delete from TIME_ALLOCATION;
delete from TIMECARD;
delete from TASK;
delete from USER_ROLE;
delete from USER;
DROP table USER;
