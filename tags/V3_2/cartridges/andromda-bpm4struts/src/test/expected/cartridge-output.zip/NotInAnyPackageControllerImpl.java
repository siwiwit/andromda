/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package ;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see .NotInAnyPackageController
 */
public class NotInAnyPackageControllerImpl extends NotInAnyPackageController
{
    /**
     * @see .NotInAnyPackageController#something(org.apache.struts.action.ActionMapping, .SomethingForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void something(ActionMapping mapping, .SomethingForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

}