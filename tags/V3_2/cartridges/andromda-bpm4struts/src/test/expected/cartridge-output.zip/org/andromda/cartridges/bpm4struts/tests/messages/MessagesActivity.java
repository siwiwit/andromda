/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.messages;

/**
 * 
 */
public final class MessagesActivity extends org.apache.struts.action.Action
{
    public org.apache.struts.action.ActionForward execute(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        return _one(mapping, form, request, response);
    }

    /**
     * 
     */
    private org.apache.struts.action.ActionForward _one(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        org.apache.struts.action.ActionForward forward = null;
        org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveSuccessMessage(request, "success.2.1");
        org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveWarningMessage(request, "warning.1.1");
        forward = _two(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private org.apache.struts.action.ActionForward _two(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        org.apache.struts.action.ActionForward forward = null;
        org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveSuccessMessage(request, "success.3.2");
        org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveWarningMessage(request, "warning.3.2");
        forward = __doSomething(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private org.apache.struts.action.ActionForward _four(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        org.apache.struts.action.ActionForward forward = null;
        org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveSuccessMessage(request, "success.7.1");
        org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveWarningMessage(request, "warning.7.1");
        forward = _one(mapping, form, request, response);
        return forward;
    }

    /**
     * 
     */
    private org.apache.struts.action.ActionForward __doSomething(org.apache.struts.action.ActionMapping mapping, org.apache.struts.action.ActionForm form, javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws java.lang.Exception
    {
        // we pass an empty form implementation to the controller, we know there are no parameters on this operation because the
        // cartridge would have issued a model validation error
        final java.lang.String value = java.lang.String.valueOf(org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().doSomething(mapping, new DoSomethingForm(){}, request, response));

        if (value.equals("true"))
        {
            org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveSuccessMessage(request, "success.4.1");
            org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveWarningMessage(request, "warning.4.1");
            return mapping.findForward("three");
        }
        if (value.equals("false"))
        {
            org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveSuccessMessage(request, "success.5.1");
            org.andromda.cartridges.bpm4struts.tests.messages.ControllerFactory.getControllerInstance().saveWarningMessage(request, "warning.5.1");
            return _four(mapping, form, request, response);
        }

        // we take the last action in case we have an invalid return value from the controller
        return _four(mapping, form, request, response);
    }

}
