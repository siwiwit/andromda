package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

import org.displaytag.decorator.TableDecorator;

/**
 * This is a <a href="http://displaytag.sourceforge.net">displaytag</a> table decorator, per column you may add
 * a getter accessor to perform additional processing.
 */
public class TableDataDecorator extends TableDecorator
{
    public TableDataDecorator()
    {
    }
}
