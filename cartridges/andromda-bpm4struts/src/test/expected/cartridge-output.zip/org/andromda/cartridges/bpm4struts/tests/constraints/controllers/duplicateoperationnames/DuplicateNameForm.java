/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>duplicateName</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.constraints.controllers.duplicateoperationnames.Controller#duplicateName
 */
public interface DuplicateNameForm
{
    /**
     * Sets the <code>diffParam</code> field.
     *
     * 
     */
    public void setDiffParam(java.lang.String diffParam);

    /**
     * Gets the <code>diffParam</code> field.
     *
     * 
     */
    public java.lang.String getDiffParam();

    /**
     * Resets the <code>diffParam</code> field.
     */
    public void resetDiffParam();

}
