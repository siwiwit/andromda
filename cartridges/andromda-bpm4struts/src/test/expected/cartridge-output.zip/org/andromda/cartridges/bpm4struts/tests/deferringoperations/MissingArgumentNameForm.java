/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>missingArgumentName</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller</code> controller.
 *
 * <p>
 *  This operation exists to test that parameters must have a
 *  non-empty name.
 * </p>
 *
 * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#missingArgumentName
 */
public interface MissingArgumentNameForm
{
    /**
     * Sets the <code></code> field.
     *
     * 
     */
    public void set(java.lang.String );

    /**
     * Gets the <code></code> field.
     *
     * 
     */
    public java.lang.String get();
    
    /**
     * Resets the <code></code> field.
     */
    public void reset();

}
