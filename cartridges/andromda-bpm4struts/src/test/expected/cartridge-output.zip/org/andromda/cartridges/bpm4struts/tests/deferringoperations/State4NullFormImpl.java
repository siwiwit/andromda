/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

public class State4NullFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
        , TestPageToPageForm
{

    private int decisionTestParam;
    private Object[] decisionTestParamValueList;
    private Object[] decisionTestParamLabelList;

    public State4NullFormImpl()
    {
    }

    /**
     * Resets the given <code>decisionTestParam</code>.
     */
    public void resetDecisionTestParam()
    {
        this.decisionTestParam = 0;
    }
    
    public void setDecisionTestParam(int decisionTestParam)
    {
        this.decisionTestParam = decisionTestParam;
    }

    /**
     * 
     */
    public int getDecisionTestParam()
    {
        return this.decisionTestParam;
    }
    

    public Object[] getDecisionTestParamBackingList()
    {
        Object[] values = this.decisionTestParamValueList;
        Object[] labels = this.decisionTestParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        Object[] backingList = new Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public Object[] getDecisionTestParamValueList()
    {
        return this.decisionTestParamValueList;
    }

    public void setDecisionTestParamValueList(Object[] decisionTestParamValueList)
    {
        this.decisionTestParamValueList = decisionTestParamValueList;
    }

    public Object[] getDecisionTestParamLabelList()
    {
        return this.decisionTestParamLabelList;
    }

    public void setDecisionTestParamLabelList(Object[] decisionTestParamLabelList)
    {
        this.decisionTestParamLabelList = decisionTestParamLabelList;
    }

    /**
     * Convenient method to quickly set the value and label backinglist for the
     * decisionTestParam property. This method takes a collection of objects, as well as
     * the property names to query on these objects in order to find the corresponding
     * values and labels.
     * <p/>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the decisionTestParam backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setDecisionTestParamBackingList(valueObjects, "id", "name")</code>
     * <p/>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or 
     *         if the caller does not have access one of the object's properties, if an exception was thrown while 
     *         accessing a property or if the property does not exist on at least one of the items
     */
    public void setDecisionTestParamBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State4NullFormImpl.setDecisionTestParamBackingList requires non-null property arguments");
        }

        this.decisionTestParamValueList = null;
        this.decisionTestParamLabelList = null;

        if (items != null)
        {
            this.decisionTestParamValueList = new Object[items.size()];
            this.decisionTestParamLabelList = new Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final Object item = iterator.next();

                    this.decisionTestParamValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.decisionTestParamLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new RuntimeException("State4NullFormImpl.setDecisionTestParamBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("decisionTestParam", this.decisionTestParam);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.decisionTestParam = 0;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (Exception exception)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private Object label = null;
        private Object value = null;

        public LabelValue(Object label, Object value)
        {
            this.label = label;
            this.value = value;
        }

        public Object getLabel()
        {
            return this.label;
        }

        public Object getValue()
        {
            return this.value;
        }

        public String toString()
        {
            return label + "=" + value;
        }
    }
}