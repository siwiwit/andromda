/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 
 */
public final class DeferringOperations extends Action
{
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // copy any parameters from the previous form into this one
        // (only those with the same name and type are considered, and only if they can be set in the target form)
        org.apache.commons.beanutils.BeanUtils.populate(form, request.getParameterMap());

        final ActionForward forward = _state1(mapping, form, request, response);
        if (this.errorsNotPresent(request))
        {
            request.getSession().setAttribute("form", form);
        }
        else
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (Exception exception)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return forward;
    }

    /**
     * 
     */
    private ActionForward _state1(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        ActionForward forward = null;

        final org.apache.struts.action.ActionMessages errors = this.getExceptionHandlerErrors(request);
        try
        {
            if (this.errorsNotPresent(request))
            {
                ControllerFactory.getControllerInstance().operation1(mapping, (DeferringOperationsFormImpl)form, request, response);
            }
            if (this.errorsNotPresent(request))
            {
                ControllerFactory.getControllerInstance().operation2(mapping, (DeferringOperationsFormImpl)form, request, response);
            }
            if (this.errorsNotPresent(request))
            {
                forward = mapping.findForward("state2");
            }
        }
        catch (Exception ex)
        {
            final String messageKey = org.andromda.presentation.bpm4struts.PatternMatchingExceptionHandler.instance().handleException(ex);
            errors.add(org.apache.struts.action.ActionMessages.GLOBAL_MESSAGE, new org.apache.struts.action.ActionMessage(messageKey));
        }
        finally
        {
        }
        if (!errors.isEmpty())
        {
            forward = mapping.getInputForward();
        }
        return forward;
    }


    /**
     * Returns true if <strong>NO</strong> errors
     * are present in the request.  This includes default validation
     * errors produced by the struts framework and the exception
     * handler errors caught by the pattern matching
     * exception handler.
     *
     * @return true if errors are <strong>not</strong> present, false otherwise.
     */
    private boolean errorsNotPresent(HttpServletRequest request)
    {
        return this.getExceptionHandlerErrors(request).isEmpty() &&
            (this.getErrors(request) == null || this.getErrors(request).isEmpty());
    }

    /**
     * <p>
     *  Retrieves the exception handler messages (if any).  Creates a new
     *  ActionMessages instance and returns that if one doesn't already exist.
     * </p>
     */
    private org.apache.struts.action.ActionMessages getExceptionHandlerErrors(HttpServletRequest request)
    {
        org.apache.struts.action.ActionMessages errors =
            (org.apache.struts.action.ActionMessages)request.getAttribute(
                "org.andromda.bpm4struts.errormessages");
        if (errors == null)
        {
            errors = new org.apache.struts.action.ActionMessages();
            request.setAttribute("org.andromda.bpm4struts.errormessages", errors);
        }
        return errors;
    }
}
