/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.deferringoperations;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>deferringOperations</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller</code> controller.
 *
 * <p>
 *  This method has practically the same name as the use-case, a
 *  user reported an error with such construction. This test exists
 *  to make sure it does not appear.
 * </p>
 *
 * @see org.andromda.cartridges.bpm4struts.tests.deferringoperations.Controller#deferringOperations
 */
public interface DeferringOperationsForm
{
    /**
     * Sets the <code>testParam2</code> field.
     *
     * 
     */
    public void setTestParam2(java.lang.String testParam2);

    /**
     * Gets the <code>testParam2</code> field.
     *
     * 
     */
    public java.lang.String getTestParam2();
    
    /**
     * Resets the <code>testParam2</code> field.
     */
    public void resetTestParam2();

    /**
     * The <code>testParam2</code> field can be selected from a list,
     * this method allows you to retrieve the current elements from that list.
     * <p/>
     * <i>Please note that the elements from that list are key value pairs, so you will
     * need to call <code>getLabel()</code> and <code>getValue()</code> to get the label and
     * value for this entry respectively.</i>
     *
     * @see #getTestParam2()
     * @see #getTestParam2ValueList()
     * @see #getTestParam2LabelList()
     */
    public Object[] getTestParam2BackingList();

    /**
     * The <code>testParam2</code> field can be selected from a list,
     * this method allows you to retrieve the values from that list.
     *
     * @see #getTestParam2()
     * @see #getTestParam2BackingList()
     */
    public Object[] getTestParam2ValueList();

    /**
     * The <code>testParam2</code> field can be selected from a list,
     * this method allows you to set the values for that list.
     *
     * @see #getTestParam2()
     * @see #getTestParam2BackingList()
     */
    public void setTestParam2ValueList(Object[] testParam2ValueList);

    /**
     * The <code>testParam2</code> field can be selected from a list,
     * this method allows you to retrieve the labels from that list.
     *
     * @see #getTestParam2()
     * @see #getTestParam2BackingList()
     */
    public Object[] getTestParam2LabelList();

    /**
     * The <code>testParam2</code> field can be selected from a list,
     * this method allows you to set the labels for that list.
     *
     * @see #getTestParam2()
     * @see #getTestParam2BackingList()
     */
    public void setTestParam2LabelList(Object[] testParam2LabelList);

}
