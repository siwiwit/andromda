/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityFifteen.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityFifteen
 */
public abstract class EntityFifteenFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityFifteen object.
    *
    * @return EntityFifteen the created object
    */
    public static EntityFifteen create ()
    {
        EntityFifteen object = new EntityFifteenImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityFifteen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityFifteen findByPrimaryKey (net.sf.hibernate.Session session, int oneBis)
        throws net.sf.hibernate.HibernateException
    {
        EntityFifteen object = (EntityFifteen) session.load(EntityFifteenImpl.class, oneBis);
        return object;
    }

}