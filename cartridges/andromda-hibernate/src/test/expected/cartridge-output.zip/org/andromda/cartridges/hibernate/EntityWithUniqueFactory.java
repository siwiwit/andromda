/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityWithUnique.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityWithUnique
 */
public abstract class EntityWithUniqueFactory
{
   /**
    * Creates a(n) EntityWithUnique object.
    *
    * @param attrib1
    * @param attrib2
    * @return EntityWithUnique the created object
    */
    public static EntityWithUnique create (java.lang.String attrib1, java.lang.String attrib2)
    {
        EntityWithUnique object = new EntityWithUniqueImpl();

        object.setAttrib1 (attrib1);
        object.setAttrib2 (attrib2);

        return object;
    }

    /**
     *
     * Finds EntityWithUnique object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityWithUnique findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityWithUnique object = (EntityWithUnique) session.load(EntityWithUniqueImpl.class, id);
        return object;
    }

}