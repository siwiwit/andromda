/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.ejb;

/**
 * Home interface for the EntityTwo entity bean.
 * <p>
 * Tests generation with a primary key defined.
 * </p>
 */
public interface EntityTwoLocalHome
    extends javax.ejb.EJBLocalHome
{
    // -- accessors for environment entries and constants --
    public static final String COMP_NAME="java:comp/env/ejb/org.andromda.cartridges.ejb.EntityTwo/Local";
    public static final String JNDI_NAME="ejb/org.andromda.cartridges.ejb.EntityTwo/Local";

    // -- accessors for constants --
    // ---------------- home methods  ----------------------

    // ---------------- finder methods  ----------------------

    /**
     * Find this entity by its primary key
     * @param key the primary key;
     */
     public EntityTwo findByPrimaryKey(java.lang.Long key)
            throws javax.ejb.FinderException;

    // ---------------- create methods --------------------

    /**
     * Create method with all CMP attribute values.
     * @param name Value for the name property
     * @param attributeOne Value for the attributeOne property
     * @param id Value for the id property
     */
    public EntityTwo create(java.lang.String name, java.lang.Long attributeOne, java.lang.Long id)
           throws javax.ejb.CreateException;

    /**
     * Create method with all CMP attribute values and CMR relations.
     * @param name Value for the name property
     * @param attributeOne Value for the attributeOne property
     * @param id Value for the id property
     * @param entityThree Value for the entityThree relation role
     */
    public EntityTwo create(java.lang.String name, java.lang.Long attributeOne, java.lang.Long id, org.andromda.cartridges.ejb.EntityThree entityThree)
           throws javax.ejb.CreateException;

}