//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ModelElementFacade
 *
 * @see org.andromda.metafacades.uml.ModelElementFacade
 */
public abstract class ModelElementFacadeLogic
    extends org.andromda.core.metafacade.MetafacadeBase
    implements org.andromda.metafacades.uml.ModelElementFacade
{

    protected org.omg.uml.foundation.core.ModelElement metaObject;

    public ModelElementFacadeLogic(org.omg.uml.foundation.core.ModelElement metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ModelElementFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getVisibility()
    */
    protected abstract java.lang.String handleGetVisibility();

    private void handleGetVisibility1aPreCondition()
    {
    }

    private void handleGetVisibility1aPostCondition()
    {
    }

    private java.lang.String __visibility1a;
    private boolean __visibility1aSet = false;

    public final java.lang.String getVisibility()
    {
        java.lang.String visibility1a = this.__visibility1a;
        if (!this.__visibility1aSet)
        {
            handleGetVisibility1aPreCondition();
            visibility1a = handleGetVisibility();
            handleGetVisibility1aPostCondition();
            this.__visibility1a = visibility1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__visibility1aSet = true;
            }
        }
        return visibility1a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getPackagePath()
    */
    protected abstract java.lang.String handleGetPackagePath();

    private void handleGetPackagePath2aPreCondition()
    {
    }

    private void handleGetPackagePath2aPostCondition()
    {
    }

    private java.lang.String __packagePath2a;
    private boolean __packagePath2aSet = false;

    public final java.lang.String getPackagePath()
    {
        java.lang.String packagePath2a = this.__packagePath2a;
        if (!this.__packagePath2aSet)
        {
            handleGetPackagePath2aPreCondition();
            packagePath2a = handleGetPackagePath();
            handleGetPackagePath2aPostCondition();
            this.__packagePath2a = packagePath2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__packagePath2aSet = true;
            }
        }
        return packagePath2a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getName()
    */
    protected abstract java.lang.String handleGetName();

    private void handleGetName3aPreCondition()
    {
    }

    private void handleGetName3aPostCondition()
    {
    }

    private java.lang.String __name3a;
    private boolean __name3aSet = false;

    public final java.lang.String getName()
    {
        java.lang.String name3a = this.__name3a;
        if (!this.__name3aSet)
        {
            handleGetName3aPreCondition();
            name3a = handleGetName();
            handleGetName3aPostCondition();
            this.__name3a = name3a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__name3aSet = true;
            }
        }
        return name3a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getPackageName()
    */
    protected abstract java.lang.String handleGetPackageName();

    private void handleGetPackageName4aPreCondition()
    {
    }

    private void handleGetPackageName4aPostCondition()
    {
    }

    private java.lang.String __packageName4a;
    private boolean __packageName4aSet = false;

    public final java.lang.String getPackageName()
    {
        java.lang.String packageName4a = this.__packageName4a;
        if (!this.__packageName4aSet)
        {
            handleGetPackageName4aPreCondition();
            packageName4a = handleGetPackageName();
            handleGetPackageName4aPostCondition();
            this.__packageName4a = packageName4a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__packageName4aSet = true;
            }
        }
        return packageName4a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedName()
    */
    protected abstract java.lang.String handleGetFullyQualifiedName();

    private void handleGetFullyQualifiedName5aPreCondition()
    {
    }

    private void handleGetFullyQualifiedName5aPostCondition()
    {
    }

    private java.lang.String __fullyQualifiedName5a;
    private boolean __fullyQualifiedName5aSet = false;

    public final java.lang.String getFullyQualifiedName()
    {
        java.lang.String fullyQualifiedName5a = this.__fullyQualifiedName5a;
        if (!this.__fullyQualifiedName5aSet)
        {
            handleGetFullyQualifiedName5aPreCondition();
            fullyQualifiedName5a = handleGetFullyQualifiedName();
            handleGetFullyQualifiedName5aPostCondition();
            this.__fullyQualifiedName5a = fullyQualifiedName5a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fullyQualifiedName5aSet = true;
            }
        }
        return fullyQualifiedName5a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getFullyQualifiedNamePath()
    */
    protected abstract java.lang.String handleGetFullyQualifiedNamePath();

    private void handleGetFullyQualifiedNamePath6aPreCondition()
    {
    }

    private void handleGetFullyQualifiedNamePath6aPostCondition()
    {
    }

    private java.lang.String __fullyQualifiedNamePath6a;
    private boolean __fullyQualifiedNamePath6aSet = false;

    public final java.lang.String getFullyQualifiedNamePath()
    {
        java.lang.String fullyQualifiedNamePath6a = this.__fullyQualifiedNamePath6a;
        if (!this.__fullyQualifiedNamePath6aSet)
        {
            handleGetFullyQualifiedNamePath6aPreCondition();
            fullyQualifiedNamePath6a = handleGetFullyQualifiedNamePath();
            handleGetFullyQualifiedNamePath6aPostCondition();
            this.__fullyQualifiedNamePath6a = fullyQualifiedNamePath6a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fullyQualifiedNamePath6aSet = true;
            }
        }
        return fullyQualifiedNamePath6a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getLanguageMappings()
    */
    protected abstract org.andromda.metafacades.uml.TypeMappings handleGetLanguageMappings();

    private void handleGetLanguageMappings7aPreCondition()
    {
    }

    private void handleGetLanguageMappings7aPostCondition()
    {
    }

    private org.andromda.metafacades.uml.TypeMappings __languageMappings7a;
    private boolean __languageMappings7aSet = false;

    public final org.andromda.metafacades.uml.TypeMappings getLanguageMappings()
    {
        org.andromda.metafacades.uml.TypeMappings languageMappings7a = this.__languageMappings7a;
        if (!this.__languageMappings7aSet)
        {
            handleGetLanguageMappings7aPreCondition();
            languageMappings7a = handleGetLanguageMappings();
            handleGetLanguageMappings7aPostCondition();
            this.__languageMappings7a = languageMappings7a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__languageMappings7aSet = true;
            }
        }
        return languageMappings7a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getStereotypeNames()
    */
    protected abstract java.util.Collection handleGetStereotypeNames();

    private void handleGetStereotypeNames8aPreCondition()
    {
    }

    private void handleGetStereotypeNames8aPostCondition()
    {
    }

    private java.util.Collection __stereotypeNames8a;
    private boolean __stereotypeNames8aSet = false;

    public final java.util.Collection getStereotypeNames()
    {
        java.util.Collection stereotypeNames8a = this.__stereotypeNames8a;
        if (!this.__stereotypeNames8aSet)
        {
            handleGetStereotypeNames8aPreCondition();
            stereotypeNames8a = handleGetStereotypeNames();
            handleGetStereotypeNames8aPostCondition();
            this.__stereotypeNames8a = stereotypeNames8a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__stereotypeNames8aSet = true;
            }
        }
        return stereotypeNames8a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#getId()
    */
    protected abstract java.lang.String handleGetId();

    private void handleGetId9aPreCondition()
    {
    }

    private void handleGetId9aPostCondition()
    {
    }

    private java.lang.String __id9a;
    private boolean __id9aSet = false;

    public final java.lang.String getId()
    {
        java.lang.String id9a = this.__id9a;
        if (!this.__id9aSet)
        {
            handleGetId9aPreCondition();
            id9a = handleGetId();
            handleGetId9aPostCondition();
            this.__id9a = id9a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__id9aSet = true;
            }
        }
        return id9a;
    }

   /**
    * @see org.andromda.metafacades.uml.ModelElementFacade#isConstraintsPresent()
    */
    protected abstract boolean handleIsConstraintsPresent();

    private void handleIsConstraintsPresent10aPreCondition()
    {
    }

    private void handleIsConstraintsPresent10aPostCondition()
    {
    }

    private boolean __constraintsPresent10a;
    private boolean __constraintsPresent10aSet = false;

    public final boolean isConstraintsPresent()
    {
        boolean constraintsPresent10a = this.__constraintsPresent10a;
        if (!this.__constraintsPresent10aSet)
        {
            handleIsConstraintsPresent10aPreCondition();
            constraintsPresent10a = handleIsConstraintsPresent();
            handleIsConstraintsPresent10aPostCondition();
            this.__constraintsPresent10a = constraintsPresent10a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__constraintsPresent10aSet = true;
            }
        }
        return constraintsPresent10a;
    }

    // ---------------- business methods ----------------------

    protected abstract java.lang.Object handleFindTaggedValue(java.lang.String tagName);

    private void handleFindTaggedValue1oPreCondition()
    {
    }

    private void handleFindTaggedValue1oPostCondition()
    {
    }

    public java.lang.Object findTaggedValue(java.lang.String tagName)
    {
        handleFindTaggedValue1oPreCondition();
        java.lang.Object returnValue = handleFindTaggedValue(tagName);
        handleFindTaggedValue1oPostCondition();
        return returnValue;
    }

    protected abstract boolean handleHasStereotype(java.lang.String stereotypeName);

    private void handleHasStereotype2oPreCondition()
    {
    }

    private void handleHasStereotype2oPostCondition()
    {
    }

    public boolean hasStereotype(java.lang.String stereotypeName)
    {
        handleHasStereotype2oPreCondition();
        boolean returnValue = handleHasStereotype(stereotypeName);
        handleHasStereotype2oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetDocumentation(java.lang.String indent);

    private void handleGetDocumentation3oPreCondition()
    {
    }

    private void handleGetDocumentation3oPostCondition()
    {
    }

    public java.lang.String getDocumentation(java.lang.String indent)
    {
        handleGetDocumentation3oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent);
        handleGetDocumentation3oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetFullyQualifiedName(boolean modelName);

    private void handleGetFullyQualifiedName4oPreCondition()
    {
    }

    private void handleGetFullyQualifiedName4oPostCondition()
    {
    }

    public java.lang.String getFullyQualifiedName(boolean modelName)
    {
        handleGetFullyQualifiedName4oPreCondition();
        java.lang.String returnValue = handleGetFullyQualifiedName(modelName);
        handleGetFullyQualifiedName4oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetDocumentation(java.lang.String indent, int lineLength);

    private void handleGetDocumentation5oPreCondition()
    {
    }

    private void handleGetDocumentation5oPostCondition()
    {
    }

    public java.lang.String getDocumentation(java.lang.String indent, int lineLength)
    {
        handleGetDocumentation5oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent, lineLength);
        handleGetDocumentation5oPostCondition();
        return returnValue;
    }

    protected abstract boolean handleHasExactStereotype(java.lang.String stereotypeName);

    private void handleHasExactStereotype6oPreCondition()
    {
    }

    private void handleHasExactStereotype6oPostCondition()
    {
    }

    public boolean hasExactStereotype(java.lang.String stereotypeName)
    {
        handleHasExactStereotype6oPreCondition();
        boolean returnValue = handleHasExactStereotype(stereotypeName);
        handleHasExactStereotype6oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleTranslateConstraint(java.lang.String name, java.lang.String translation);

    private void handleTranslateConstraint7oPreCondition()
    {
    }

    private void handleTranslateConstraint7oPostCondition()
    {
    }

    public java.lang.String translateConstraint(java.lang.String name, java.lang.String translation)
    {
        handleTranslateConstraint7oPreCondition();
        java.lang.String returnValue = handleTranslateConstraint(name, translation);
        handleTranslateConstraint7oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String[] handleTranslateConstraints(java.lang.String kind, java.lang.String translation);

    private void handleTranslateConstraints8oPreCondition()
    {
    }

    private void handleTranslateConstraints8oPostCondition()
    {
    }

    public java.lang.String[] translateConstraints(java.lang.String kind, java.lang.String translation)
    {
        handleTranslateConstraints8oPreCondition();
        java.lang.String[] returnValue = handleTranslateConstraints(kind, translation);
        handleTranslateConstraints8oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String[] handleTranslateConstraints(java.lang.String translation);

    private void handleTranslateConstraints9oPreCondition()
    {
    }

    private void handleTranslateConstraints9oPostCondition()
    {
    }

    public java.lang.String[] translateConstraints(java.lang.String translation)
    {
        handleTranslateConstraints9oPreCondition();
        java.lang.String[] returnValue = handleTranslateConstraints(translation);
        handleTranslateConstraints9oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleGetConstraints(java.lang.String kind);

    private void handleGetConstraints10oPreCondition()
    {
    }

    private void handleGetConstraints10oPostCondition()
    {
    }

    public java.util.Collection getConstraints(java.lang.String kind)
    {
        handleGetConstraints10oPreCondition();
        java.util.Collection returnValue = handleGetConstraints(kind);
        handleGetConstraints10oPostCondition();
        return returnValue;
    }

    protected abstract java.util.Collection handleFindTaggedValues(java.lang.String tagName);

    private void handleFindTaggedValues11oPreCondition()
    {
    }

    private void handleFindTaggedValues11oPostCondition()
    {
    }

    public java.util.Collection findTaggedValues(java.lang.String tagName)
    {
        handleFindTaggedValues11oPreCondition();
        java.util.Collection returnValue = handleFindTaggedValues(tagName);
        handleFindTaggedValues11oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle);

    private void handleGetDocumentation12oPreCondition()
    {
    }

    private void handleGetDocumentation12oPostCondition()
    {
    }

    public java.lang.String getDocumentation(java.lang.String indent, int lineLength, boolean htmlStyle)
    {
        handleGetDocumentation12oPreCondition();
        java.lang.String returnValue = handleGetDocumentation(indent, lineLength, htmlStyle);
        handleGetDocumentation12oPostCondition();
        return returnValue;
    }

    protected abstract java.lang.String handleGetPackageName(boolean modelName);

    private void handleGetPackageName13oPreCondition()
    {
    }

    private void handleGetPackageName13oPostCondition()
    {
    }

    public java.lang.String getPackageName(boolean modelName)
    {
        handleGetPackageName13oPreCondition();
        java.lang.String returnValue = handleGetPackageName(modelName);
        handleGetPackageName13oPostCondition();
        return returnValue;
    }

    // ------------- associations ------------------

    private void handleGetTaggedValues1rPreCondition()
    {
    }

    private void handleGetTaggedValues1rPostCondition()
    {
    }

    public final java.util.Collection getTaggedValues()
    {
        java.util.Collection getTaggedValues1r = null;
        handleGetTaggedValues1rPreCondition();
        Object result = this.shieldedElements(handleGetTaggedValues());
        try
        {
            getTaggedValues1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTaggedValues1rPostCondition();
        return getTaggedValues1r;
    }

    protected abstract java.util.Collection handleGetTaggedValues();

    private void handleGetPackage2rPreCondition()
    {
    }

    private void handleGetPackage2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelElementFacade getPackage()
    {
        org.andromda.metafacades.uml.ModelElementFacade getPackage2r = null;
        handleGetPackage2rPreCondition();
        Object result = this.shieldedElement(handleGetPackage());
        try
        {
            getPackage2r = (org.andromda.metafacades.uml.ModelElementFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetPackage2rPostCondition();
        return getPackage2r;
    }

    protected abstract java.lang.Object handleGetPackage();

    private void handleGetRootPackage4rPreCondition()
    {
    }

    private void handleGetRootPackage4rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.PackageFacade getRootPackage()
    {
        org.andromda.metafacades.uml.PackageFacade getRootPackage4r = null;
        handleGetRootPackage4rPreCondition();
        Object result = this.shieldedElement(handleGetRootPackage());
        try
        {
            getRootPackage4r = (org.andromda.metafacades.uml.PackageFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetRootPackage4rPostCondition();
        return getRootPackage4r;
    }

    protected abstract java.lang.Object handleGetRootPackage();

    private void handleGetTargetDependencies5rPreCondition()
    {
    }

    private void handleGetTargetDependencies5rPostCondition()
    {
    }

    public final java.util.Collection getTargetDependencies()
    {
        java.util.Collection getTargetDependencies5r = null;
        handleGetTargetDependencies5rPreCondition();
        Object result = this.shieldedElements(handleGetTargetDependencies());
        try
        {
            getTargetDependencies5r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetTargetDependencies5rPostCondition();
        return getTargetDependencies5r;
    }

    protected abstract java.util.Collection handleGetTargetDependencies();

    private void handleGetNameSpace6rPreCondition()
    {
    }

    private void handleGetNameSpace6rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.NamespaceFacade getNameSpace()
    {
        org.andromda.metafacades.uml.NamespaceFacade getNameSpace6r = null;
        handleGetNameSpace6rPreCondition();
        Object result = this.shieldedElement(handleGetNameSpace());
        try
        {
            getNameSpace6r = (org.andromda.metafacades.uml.NamespaceFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetNameSpace6rPostCondition();
        return getNameSpace6r;
    }

    protected abstract java.lang.Object handleGetNameSpace();

    private void handleGetActivityGraphContext7rPreCondition()
    {
    }

    private void handleGetActivityGraphContext7rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext()
    {
        org.andromda.metafacades.uml.ActivityGraphFacade getActivityGraphContext7r = null;
        handleGetActivityGraphContext7rPreCondition();
        Object result = this.shieldedElement(handleGetActivityGraphContext());
        try
        {
            getActivityGraphContext7r = (org.andromda.metafacades.uml.ActivityGraphFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetActivityGraphContext7rPostCondition();
        return getActivityGraphContext7r;
    }

    protected abstract java.lang.Object handleGetActivityGraphContext();

    private void handleGetModel8rPreCondition()
    {
    }

    private void handleGetModel8rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ModelFacade getModel()
    {
        org.andromda.metafacades.uml.ModelFacade getModel8r = null;
        handleGetModel8rPreCondition();
        Object result = this.shieldedElement(handleGetModel());
        try
        {
            getModel8r = (org.andromda.metafacades.uml.ModelFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetModel8rPostCondition();
        return getModel8r;
    }

    protected abstract java.lang.Object handleGetModel();

    private void handleGetStereotypes9rPreCondition()
    {
    }

    private void handleGetStereotypes9rPostCondition()
    {
    }

    public final java.util.Collection getStereotypes()
    {
        java.util.Collection getStereotypes9r = null;
        handleGetStereotypes9rPreCondition();
        Object result = this.shieldedElements(handleGetStereotypes());
        try
        {
            getStereotypes9r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetStereotypes9rPostCondition();
        return getStereotypes9r;
    }

    protected abstract java.util.Collection handleGetStereotypes();

    private void handleGetConstraints10rPreCondition()
    {
    }

    private void handleGetConstraints10rPostCondition()
    {
    }

    public final java.util.Collection getConstraints()
    {
        java.util.Collection getConstraints10r = null;
        handleGetConstraints10rPreCondition();
        Object result = this.shieldedElements(handleGetConstraints());
        try
        {
            getConstraints10r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetConstraints10rPostCondition();
        return getConstraints10r;
    }

    protected abstract java.util.Collection handleGetConstraints();

    private void handleGetSourceDependencies12rPreCondition()
    {
    }

    private void handleGetSourceDependencies12rPostCondition()
    {
    }

    public final java.util.Collection getSourceDependencies()
    {
        java.util.Collection getSourceDependencies12r = null;
        handleGetSourceDependencies12rPreCondition();
        Object result = this.shieldedElements(handleGetSourceDependencies());
        try
        {
            getSourceDependencies12r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetSourceDependencies12rPostCondition();
        return getSourceDependencies12r;
    }

    protected abstract java.util.Collection handleGetSourceDependencies();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}