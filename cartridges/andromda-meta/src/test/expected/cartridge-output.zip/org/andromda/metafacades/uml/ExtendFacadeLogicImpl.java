package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.ExtendFacade.
 *
 * @see org.andromda.metafacades.uml.ExtendFacade
 */
public class ExtendFacadeLogicImpl
    extends ExtendFacadeLogic
{

    public ExtendFacadeLogicImpl (org.omg.uml.behavioralelements.usecases.Extend metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.ExtendFacade#getBase()
     */
    protected java.lang.Object handleGetBase()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ExtendFacade#getExtensionPoints()
     */
    protected java.util.List handleGetExtensionPoints()
    {
        // TODO: add your implementation here!
        return null;
    }

    /**
     * @see org.andromda.metafacades.uml.ExtendFacade#getExtension()
     */
    protected java.lang.Object handleGetExtension()
    {
        // TODO: add your implementation here!
        return null;
    }

}