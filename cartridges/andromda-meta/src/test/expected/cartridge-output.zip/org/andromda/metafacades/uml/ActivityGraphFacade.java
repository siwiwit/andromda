//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ActivityGraphFacade
    extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public java.util.Collection getActionStates();

   /**
    * 
    */
    public org.andromda.metafacades.uml.ModelElementFacade getContextElement();

   /**
    * 
    */
    public java.util.Collection getFinalStates();

   /**
    * 
    */
    public java.util.Collection getInitialStates();

   /**
    * 
    */
    public java.util.Collection getObjectFlowStates();

   /**
    * 
    */
    public java.util.Collection getPartitions();

   /**
    * 
    */
    public java.util.Collection getPseudostates();

   /**
    * 
    */
    public java.util.Collection getTransitions();

   /**
    * <p>
    *  The use-case owning this activity graph.
    * </p>
    */
    public org.andromda.metafacades.uml.UseCaseFacade getUseCase();

}