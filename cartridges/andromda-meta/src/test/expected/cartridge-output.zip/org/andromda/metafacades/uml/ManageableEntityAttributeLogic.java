//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ManageableEntityAttribute
 *
 * @see org.andromda.metafacades.uml.ManageableEntityAttribute
 */
public abstract class ManageableEntityAttributeLogic
    extends org.andromda.metafacades.uml.EntityAttributeLogicImpl
    implements org.andromda.metafacades.uml.ManageableEntityAttribute
{

    protected Object metaObject;

    public ManageableEntityAttributeLogic(Object metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ManageableEntityAttribute";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.ManageableEntityAttribute#isDisplay()
    */
    protected abstract boolean handleIsDisplay();

    private void handleIsDisplay1aPreCondition()
    {
    }

    private void handleIsDisplay1aPostCondition()
    {
    }

    private boolean __display1a;
    private boolean __display1aSet = false;

    public final boolean isDisplay()
    {
        boolean display1a = this.__display1a;
        if (!this.__display1aSet)
        {
            handleIsDisplay1aPreCondition();
            display1a = handleIsDisplay();
            handleIsDisplay1aPostCondition();
            this.__display1a = display1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__display1aSet = true;
            }
        }
        return display1a;
    }

    // ------------- associations ------------------

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}