//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ManageableEntityAttribute
    extends org.andromda.metafacades.uml.EntityAttribute
{

   /**
    * <p>
    *  Whether or not this attribute should be displayed.
    * </p>
    */
    public boolean isDisplay();

}