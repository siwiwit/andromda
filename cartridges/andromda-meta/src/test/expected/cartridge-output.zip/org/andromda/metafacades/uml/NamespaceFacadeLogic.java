//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.NamespaceFacade
 *
 * @see org.andromda.metafacades.uml.NamespaceFacade
 */
public abstract class NamespaceFacadeLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.NamespaceFacade
{

    protected Object metaObject;

    public NamespaceFacadeLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Classifier)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.NamespaceFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetOwnedElements1rPreCondition()
    {
    }

    private void handleGetOwnedElements1rPostCondition()
    {
    }

    public final java.util.Collection getOwnedElements()
    {
        java.util.Collection getOwnedElements1r = null;
        handleGetOwnedElements1rPreCondition();
        Object result = this.shieldedElements(handleGetOwnedElements());
        try
        {
            getOwnedElements1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetOwnedElements1rPostCondition();
        return getOwnedElements1r;
    }

    protected abstract java.util.Collection handleGetOwnedElements();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}