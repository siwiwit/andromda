//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.EnumerationFacade
 *
 * @see org.andromda.metafacades.uml.EnumerationFacade
 */
public abstract class EnumerationFacadeLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.EnumerationFacade
{

    protected Object metaObject;

    public EnumerationFacadeLogic(Object metaObject, String context)
    {
        super((org.omg.uml.foundation.core.Classifier)metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.EnumerationFacade";
        }
        return context;
    }

    // --------------- attributes ---------------------

   /**
    * @see org.andromda.metafacades.uml.EnumerationFacade#getFromOperationSignature()
    */
    protected abstract java.lang.String handleGetFromOperationSignature();

    private void handleGetFromOperationSignature1aPreCondition()
    {
    }

    private void handleGetFromOperationSignature1aPostCondition()
    {
    }

    private java.lang.String __fromOperationSignature1a;
    private boolean __fromOperationSignature1aSet = false;

    public final java.lang.String getFromOperationSignature()
    {
        java.lang.String fromOperationSignature1a = this.__fromOperationSignature1a;
        if (!this.__fromOperationSignature1aSet)
        {
            handleGetFromOperationSignature1aPreCondition();
            fromOperationSignature1a = handleGetFromOperationSignature();
            handleGetFromOperationSignature1aPostCondition();
            this.__fromOperationSignature1a = fromOperationSignature1a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fromOperationSignature1aSet = true;
            }
        }
        return fromOperationSignature1a;
    }

   /**
    * @see org.andromda.metafacades.uml.EnumerationFacade#getFromOperationName()
    */
    protected abstract java.lang.String handleGetFromOperationName();

    private void handleGetFromOperationName2aPreCondition()
    {
    }

    private void handleGetFromOperationName2aPostCondition()
    {
    }

    private java.lang.String __fromOperationName2a;
    private boolean __fromOperationName2aSet = false;

    public final java.lang.String getFromOperationName()
    {
        java.lang.String fromOperationName2a = this.__fromOperationName2a;
        if (!this.__fromOperationName2aSet)
        {
            handleGetFromOperationName2aPreCondition();
            fromOperationName2a = handleGetFromOperationName();
            handleGetFromOperationName2aPostCondition();
            this.__fromOperationName2a = fromOperationName2a;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__fromOperationName2aSet = true;
            }
        }
        return fromOperationName2a;
    }

    // ------------- associations ------------------

    private void handleGetLiterals1rPreCondition()
    {
    }

    private void handleGetLiterals1rPostCondition()
    {
    }

    public final java.util.Collection getLiterals()
    {
        java.util.Collection getLiterals1r = null;
        handleGetLiterals1rPreCondition();
        Object result = this.shieldedElements(handleGetLiterals());
        try
        {
            getLiterals1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetLiterals1rPostCondition();
        return getLiterals1r;
    }

    protected abstract java.util.Collection handleGetLiterals();

    private void handleGetLiteralType2rPreCondition()
    {
    }

    private void handleGetLiteralType2rPostCondition()
    {
    }

    public final org.andromda.metafacades.uml.ClassifierFacade getLiteralType()
    {
        org.andromda.metafacades.uml.ClassifierFacade getLiteralType2r = null;
        handleGetLiteralType2rPreCondition();
        Object result = this.shieldedElement(handleGetLiteralType());
        try
        {
            getLiteralType2r = (org.andromda.metafacades.uml.ClassifierFacade)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetLiteralType2rPostCondition();
        return getLiteralType2r;
    }

    protected abstract java.lang.Object handleGetLiteralType();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.notEmpty(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"literals")));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "An enumeration must have at least one literal modeled."));
        }
        {
            final java.lang.Object contextElement = this; boolean constraintValid = org.andromda.translation.ocl.validation.OCLResultEnsurer.ensure(org.andromda.translation.ocl.validation.OCLCollections.forAll(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"attributes"),new org.apache.commons.collections.Predicate(){public boolean evaluate(java.lang.Object object){return Boolean.valueOf(String.valueOf(org.andromda.translation.ocl.validation.OCLExpressions.equal(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(object,"type.fullyQualifiedName"),org.andromda.translation.ocl.validation.OCLIntrospector.invoke(org.andromda.translation.ocl.validation.OCLCollections.first(org.andromda.translation.ocl.validation.OCLIntrospector.invoke(contextElement,"attributes")),"type.fullyQualifiedName")))).booleanValue();}}));
            if (!constraintValid)
                validationMessages.add(
                    new org.andromda.core.metafacade.ModelValidationMessage(
                        this,
                        "Enumeration literals must all be of the same type."));
        }
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}