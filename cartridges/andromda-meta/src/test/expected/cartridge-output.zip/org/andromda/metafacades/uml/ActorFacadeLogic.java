//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.ActorFacade
 *
 * @see org.andromda.metafacades.uml.ActorFacade
 */
public abstract class ActorFacadeLogic
    extends org.andromda.metafacades.uml.ClassifierFacadeLogicImpl
    implements org.andromda.metafacades.uml.ActorFacade
{

    protected org.omg.uml.behavioralelements.usecases.Actor metaObject;

    public ActorFacadeLogic(org.omg.uml.behavioralelements.usecases.Actor metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.ActorFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetGeneralizedByActors3rPreCondition()
    {
    }

    private void handleGetGeneralizedByActors3rPostCondition()
    {
    }

    private java.util.List __getGeneralizedByActors3r;
    private boolean __getGeneralizedByActors3rSet = false;

    public final java.util.List getGeneralizedByActors()
    {
        java.util.List getGeneralizedByActors3r = this.__getGeneralizedByActors3r;
        if (!this.__getGeneralizedByActors3rSet)
        {
            handleGetGeneralizedByActors3rPreCondition();
            Object result = this.shieldedElements(handleGetGeneralizedByActors());
            try
            {
                getGeneralizedByActors3r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetGeneralizedByActors3rPostCondition();
            this.__getGeneralizedByActors3r = getGeneralizedByActors3r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getGeneralizedByActors3rSet = true;
            }
        }
        return getGeneralizedByActors3r;
    }

    protected abstract java.util.List handleGetGeneralizedByActors();

    private void handleGetGeneralizedActors4rPreCondition()
    {
    }

    private void handleGetGeneralizedActors4rPostCondition()
    {
    }

    private java.util.List __getGeneralizedActors4r;
    private boolean __getGeneralizedActors4rSet = false;

    public final java.util.List getGeneralizedActors()
    {
        java.util.List getGeneralizedActors4r = this.__getGeneralizedActors4r;
        if (!this.__getGeneralizedActors4rSet)
        {
            handleGetGeneralizedActors4rPreCondition();
            Object result = this.shieldedElements(handleGetGeneralizedActors());
            try
            {
                getGeneralizedActors4r = (java.util.List)result;
            }
            catch (ClassCastException ex)
            {
                // ignore since the metafacade shouldn't
                // be set if its not of the correct type
            }
            handleGetGeneralizedActors4rPostCondition();
            this.__getGeneralizedActors4r = getGeneralizedActors4r;
            if (isMetafacadePropertyCachingEnabled())
            {
                this.__getGeneralizedActors4rSet = true;
            }
        }
        return getGeneralizedActors4r;
    }

    protected abstract java.util.List handleGetGeneralizedActors();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}