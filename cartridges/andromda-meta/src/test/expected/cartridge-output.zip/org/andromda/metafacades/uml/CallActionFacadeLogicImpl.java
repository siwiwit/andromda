package org.andromda.metafacades.uml;


/**
 * MetafacadeLogic implementation for org.andromda.metafacades.uml.CallActionFacade.
 *
 * @see org.andromda.metafacades.uml.CallActionFacade
 */
public class CallActionFacadeLogicImpl
    extends CallActionFacadeLogic
{

    public CallActionFacadeLogicImpl (org.omg.uml.behavioralelements.commonbehavior.CallAction metaObject, String context)
    {
        super (metaObject, context);
    }
    /**
     * @see org.andromda.metafacades.uml.CallActionFacade#getOperation()
     */
    protected java.lang.Object handleGetOperation()
    {
        // TODO: add your implementation here!
        return null;
    }

}