//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ParameterFacade
    extends org.andromda.metafacades.uml.ModelElementFacade
{

   /**
    * 
    */
    public java.lang.String getDefaultValue();

   /**
    * <p>
    *  If this parameter is located on an event, this will represent
    *  that event.
    * </p>
    */
    public org.andromda.metafacades.uml.EventFacade getEvent();

   /**
    * <p>
    *  If this parameter is located on an operation, this will
    *  represent that operation.
    * </p>
    */
    public org.andromda.metafacades.uml.OperationFacade getOperation();

   /**
    * 
    */
    public org.andromda.metafacades.uml.ClassifierFacade getType();

   /**
    * <p>
    *  Whether or not this parameter is considered required (i.e must
    *  a non-empty value).
    * </p>
    */
    public boolean isRequired();

   /**
    * <p>
    *  Whether or not this parameter represents a return parameter.
    * </p>
    */
    public boolean isReturn();

}