//
// Attention: generated code (by MetafacadeLogic.vsl) - do not modify!
//
package org.andromda.metafacades.uml;

/**
 * MetafacadeLogic for org.andromda.metafacades.uml.StateFacade
 *
 * @see org.andromda.metafacades.uml.StateFacade
 */
public abstract class StateFacadeLogic
    extends org.andromda.metafacades.uml.StateVertexFacadeLogicImpl
    implements org.andromda.metafacades.uml.StateFacade
{

    protected org.omg.uml.behavioralelements.statemachines.State metaObject;

    public StateFacadeLogic(org.omg.uml.behavioralelements.statemachines.State metaObject, String context)
    {
        super(metaObject, getContext(context));
        this.metaObject = metaObject;
    }

    /**
     * Gets the context for this metafacade logic instance.
     */
    private static String getContext(String context)
    {
        if (context == null)
        {
            context = "org.andromda.metafacades.uml.StateFacade";
        }
        return context;
    }

    // ------------- associations ------------------

    private void handleGetDeferrableEvents1rPreCondition()
    {
    }

    private void handleGetDeferrableEvents1rPostCondition()
    {
    }

    public final java.util.Collection getDeferrableEvents()
    {
        java.util.Collection getDeferrableEvents1r = null;
        handleGetDeferrableEvents1rPreCondition();
        Object result = this.shieldedElements(handleGetDeferrableEvents());
        try
        {
            getDeferrableEvents1r = (java.util.Collection)result;
        }
        catch (ClassCastException ex)
        {
            // ignore since the metafacade shouldn't
            // be set if its not of the correct type
        }
        handleGetDeferrableEvents1rPostCondition();
        return getDeferrableEvents1r;
    }

    protected abstract java.util.Collection handleGetDeferrableEvents();

    /**
     * @see org.andromda.core.metafacade.MetafacadeBase#validateInvariants(java.util.Collection)
     */
    public void validateInvariants(java.util.Collection validationMessages)
    {
        super.validateInvariants(validationMessages);
    }

    /**
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
        StringBuffer toString = new StringBuffer(this.getClass().getName());
        toString.append("[");
        try
        {
            toString.append(org.apache.commons.beanutils.PropertyUtils.getProperty(this, "name"));
        }
        catch (Throwable th)
        {
            // Just ignore when the metafacade doesn't have a name property
        }
        toString.append("]");
        return toString.toString();
    }
}