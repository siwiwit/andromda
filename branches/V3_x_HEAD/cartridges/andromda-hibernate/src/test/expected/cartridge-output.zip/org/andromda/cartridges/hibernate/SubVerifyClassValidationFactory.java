/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type SubVerifyClassValidation.
 * The Hibernate <em>concrete</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.SubVerifyClassValidation
 */
public abstract class SubVerifyClassValidationFactory
{
   /**
    * Creates a(n) SubVerifyClassValidation object.
    *
    * @return SubVerifyClassValidation the created object
    */
    public static SubVerifyClassValidation create ()
    {
        SubVerifyClassValidation object = new SubVerifyClassValidationImpl();


        return object;
    }

    /**
     *
     * Finds SubVerifyClassValidation object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static SubVerifyClassValidation findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        SubVerifyClassValidation object = (SubVerifyClassValidation) session.load(SubVerifyClassValidationImpl.class, id);
        return object;
    }

}