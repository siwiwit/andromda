/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityWithToMAggregation.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityWithToMAggregation
 */
public abstract class EntityWithToMAggregationFactory
{
   /**
    * Creates a(n) EntityWithToMAggregation object.
    *
    * @return EntityWithToMAggregation the created object
    */
    public static EntityWithToMAggregation create ()
    {
        EntityWithToMAggregation object = new EntityWithToMAggregationImpl();


        return object;
    }

    /**
     *
     * Finds EntityWithToMAggregation object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityWithToMAggregation findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityWithToMAggregation object = (EntityWithToMAggregation) session.load(EntityWithToMAggregationImpl.class, id);
        return object;
    }

}