/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type CompositeEntityA.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.CompositeEntityA
 */
public abstract class CompositeEntityAFactory
{
   /**
    * Creates a(n) CompositeEntityA object.
    *
    * @param attribute2
    * @return CompositeEntityA the created object
    */
    public static CompositeEntityA create (int attribute2)
    {
        CompositeEntityA object = new CompositeEntityAImpl();

        object.setAttribute2 (attribute2);

        return object;
    }

    /**
     *
     * Finds CompositeEntityA object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
	public static CompositeEntityA findByPrimaryKey (org.hibernate.Session session, org.andromda.cartridges.hibernate.CompositeEntityAPK compositeEntityAPk)
        throws org.hibernate.HibernateException
    {
        CompositeEntityA object = (CompositeEntityA) session.load(CompositeEntityAImpl.class, compositeEntityAPk);
        return object;
    }

}