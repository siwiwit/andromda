/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type ImpliedListTarget.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.ImpliedListTarget
 */
public abstract class ImpliedListTargetFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) ImpliedListTarget object.
    *
    * @return ImpliedListTarget the created object
    */
    public static ImpliedListTarget create ()
    {
        ImpliedListTarget object = new ImpliedListTargetImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds ImpliedListTarget object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static ImpliedListTarget findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        ImpliedListTarget object = (ImpliedListTarget) session.load(ImpliedListTargetImpl.class, id);
        return object;
    }

}