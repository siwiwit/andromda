/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntitySixteen.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntitySixteen
 */
public abstract class EntitySixteenFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntitySixteen object.
    *
    * @return EntitySixteen the created object
    */
    public static EntitySixteen create ()
    {
        EntitySixteen object = new EntitySixteenImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntitySixteen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntitySixteen findByPrimaryKey (net.sf.hibernate.Session session, int one)
        throws net.sf.hibernate.HibernateException
    {
        EntitySixteen object = (EntitySixteen) session.load(EntitySixteenImpl.class, new java.lang.Integer(one));
        return object;
    }

}