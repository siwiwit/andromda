/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityTen.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityTen
 */
public abstract class EntityTenFactory
{
   /**
    * Creates a(n) EntityTen object.
    *
    * @return EntityTen the created object
    */
    public static EntityTen create ()
    {
        EntityTen object = new EntityTenImpl();


        return object;
    }

    /**
     *
     * Finds EntityTen object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityTen findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityTen object = (EntityTen) session.load(EntityTenImpl.class, id);
        return object;
    }

}