/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityWithPrivateAttribute.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityWithPrivateAttribute
 */
public abstract class EntityWithPrivateAttributeFactory
{
   /**
    * Creates a(n) EntityWithPrivateAttribute object.
    *
    * @param aPrivateAttribute
    * @param aPublicAttribute
    * @return EntityWithPrivateAttribute the created object
    */
    public static EntityWithPrivateAttribute create (java.lang.String aPrivateAttribute, java.lang.Long aPublicAttribute)
    {
        EntityWithPrivateAttribute object = new EntityWithPrivateAttributeImpl();

        object.setAPrivateAttribute (aPrivateAttribute);
        object.setAPublicAttribute (aPublicAttribute);

        return object;
    }

    /**
     *
     * Finds EntityWithPrivateAttribute object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityWithPrivateAttribute findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityWithPrivateAttribute object = (EntityWithPrivateAttribute) session.load(EntityWithPrivateAttributeImpl.class, id);
        return object;
    }

}