/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type ListEntityTarget.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.ListEntityTarget
 */
public abstract class ListEntityTargetFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) ListEntityTarget object.
    *
    * @return ListEntityTarget the created object
    */
    public static ListEntityTarget create ()
    {
        ListEntityTarget object = new ListEntityTargetImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds ListEntityTarget object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static ListEntityTarget findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        ListEntityTarget object = (ListEntityTarget) session.load(ListEntityTargetImpl.class, id);
        return object;
    }

}