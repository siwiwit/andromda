/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityFour.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityFour
 */
public abstract class EntityFourFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityFour object.
    *
    * @param enumTest
    * @return EntityFour the created object
    */
    public static EntityFour create (org.andromda.cartridges.hibernate.EnumerationOne enumTest)
    {
        EntityFour object = new EntityFourImpl();

        object.setEnumTest (enumTest);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityFour object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityFour findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        EntityFour object = (EntityFour) session.load(EntityFourImpl.class, id);
        return object;
    }

}