/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.EntityImplementingInterface
 */
public class EntityImplementingInterfaceImpl
    extends org.andromda.cartridges.hibernate.EntityImplementingInterface
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 7510214773445580208L;

    /**
     * @see org.andromda.cartridges.hibernate.EntityImplementingInterface#doSomething(int[])
     */
    public void doSomething(int[] someParam)
    {
        // @todo implement public void doSomething(int[] someParam)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.hibernate.EntityImplementingInterface.doSomething(int[] someParam) Not implemented!");
    }

}