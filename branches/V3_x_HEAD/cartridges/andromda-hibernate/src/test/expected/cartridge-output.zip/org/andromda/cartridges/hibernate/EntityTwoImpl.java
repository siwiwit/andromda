/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.EntityTwo
 */
public class EntityTwoImpl
    extends org.andromda.cartridges.hibernate.EntityTwo
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -2047029433980992227L;

    /**
     * @see org.andromda.cartridges.hibernate.EntityTwo#operationOne(java.lang.String)
     */
    public long operationOne(java.lang.String paramOne)
        throws org.andromda.cartridges.hibernate.TestException
    {
        // @todo implement public long operationOne(java.lang.String paramOne)
        return 0;
    }

    /**
     * @see org.andromda.cartridges.hibernate.EntityTwo#operationTwo(java.lang.Long)
     */
    public void operationTwo(java.lang.Long paramOne)
        throws org.andromda.cartridges.hibernate.TestException
    {
        // @todo implement public void operationTwo(java.lang.Long paramOne)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.hibernate.EntityTwo.operationTwo(java.lang.Long paramOne) Not implemented!");
    }

}