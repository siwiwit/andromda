/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityWithEmbeddedParts.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityWithEmbeddedParts
 */
public abstract class EntityWithEmbeddedPartsFactory
{
   /**
    * Creates a(n) EntityWithEmbeddedParts object.
    *
    * @param firstEmbedded
    * @param secondEmbedded
    * @param normalAttr
    * @param thirdEmbedded
    * @return EntityWithEmbeddedParts the created object
    */
    public static EntityWithEmbeddedParts create (org.andromda.cartridges.hibernate.TheEmbeddedDataType firstEmbedded, org.andromda.cartridges.hibernate.TheEmbeddedDataType secondEmbedded, java.lang.String normalAttr, org.andromda.cartridges.hibernate.TheEmbeddedImmutableType thirdEmbedded)
    {
        EntityWithEmbeddedParts object = new EntityWithEmbeddedPartsImpl();

        object.setFirstEmbedded (firstEmbedded);
        object.setSecondEmbedded (secondEmbedded);
        object.setNormalAttr (normalAttr);
        object.setThirdEmbedded (thirdEmbedded);

        return object;
    }

    /**
     *
     * Finds EntityWithEmbeddedParts object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityWithEmbeddedParts findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityWithEmbeddedParts object = (EntityWithEmbeddedParts) session.load(EntityWithEmbeddedPartsImpl.class, id);
        return object;
    }

}