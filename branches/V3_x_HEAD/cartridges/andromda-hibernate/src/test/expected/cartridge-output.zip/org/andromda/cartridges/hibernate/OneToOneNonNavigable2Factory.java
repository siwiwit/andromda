/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type OneToOneNonNavigable2.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.OneToOneNonNavigable2
 */
public abstract class OneToOneNonNavigable2Factory
{
   /**
    * Creates a(n) OneToOneNonNavigable2 object.
    *
    * @return OneToOneNonNavigable2 the created object
    */
    public static OneToOneNonNavigable2 create ()
    {
        OneToOneNonNavigable2 object = new OneToOneNonNavigable2Impl();


        return object;
    }

    /**
     *
     * Finds OneToOneNonNavigable2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static OneToOneNonNavigable2 findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        OneToOneNonNavigable2 object = (OneToOneNonNavigable2) session.load(OneToOneNonNavigable2Impl.class, id);
        return object;
    }

}