/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceInterfaceSubclass.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceInterfaceSubclass
 */
public abstract class InheritanceInterfaceSubclassFactory
{
   /**
    * Creates a(n) InheritanceInterfaceSubclass object.
    *
    * @param attributeISC2a
    * @param baseAttributeI1a
    * @return InheritanceInterfaceSubclass the created object
    */
    public static InheritanceInterfaceSubclass create (float attributeISC2a, float baseAttributeI1a)
    {
        InheritanceInterfaceSubclass object = new InheritanceInterfaceSubclassImpl();

        object.setAttributeISC2a (attributeISC2a);
        object.setBaseAttributeI1a (baseAttributeI1a);

        return object;
    }

    /**
     *
     * Finds InheritanceInterfaceSubclass object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceInterfaceSubclass findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        InheritanceInterfaceSubclass object = (InheritanceInterfaceSubclass) session.load(InheritanceInterfaceSubclassImpl.class, id);
        return object;
    }

}