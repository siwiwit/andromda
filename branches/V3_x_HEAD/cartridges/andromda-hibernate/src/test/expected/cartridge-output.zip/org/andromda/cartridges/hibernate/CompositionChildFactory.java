/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type CompositionChild.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.CompositionChild
 */
public abstract class CompositionChildFactory
{
   /**
    * Creates a(n) CompositionChild object.
    *
    * @return CompositionChild the created object
    */
    public static CompositionChild create ()
    {
        CompositionChild object = new CompositionChildImpl();


        return object;
    }

    /**
     *
     * Finds CompositionChild object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static CompositionChild findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        CompositionChild object = (CompositionChild) session.load(CompositionChildImpl.class, id);
        return object;
    }

}