/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type AbstractInterfaceRoot.
 * The Hibernate <em>interface</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.AbstractInterfaceRoot
 */
public abstract class AbstractInterfaceRootFactory {
    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds AbstractInterfaceRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static AbstractInterfaceRoot findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        AbstractInterfaceRoot object = (AbstractInterfaceRoot) session.load(AbstractInterfaceRootImpl.class, id);
        return object;
    }

}