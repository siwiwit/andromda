/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.SecondLevelEmbedded
 */
public class SecondLevelEmbeddedImpl
    extends org.andromda.cartridges.hibernate.SecondLevelEmbedded
    implements java.io.Serializable
{

    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = 2028848976374662445L;
    
}