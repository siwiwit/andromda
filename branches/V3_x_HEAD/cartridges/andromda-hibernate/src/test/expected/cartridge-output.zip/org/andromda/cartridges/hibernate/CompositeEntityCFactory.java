/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type CompositeEntityC.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.CompositeEntityC
 */
public abstract class CompositeEntityCFactory
{
   /**
    * Creates a(n) CompositeEntityC object.
    *
    * @param attribute3
    * @return CompositeEntityC the created object
    */
    public static CompositeEntityC create (float attribute3)
    {
        CompositeEntityC object = new CompositeEntityCImpl();

        object.setAttribute3 (attribute3);

        return object;
    }

    /**
     *
     * Finds CompositeEntityC object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
	public static CompositeEntityC findByPrimaryKey (org.hibernate.Session session, org.andromda.cartridges.hibernate.CompositeEntityCPK compositeEntityCPk)
        throws org.hibernate.HibernateException
    {
        CompositeEntityC object = (CompositeEntityC) session.load(CompositeEntityCImpl.class, compositeEntityCPk);
        return object;
    }

}