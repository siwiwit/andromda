/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityEleven.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityEleven
 */
public abstract class EntityElevenFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) EntityEleven object.
    *
    * @return EntityEleven the created object
    */
    public static EntityEleven create ()
    {
        EntityEleven object = new EntityElevenImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds EntityEleven object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityEleven findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        EntityEleven object = (EntityEleven) session.load(EntityElevenImpl.class, id);
        return object;
    }

}