/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntitySeven.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntitySeven
 */
public abstract class EntitySevenFactory
{
   /**
    * Creates a(n) EntitySeven object.
    *
    * @return EntitySeven the created object
    */
    public static EntitySeven create ()
    {
        EntitySeven object = new EntitySevenImpl();


        return object;
    }

    /**
     *
     * Finds EntitySeven object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntitySeven findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntitySeven object = (EntitySeven) session.load(EntitySevenImpl.class, id);
        return object;
    }

}