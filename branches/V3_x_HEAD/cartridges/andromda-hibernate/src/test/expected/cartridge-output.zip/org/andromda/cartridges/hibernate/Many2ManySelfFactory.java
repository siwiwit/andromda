/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type Many2ManySelf.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.Many2ManySelf
 */
public abstract class Many2ManySelfFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) Many2ManySelf object.
    *
    * @return Many2ManySelf the created object
    */
    public static Many2ManySelf create ()
    {
        Many2ManySelf object = new Many2ManySelfImpl();


        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds Many2ManySelf object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static Many2ManySelf findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        Many2ManySelf object = (Many2ManySelf) session.load(Many2ManySelfImpl.class, id);
        return object;
    }

}