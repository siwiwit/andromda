/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityThree.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityThree
 */
public abstract class EntityThreeFactory
{
   /**
    * Creates a(n) EntityThree object.
    *
    * @param testAttribute
    * @param testAttributeTwo
    * @return EntityThree the created object
    */
    public static EntityThree create (java.lang.Boolean testAttribute, java.lang.Long testAttributeTwo)
    {
        EntityThree object = new EntityThreeImpl();

        object.setTestAttribute (testAttribute);
        object.setTestAttributeTwo (testAttributeTwo);

        return object;
    }

    /**
     *
     * Finds EntityThree object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityThree findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityThree object = (EntityThree) session.load(EntityThreeImpl.class, id);
        return object;
    }

    /**
     * 
     *
     * Finds EntityThree instance(s) using a query.
     */
    public static java.util.Collection findByTestAttributes(org.hibernate.Session session, java.lang.Boolean testAttribute, java.lang.Long testAttributeTwo)
        throws org.hibernate.HibernateException
    {
        org.hibernate.Query query = session.createQuery("from org.andromda.cartridges.hibernate.EntityThree as entityThree where entityThree.testAttribute = :testAttribute and entityThree.testAttributeTwo = :testAttributeTwo");
        query.setParameter("testAttribute", testAttribute);
        query.setParameter("testAttributeTwo", testAttributeTwo);
        return query.list();
    }

}