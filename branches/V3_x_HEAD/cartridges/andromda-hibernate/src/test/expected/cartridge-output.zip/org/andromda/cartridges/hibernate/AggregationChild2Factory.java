/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type AggregationChild2.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.AggregationChild2
 */
public abstract class AggregationChild2Factory
{
   /**
    * Creates a(n) AggregationChild2 object.
    *
    * @return AggregationChild2 the created object
    */
    public static AggregationChild2 create ()
    {
        AggregationChild2 object = new AggregationChild2Impl();


        return object;
    }

    /**
     *
     * Finds AggregationChild2 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static AggregationChild2 findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        AggregationChild2 object = (AggregationChild2) session.load(AggregationChild2Impl.class, id);
        return object;
    }

}