/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceConcreteSubclass1.
 * The Hibernate <em>concrete</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceConcreteSubclass1
 */
public abstract class InheritanceConcreteSubclass1Factory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceConcreteSubclass1 object.
    *
    * @param attributeCCSC1a
    * @param baseAttributeCC1a
    * @return InheritanceConcreteSubclass1 the created object
    */
    public static InheritanceConcreteSubclass1 create (boolean attributeCCSC1a, int baseAttributeCC1a)
    {
        InheritanceConcreteSubclass1 object = new InheritanceConcreteSubclass1Impl();

        object.setAttributeCCSC1a (attributeCCSC1a);
        object.setBaseAttributeCC1a (baseAttributeCC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceConcreteSubclass1 object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceConcreteSubclass1 findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceConcreteSubclass1 object = (InheritanceConcreteSubclass1) session.load(InheritanceConcreteSubclass1Impl.class, id);
        return object;
    }

}