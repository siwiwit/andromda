/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.ServiceOne
 */
public class ServiceOneBeanImpl
    extends ServiceOneBean
    implements javax.ejb.SessionBean
{
    protected void handleOperationWithVoidReturnType (org.hibernate.Session session)
        throws org.andromda.cartridges.hibernate.TestException
    {
        // @todo implement public void operationWithVoidReturnType()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.hibernate.ServiceOne.operationWithVoidReturnType() Not implemented!");
    }

    protected java.lang.String handleOperationWithSimpleReturnType (org.hibernate.Session session)
        throws org.andromda.cartridges.hibernate.TestException
    {
        // @todo implement public java.lang.String operationWithSimpleReturnType()
        return null;
    }

    protected java.util.Collection handleOperationWithComplexReturnType (org.hibernate.Session session)
        throws org.andromda.cartridges.hibernate.TestException
    {
        // @todo implement public java.util.Collection operationWithComplexReturnType()
        return null;
    }

    protected java.lang.String handleSoperationWithSingleArgument (org.hibernate.Session session, java.util.Date argumentOne)
        throws org.andromda.cartridges.hibernate.TestException
    {
        // @todo implement public java.lang.String SoperationWithSingleArgument(java.util.Date argumentOne)
        return null;
    }

    protected void handleOperationWithMultipleArguments (org.hibernate.Session session, java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throws org.andromda.cartridges.hibernate.TestException
    {
        // @todo implement public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.hibernate.ServiceOne.operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument) Not implemented!");
    }

}