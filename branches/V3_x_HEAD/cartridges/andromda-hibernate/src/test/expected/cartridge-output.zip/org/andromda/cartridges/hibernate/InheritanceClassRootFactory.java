/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type InheritanceClassRoot.
 * The Hibernate <em>class</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.InheritanceClassRoot
 */
public abstract class InheritanceClassRootFactory {
   // ---------------- create method --------------------

   /**
    * Creates a(n) InheritanceClassRoot object.
    *
    * @param baseAttributeCSC1a
    * @return InheritanceClassRoot the created object
    */
    public static InheritanceClassRoot create (java.util.Date baseAttributeCSC1a)
    {
        InheritanceClassRoot object = new InheritanceClassRootImpl();

        object.setBaseAttributeCSC1a (baseAttributeCSC1a);

        return object;
    }

    // ---------------- finder methods  ----------------------

    /**
     *
     * Finds InheritanceClassRoot object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static InheritanceClassRoot findByPrimaryKey (net.sf.hibernate.Session session, java.lang.Long id)
        throws net.sf.hibernate.HibernateException
    {
        InheritanceClassRoot object = (InheritanceClassRoot) session.load(InheritanceClassRootImpl.class, id);
        return object;
    }

}