/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * Attention: Generated source! Do not modify by hand!
 */
package org.andromda.cartridges.hibernate;

/**
 * <p>
 * Factory class.
 * Is able to find and create objects of type EntityWithANonDataTypeAttribute.
 * The Hibernate <em>subclass</em> inheritance
 * strategy is followed.
 * Those can be described as follows:
 * </p>
 * @see org.andromda.cartridges.hibernate.EntityWithANonDataTypeAttribute
 */
public abstract class EntityWithANonDataTypeAttributeFactory
{
   /**
    * Creates a(n) EntityWithANonDataTypeAttribute object.
    *
    * @param nonDataTypeAttribute
    * @return EntityWithANonDataTypeAttribute the created object
    */
    public static EntityWithANonDataTypeAttribute create (org.andromda.cartridges.hibernate.NonDataType nonDataTypeAttribute)
    {
        EntityWithANonDataTypeAttribute object = new EntityWithANonDataTypeAttributeImpl();

        object.setNonDataTypeAttribute (nonDataTypeAttribute);

        return object;
    }

    /**
     *
     * Finds EntityWithANonDataTypeAttribute object by its primary key.
     * In Hibernate, this is just a call to load().
     *
     */
    public static EntityWithANonDataTypeAttribute findByPrimaryKey (org.hibernate.Session session, java.lang.Long id)
        throws org.hibernate.HibernateException
    {
        EntityWithANonDataTypeAttribute object = (EntityWithANonDataTypeAttribute) session.load(EntityWithANonDataTypeAttributeImpl.class, id);
        return object;
    }

}