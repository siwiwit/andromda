/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.hibernate;

/**
 * @see org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest
 */
public abstract class InheritanceBusinessMethodTestImpl
    extends org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -7929923826647052813L;

    /**
     * @see org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest#realMethod()
     */
    public boolean realMethod()
    {
        // @todo implement public boolean realMethod()
        return false;
    }

    /**
     * @see org.andromda.cartridges.hibernate.InheritanceBusinessMethodTest#abstractMethod()
     */
    public abstract byte abstractMethod();
}