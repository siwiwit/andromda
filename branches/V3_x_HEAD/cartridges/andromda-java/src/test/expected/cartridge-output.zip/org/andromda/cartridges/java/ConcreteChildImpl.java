/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.java;

/**
 * @see org.andromda.cartridges.java.ConcreteChild
 */
public class ConcreteChildImpl
    implements org.andromda.cartridges.java.ConcreteChild
{

    /**
     * @see org.andromda.cartridges.java.ConcreteChild#operation1(int)
     */
    public void operation1(int i)
    {
        // @todo implement public void operation1(int i)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.java.ConcreteChild.operation1(int i) Not implemented!");
    }

}
