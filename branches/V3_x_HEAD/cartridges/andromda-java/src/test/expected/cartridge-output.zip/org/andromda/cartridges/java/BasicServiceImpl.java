/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.java;

/**
 * @see org.andromda.cartridges.java.BasicService
 */
public class BasicServiceImpl
    implements org.andromda.cartridges.java.BasicService
{

    /**
     * @see org.andromda.cartridges.java.BasicService#operationWithVoidReturnType()
     */
    public void operationWithVoidReturnType()
        throws org.andromda.cartridges.java.TestException
    {
        //@todo implement public void operationWithVoidReturnType()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.java.BasicService.operationWithVoidReturnType() Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.java.BasicService#operationWithSimpleReturnType()
     */
    public java.lang.String operationWithSimpleReturnType()
        throws org.andromda.cartridges.java.TestException
    {
        //@todo implement public java.lang.String operationWithSimpleReturnType()
        return null;
    }

    /**
     * @see org.andromda.cartridges.java.BasicService#operationWithValueObjectReturnType()
     */
    public org.andromda.cartridges.java.TestValueObject operationWithValueObjectReturnType()
        throws org.andromda.cartridges.java.TestException
    {
        //@todo implement public org.andromda.cartridges.java.TestValueObject operationWithValueObjectReturnType()
        return null;
    }

    /**
     * @see org.andromda.cartridges.java.BasicService#operationWithSingleArgument(java.util.Date)
     */
    public java.lang.String[] operationWithSingleArgument(java.util.Date argumentOne)
        throws org.andromda.cartridges.java.TestException
    {
        //@todo implement public java.lang.String[] operationWithSingleArgument(java.util.Date argumentOne)
        return null;
    }

    /**
     * @see org.andromda.cartridges.java.BasicService#operationWithMultipleArguments(java.lang.Long, java.lang.Boolean, java.lang.String)
     */
    public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument)
        throws org.andromda.cartridges.java.TestException
    {
        //@todo implement public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.java.BasicService.operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument) Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.java.BasicService#operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String)
     */
    public org.andromda.cartridges.java.RelatedValueObject operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)
        throws org.andromda.cartridges.java.TestException
    {
        //@todo implement public org.andromda.cartridges.java.RelatedValueObject operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)
        return null;
    }

    /**
     * @see org.andromda.cartridges.java.BasicService#operationWithSingleComplexReturnTypeNoParameters()
     */
    public org.andromda.cartridges.java.RelatedValueObject operationWithSingleComplexReturnTypeNoParameters()
        throws org.andromda.cartridges.java.TestException
    {
        //@todo implement public org.andromda.cartridges.java.RelatedValueObject operationWithSingleComplexReturnTypeNoParameters()
        return null;
    }

    /**
     * @see org.andromda.cartridges.java.BasicService#operationWithArrayParameter(byte[])
     */
    public void operationWithArrayParameter(byte[] arrayParam)
        throws org.andromda.cartridges.java.TestException
    {
        //@todo implement public void operationWithArrayParameter(byte[] arrayParam)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.java.BasicService.operationWithArrayParameter(byte[] arrayParam) Not implemented!");
    }

}
