/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.webservice.test;


import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * JUnit test for web service {@link org.andromda.cartridges.webservice.BasicWebService}.
 * <p>
 *   NOTE: You must generate the client stubs for the org.andromda.cartridges.webservice.BasicWebService WSDL
 *   using axis's java2wsdl tool in order to run these tests.
 * </p>
 *
 * @see org.andromda.cartridges.webservice.BasicWebService
 */
public abstract class BasicWebServiceTest
    extends TestCase
{

    /**
     * Constructor for BasicWebServiceTest.
     *
     * @param testName name of the test.
     */
    public BasicWebServiceTest(String testName)
    {
        super(testName);
    }

    /**
     * Allows the BasicWebServiceTest to be run by JUnit as a suite.
     */
    public static Test suite()
    {
           return new TestSuite(BasicWebServiceTestImpl.class);
    }

    /**
     * Runs the BasicWebServiceTest test case.
     */
    public static void main(String[] args)
    {
        junit.textui.TestRunner.main(new String[] {BasicWebServiceTestImpl.class.getName()});
    }

    /**
     * The service under test.
     */
    private org.andromda.cartridges.webservice.test.BasicWebServiceSoapBindingStub service = null;

    /**
     * Returns the service under test {@link org.andromda.cartridges.webservice.test.BasicWebService}
     */
    protected org.andromda.cartridges.webservice.test.BasicWebServiceSoapBindingStub getService()
        throws Exception
    {
        if (this.username != null || this.password != null)
        {
            this.service = org.andromda.webservice.test.TestServiceLocator.instance().getBasicWebService(username, password);
        }
        else
        {
            this.service = org.andromda.webservice.test.TestServiceLocator.instance().getBasicWebService();
        }
        return this.service;
    }

    /**
     * The username providing access to the service under test.
     */
    private String username;

    /**
     * Sets the <code>username</code> providing access to the
     * service under test.
     *
     * @param username the username providing access to the
     *        service under test.
     */
    protected void setUsername(String username)
    {
        this.username = username;
    }

    /**
     * The password providing access to the service under test.
     */
    private String password;

    /**
     * Sets the <code>password</code> for the service under test.
     *
     * @param password the password for the service under test.
     */
    protected void setPassword(String password)
    {
        this.password = password;
    }

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithArrayParameter(byte[] arrayParam)}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithArrayParameter(byte[] arrayParam)
     */
    public void testOperationWithArrayParameter()
        throws java.lang.Exception
    {
        this.handleTestOperationWithArrayParameter();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithArrayParameter(byte[] arrayParam)}
     */
    protected abstract void handleTestOperationWithArrayParameter()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithComplexReturnType()}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithComplexReturnType()
     */
    public void testOperationWithComplexReturnType()
        throws java.lang.Exception
    {
        this.handleTestOperationWithComplexReturnType();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithComplexReturnType()}
     */
    protected abstract void handleTestOperationWithComplexReturnType()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithInheritedArrayTypes(org.andromda.cartridges.webservice.TestComplexType4[] param)}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithInheritedArrayTypes(org.andromda.cartridges.webservice.TestComplexType4[] param)
     */
    public void testOperationWithInheritedArrayTypes()
        throws java.lang.Exception
    {
        this.handleTestOperationWithInheritedArrayTypes();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithInheritedArrayTypes(org.andromda.cartridges.webservice.TestComplexType4[] param)}
     */
    protected abstract void handleTestOperationWithInheritedArrayTypes()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithInheritedTypes(org.andromda.cartridges.webservice.TestComplexType4 param)}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithInheritedTypes(org.andromda.cartridges.webservice.TestComplexType4 param)
     */
    public void testOperationWithInheritedTypes()
        throws java.lang.Exception
    {
        this.handleTestOperationWithInheritedTypes();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithInheritedTypes(org.andromda.cartridges.webservice.TestComplexType4 param)}
     */
    protected abstract void handleTestOperationWithInheritedTypes()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument, org.andromda.cartridges.webservice.TestEnumeration enumArgument)}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument, org.andromda.cartridges.webservice.TestEnumeration enumArgument)
     */
    public void testOperationWithMultipleArguments()
        throws java.lang.Exception
    {
        this.handleTestOperationWithMultipleArguments();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument, java.lang.String requiredArgument, org.andromda.cartridges.webservice.TestEnumeration enumArgument)}
     */
    protected abstract void handleTestOperationWithMultipleArguments()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithSimpleReturnType()}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSimpleReturnType()
     */
    public void testOperationWithSimpleReturnType()
        throws java.lang.Exception
    {
        this.handleTestOperationWithSimpleReturnType();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithSimpleReturnType()}
     */
    protected abstract void handleTestOperationWithSimpleReturnType()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithSingleArgument(java.util.Date argumentOne)}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleArgument(java.util.Date argumentOne)
     */
    public void testOperationWithSingleArgument()
        throws java.lang.Exception
    {
        this.handleTestOperationWithSingleArgument();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithSingleArgument(java.util.Date argumentOne)}
     */
    protected abstract void handleTestOperationWithSingleArgument()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithSingleComplexReturnTypeNoParameters()}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleComplexReturnTypeNoParameters()
     */
    public void testOperationWithSingleComplexReturnTypeNoParameters()
        throws java.lang.Exception
    {
        this.handleTestOperationWithSingleComplexReturnTypeNoParameters();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithSingleComplexReturnTypeNoParameters()}
     */
    protected abstract void handleTestOperationWithSingleComplexReturnTypeNoParameters()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)
     */
    public void testOperationWithSingleRelatedComplexTypeAndOneParameter()
        throws java.lang.Exception
    {
        this.handleTestOperationWithSingleRelatedComplexTypeAndOneParameter();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithSingleRelatedComplexTypeAndOneParameter(java.lang.String parameterOne)}
     */
    protected abstract void handleTestOperationWithSingleRelatedComplexTypeAndOneParameter()
        throws java.lang.Exception;

    /**
     * Tests: {@link org.andromda.cartridges.webservice.BasicWebService#operationWithVoidReturnType()}
     *
     * @see org.andromda.cartridges.webservice.BasicWebService#operationWithVoidReturnType()
     */
    public void testOperationWithVoidReturnType()
        throws java.lang.Exception
    {
        this.handleTestOperationWithVoidReturnType();
    }

    /**
     * Provides the actual test implementation for {@link #operationWithVoidReturnType()}
     */
    protected abstract void handleTestOperationWithVoidReturnType()
        throws java.lang.Exception;

}