/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.webservice.test;

/**
 * @see org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsTest
 */
public class ServiceWithExposedOperationsTestImpl
    extends ServiceWithExposedOperationsTest
{

    /**
     * Constructor for ServiceWithExposedOperationsTest.
     *
     * @param testName name of the test.
     */
    public ServiceWithExposedOperationsTestImpl(String testName)
    {
        super(testName);
    }

    /**
     * @see org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsTest#testExposedOperation()
     */
    public void handleTestExposedOperation()
        throws Exception
    {
        this.getService().exposedOperation();
        // @todo implement org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsTest.handleTestExposedOperation()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsTest#testTestUniqueName()
     */
    public void handleTestTestUniqueName()
        throws Exception
    {
        this.getService().testUniqueName();
        // @todo implement org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsTest.handleTestTestUniqueName()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsTest#testTestUniqueName()
     */
    public void handleTestTestUniqueName()
        throws Exception
    {
        java.lang.Long paramOne = null;
        this.getService().testUniqueName(paramOne);
        // @todo implement org.andromda.cartridges.webservice.test.ServiceWithExposedOperationsTest.handleTestTestUniqueName()
    }

}