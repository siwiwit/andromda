/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.webservice.test;

/**
 * @see org.andromda.cartridges.webservice.test.ServiceWithCollectionParametersTest
 */
public class ServiceWithCollectionParametersTestImpl
    extends ServiceWithCollectionParametersTest
{

    /**
     * Constructor for ServiceWithCollectionParametersTest.
     *
     * @param testName name of the test.
     */
    public ServiceWithCollectionParametersTestImpl(String testName)
    {
        super(testName);
    }

    /**
     * @see org.andromda.cartridges.webservice.test.ServiceWithCollectionParametersTest#testOperationWithCollectionReturnType()
     */
    public void handleTestOperationWithCollectionReturnType()
        throws Exception
    {
        this.getService().operationWithCollectionReturnType();
        // @todo implement org.andromda.cartridges.webservice.test.ServiceWithCollectionParametersTest.handleTestOperationWithCollectionReturnType()
    }

    /**
     * @see org.andromda.cartridges.webservice.test.ServiceWithCollectionParametersTest#testOperationWithCollectionTypeParameter()
     */
    public void handleTestOperationWithCollectionTypeParameter()
        throws Exception
    {
        java.util.Collection invalidParameter = null;
        this.getService().operationWithCollectionTypeParameter(invalidParameter);
        // @todo implement org.andromda.cartridges.webservice.test.ServiceWithCollectionParametersTest.handleTestOperationWithCollectionTypeParameter()
    }

}