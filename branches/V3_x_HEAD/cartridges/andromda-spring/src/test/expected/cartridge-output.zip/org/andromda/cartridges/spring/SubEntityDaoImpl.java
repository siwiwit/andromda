/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see org.andromda.cartridges.spring.SubEntity
 */
public class SubEntityDaoImpl
    extends org.andromda.cartridges.spring.SubEntityDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#toSubEntityVO2(org.andromda.cartridges.spring.SubEntity, org.andromda.cartridges.spring.SubEntityVO2)
     */
    public void toSubEntityVO2(
        org.andromda.cartridges.spring.SubEntity sourceEntity,
        org.andromda.cartridges.spring.SubEntityVO2 targetVO)
    {
        // @todo verify behavior of toSubEntityVO2
        super.toSubEntityVO2(sourceEntity, targetVO);
    }


    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#toSubEntityVO2(org.andromda.cartridges.spring.SubEntity)
     */
    public org.andromda.cartridges.spring.SubEntityVO2 toSubEntityVO2(final org.andromda.cartridges.spring.SubEntity entity)
    {
        // @todo verify behavior of toSubEntityVO2
        return super.toSubEntityVO2(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private org.andromda.cartridges.spring.SubEntity loadSubEntityFromSubEntityVO2(org.andromda.cartridges.spring.SubEntityVO2 subEntityVO2)
    {
        // @todo implement loadSubEntityFromSubEntityVO2
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.loadSubEntityFromSubEntityVO2(org.andromda.cartridges.spring.SubEntityVO2) not yet implemented.");

        /* A typical implementation looks like this:
        org.andromda.cartridges.spring.SubEntity subEntity = this.load(subEntityVO2.getId());
        if (subEntity == null)
        {
            subEntity = org.andromda.cartridges.spring.SubEntity.Factory.newInstance();
        }
        return subEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#subEntityVO2ToEntity(org.andromda.cartridges.spring.SubEntityVO2)
     */
    public org.andromda.cartridges.spring.SubEntity subEntityVO2ToEntity(org.andromda.cartridges.spring.SubEntityVO2 subEntityVO2)
    {
        // @todo verify behavior of subEntityVO2ToEntity
        org.andromda.cartridges.spring.SubEntity entity = this.loadSubEntityFromSubEntityVO2(subEntityVO2);
        this.subEntityVO2ToEntity(subEntityVO2, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#subEntityVO2ToEntity(org.andromda.cartridges.spring.SubEntityVO2, org.andromda.cartridges.spring.SubEntity)
     */
    public void subEntityVO2ToEntity(
        org.andromda.cartridges.spring.SubEntityVO2 sourceVO,
        org.andromda.cartridges.spring.SubEntity targetEntity,
        boolean copyIfNull)
    {
        // @todo verify behavior of subEntityVO2ToEntity
        super.subEntityVO2ToEntity(sourceVO, targetEntity, copyIfNull);
    }

    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#toSubEntityVO1(org.andromda.cartridges.spring.SubEntity, org.andromda.cartridges.spring.SubEntityVO1)
     */
    public void toSubEntityVO1(
        org.andromda.cartridges.spring.SubEntity sourceEntity,
        org.andromda.cartridges.spring.SubEntityVO1 targetVO)
    {
        // @todo verify behavior of toSubEntityVO1
        super.toSubEntityVO1(sourceEntity, targetVO);
    }


    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#toSubEntityVO1(org.andromda.cartridges.spring.SubEntity)
     */
    public org.andromda.cartridges.spring.SubEntityVO1 toSubEntityVO1(final org.andromda.cartridges.spring.SubEntity entity)
    {
        // @todo verify behavior of toSubEntityVO1
        return super.toSubEntityVO1(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private org.andromda.cartridges.spring.SubEntity loadSubEntityFromSubEntityVO1(org.andromda.cartridges.spring.SubEntityVO1 subEntityVO1)
    {
        // @todo implement loadSubEntityFromSubEntityVO1
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.loadSubEntityFromSubEntityVO1(org.andromda.cartridges.spring.SubEntityVO1) not yet implemented.");

        /* A typical implementation looks like this:
        org.andromda.cartridges.spring.SubEntity subEntity = this.load(subEntityVO1.getId());
        if (subEntity == null)
        {
            subEntity = org.andromda.cartridges.spring.SubEntity.Factory.newInstance();
        }
        return subEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#subEntityVO1ToEntity(org.andromda.cartridges.spring.SubEntityVO1)
     */
    public org.andromda.cartridges.spring.SubEntity subEntityVO1ToEntity(org.andromda.cartridges.spring.SubEntityVO1 subEntityVO1)
    {
        // @todo verify behavior of subEntityVO1ToEntity
        org.andromda.cartridges.spring.SubEntity entity = this.loadSubEntityFromSubEntityVO1(subEntityVO1);
        this.subEntityVO1ToEntity(subEntityVO1, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.SubEntityDao#subEntityVO1ToEntity(org.andromda.cartridges.spring.SubEntityVO1, org.andromda.cartridges.spring.SubEntity)
     */
    public void subEntityVO1ToEntity(
        org.andromda.cartridges.spring.SubEntityVO1 sourceVO,
        org.andromda.cartridges.spring.SubEntity targetEntity,
        boolean copyIfNull)
    {
        // @todo verify behavior of subEntityVO1ToEntity
        super.subEntityVO1ToEntity(sourceVO, targetEntity, copyIfNull);
    }

}