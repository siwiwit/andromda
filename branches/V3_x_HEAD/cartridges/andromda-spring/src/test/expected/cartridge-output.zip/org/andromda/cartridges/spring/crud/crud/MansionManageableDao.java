/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public interface MansionManageableDao
{
    public org.andromda.cartridges.spring.crud.Mansion create(java.lang.String name, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] houses, java.lang.Long room, java.lang.Long[] gardens, java.lang.Long mansion);

    public org.andromda.cartridges.spring.crud.Mansion readById(java.lang.Long id);

    public java.util.List read(java.lang.String name, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] houses, java.lang.Long room, java.lang.Long[] gardens, java.lang.Long mansion);

    public java.util.List readAll();

    public java.util.Map readBackingLists();

    public org.andromda.cartridges.spring.crud.Mansion update(java.lang.String name, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] houses, java.lang.Long room, java.lang.Long[] gardens, java.lang.Long mansion);

    public void delete(java.lang.Long[] ids);

}