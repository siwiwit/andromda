/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public class MansionValueObject
    extends org.andromda.cartridges.spring.crud.crud.HouseValueObject
{
    private java.lang.String name;

    public java.lang.String getName()
    {
        return this.name;
    }

    public void setName(java.lang.String name)
    {
        this.name = name;
    }

    private java.lang.Long[] houses;

    public java.lang.Long[] getHouses()
    {
        return this.houses;
    }

    public void setHouses(java.lang.Long[] houses)
    {
        this.houses = houses;
    }

}