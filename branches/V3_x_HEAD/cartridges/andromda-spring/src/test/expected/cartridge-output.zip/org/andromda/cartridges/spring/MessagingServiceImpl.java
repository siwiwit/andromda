/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.MessagingService
 */
public class MessagingServiceImpl
    extends org.andromda.cartridges.spring.MessagingServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.MessagingService#outgoingMessageOperation1(org.andromda.cartridges.spring.TestValueObject)
     */
    protected void handleOutgoingMessageOperation1(javax.jms.Session session, org.andromda.cartridges.spring.TestValueObject valueObject)
        throws java.lang.Exception
    {
        // @todo implement protected void handleOutgoingMessageOperation1(javax.jms.Session session, org.andromda.cartridges.spring.TestValueObject valueObject)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.MessagingService.handleOutgoingMessageOperation1(javax.jms.Session session, org.andromda.cartridges.spring.TestValueObject valueObject) Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.MessagingService#outgoingMessageOperation2(java.lang.String, java.lang.Long)
     */
    protected void handleOutgoingMessageOperation2(javax.jms.Session session, java.lang.String param1, java.lang.Long param2)
        throws java.lang.Exception
    {
        // @todo implement protected void handleOutgoingMessageOperation2(javax.jms.Session session, java.lang.String param1, java.lang.Long param2)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.MessagingService.handleOutgoingMessageOperation2(javax.jms.Session session, java.lang.String param1, java.lang.Long param2) Not implemented!");
    }

    /**
     * @see org.andromda.cartridges.spring.MessagingService#incomingMessageOperation1(javax.jms.Message message)
     */
    protected org.andromda.cartridges.spring.TestValueObject handleIncomingMessageOperation1(javax.jms.Message message)
        throws java.lang.Exception
    {
        // @todo implement protected org.andromda.cartridges.spring.TestValueObject handleIncomingMessageOperation1(javax.jms.Message message)
        return null;
    }

    /**
     * @see org.andromda.cartridges.spring.MessagingService#incomingMessageOperation2(java.lang.String)
     */
    protected java.lang.Long handleIncomingMessageOperation2(java.lang.String param1)
        throws java.lang.Exception
    {
        // @todo implement protected java.lang.Long handleIncomingMessageOperation2(java.lang.String param1)
        return null;
    }

    /**
     * @see org.andromda.cartridges.spring.MessagingService#incomingTopic1MessageOperation(java.lang.String)
     */
    protected void handleIncomingTopic1MessageOperation(java.lang.String test)
        throws java.lang.Exception
    {
        // @todo implement protected void handleIncomingTopic1MessageOperation(java.lang.String test)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.MessagingService.handleIncomingTopic1MessageOperation(java.lang.String test) Not implemented!");
    }

}