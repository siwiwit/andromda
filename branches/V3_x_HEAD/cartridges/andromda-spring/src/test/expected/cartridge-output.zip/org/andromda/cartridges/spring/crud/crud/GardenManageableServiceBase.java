/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public final class GardenManageableServiceBase
    implements GardenManageableService
{
    private org.andromda.cartridges.spring.crud.crud.GardenManageableDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.crud.GardenManageableDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.crud.GardenManageableDao getDao()
    {
        return this.dao;
    }

    public void create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception
    {
        if (intWrapper == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'intWrapper' can not be null");
        }

        if (room == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'room' can not be null");
        }

        dao.create(integer, intWrapper, id, room, houses);
    }

    public java.util.List read(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception
    {
        return toValueObjects(dao.read(integer, intWrapper, id, room, houses));
    }

    public java.util.List readAll()
        throws Exception
    {
        return toValueObjects(dao.readAll());
    }

    public java.util.Map readBackingLists()
        throws Exception
    {
        return getDao().readBackingLists();
    }

    public void update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception
    {
        if (intWrapper == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'intWrapper' can not be null");
        }

        if (id == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'id' can not be null");
        }

        if (room == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses) - 'room' can not be null");
        }

        dao.update(integer, intWrapper, id, room, houses);
    }

    public void delete(java.lang.Long[] ids)
        throws Exception
    {
        if (ids == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.GardenManageableService.delete(java.lang.Long[] ids) - 'ids' can not be null");
        }

        dao.delete(ids);
    }


    private java.util.List toValueObjects(java.util.Collection entities)
    {
        final java.util.List list = new java.util.ArrayList();

        for (java.util.Iterator iterator = entities.iterator(); iterator.hasNext();)
        {
            list.add(toValueObject((org.andromda.cartridges.spring.crud.Garden)iterator.next()));
        }

        return list;
    }

    private org.andromda.cartridges.spring.crud.crud.GardenValueObject toValueObject(org.andromda.cartridges.spring.crud.Garden entity)
    {
        final org.andromda.cartridges.spring.crud.crud.GardenValueObject valueObject = new org.andromda.cartridges.spring.crud.crud.GardenValueObject();

        valueObject.setInteger(entity.getInteger());
        valueObject.setIntWrapper(entity.getIntWrapper());
        valueObject.setId(entity.getId());

        final org.andromda.cartridges.spring.crud.Room room = entity.getRoom();
        if (room != null)
        {
            valueObject.setRoom(room.getSpecificId());
        }
        final java.util.Collection houses = entity.getHouses();
        if (houses.isEmpty())
        {
            valueObject.setHouses(java.util.Collections.EMPTY_LIST);
        }
        else
        {
            final java.util.List values = new java.util.ArrayList();
            for (final java.util.Iterator iterator = houses.iterator(); iterator.hasNext();)
            {
                final org.andromda.cartridges.spring.crud.House element = (org.andromda.cartridges.spring.crud.House)iterator.next();
                values.add(element.getId());
            }
            valueObject.setHouses(values);
        }

        return valueObject;
    }
}
