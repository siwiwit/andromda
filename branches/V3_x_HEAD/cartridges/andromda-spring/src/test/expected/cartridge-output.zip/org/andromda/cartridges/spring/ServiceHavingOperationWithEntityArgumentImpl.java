/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ServiceHavingOperationWithEntityArgument
 */
public class ServiceHavingOperationWithEntityArgumentImpl
    extends org.andromda.cartridges.spring.ServiceHavingOperationWithEntityArgumentBase
{

    /**
     * @see org.andromda.cartridges.spring.ServiceHavingOperationWithEntityArgument#operationHavingEntity(org.andromda.cartridges.spring.EntityFour)
     */
    protected void handleOperationHavingEntity(org.andromda.cartridges.spring.EntityFour entity)
        throws java.lang.Exception
    {
        // @todo implement protected void handleOperationHavingEntity(org.andromda.cartridges.spring.EntityFour entity)
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.ServiceHavingOperationWithEntityArgument.handleOperationHavingEntity(org.andromda.cartridges.spring.EntityFour entity) Not implemented!");
    }

}