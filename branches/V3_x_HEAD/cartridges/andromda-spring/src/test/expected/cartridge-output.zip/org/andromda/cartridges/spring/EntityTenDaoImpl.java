/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see org.andromda.cartridges.spring.EntityTen
 */
public class EntityTenDaoImpl
    extends org.andromda.cartridges.spring.EntityTenDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#toValueObjectTen(org.andromda.cartridges.spring.EntityTen, org.andromda.cartridges.spring.ValueObjectTen)
     */
    public void toValueObjectTen(
        org.andromda.cartridges.spring.EntityTen sourceEntity,
        org.andromda.cartridges.spring.ValueObjectTen targetVO)
    {
        // @todo verify behavior of toValueObjectTen
        super.toValueObjectTen(sourceEntity, targetVO);
    }


    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#toValueObjectTen(org.andromda.cartridges.spring.EntityTen)
     */
    public org.andromda.cartridges.spring.ValueObjectTen toValueObjectTen(final org.andromda.cartridges.spring.EntityTen entity)
    {
        // @todo verify behavior of toValueObjectTen
        return super.toValueObjectTen(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private org.andromda.cartridges.spring.EntityTen loadEntityTenFromValueObjectTen(org.andromda.cartridges.spring.ValueObjectTen valueObjectTen)
    {
        // @todo implement loadEntityTenFromValueObjectTen
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.loadEntityTenFromValueObjectTen(org.andromda.cartridges.spring.ValueObjectTen) not yet implemented.");

        /* A typical implementation looks like this:
        org.andromda.cartridges.spring.EntityTen entityTen = this.load(valueObjectTen.getId());
        if (entityTen == null)
        {
            entityTen = org.andromda.cartridges.spring.EntityTen.Factory.newInstance();
        }
        return entityTen;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#valueObjectTenToEntity(org.andromda.cartridges.spring.ValueObjectTen)
     */
    public org.andromda.cartridges.spring.EntityTen valueObjectTenToEntity(org.andromda.cartridges.spring.ValueObjectTen valueObjectTen)
    {
        // @todo verify behavior of valueObjectTenToEntity
        org.andromda.cartridges.spring.EntityTen entity = this.loadEntityTenFromValueObjectTen(valueObjectTen);
        this.valueObjectTenToEntity(valueObjectTen, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.EntityTenDao#valueObjectTenToEntity(org.andromda.cartridges.spring.ValueObjectTen, org.andromda.cartridges.spring.EntityTen)
     */
    public void valueObjectTenToEntity(
        org.andromda.cartridges.spring.ValueObjectTen sourceVO,
        org.andromda.cartridges.spring.EntityTen targetEntity,
        boolean copyIfNull)
    {
        // @todo verify behavior of valueObjectTenToEntity
        super.valueObjectTenToEntity(sourceVO, targetEntity, copyIfNull);
    }

}