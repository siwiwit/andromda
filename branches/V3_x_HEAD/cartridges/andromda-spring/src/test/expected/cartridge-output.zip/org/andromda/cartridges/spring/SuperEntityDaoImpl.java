/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;
/**
 * @see org.andromda.cartridges.spring.SuperEntity
 */
public class SuperEntityDaoImpl
    extends org.andromda.cartridges.spring.SuperEntityDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO2(org.andromda.cartridges.spring.SuperEntity, org.andromda.cartridges.spring.SuperEntityVO2)
     */
    public void toSuperEntityVO2(
        org.andromda.cartridges.spring.SuperEntity source,
        org.andromda.cartridges.spring.SuperEntityVO2 target)
    {
        // @todo verify behavior of toSuperEntityVO2
        super.toSuperEntityVO2(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO2(org.andromda.cartridges.spring.SuperEntity)
     */
    public org.andromda.cartridges.spring.SuperEntityVO2 toSuperEntityVO2(final org.andromda.cartridges.spring.SuperEntity entity)
    {
        // @todo verify behavior of toSuperEntityVO2
        return super.toSuperEntityVO2(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private org.andromda.cartridges.spring.SuperEntity loadSuperEntityFromSuperEntityVO2(org.andromda.cartridges.spring.SuperEntityVO2 superEntityVO2)
    {
        // @todo implement loadSuperEntityFromSuperEntityVO2
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.loadSuperEntityFromSuperEntityVO2(org.andromda.cartridges.spring.SuperEntityVO2) not yet implemented.");

        /* A typical implementation looks like this:
        org.andromda.cartridges.spring.SuperEntity superEntity = this.load(superEntityVO2.getId());
        if (superEntity == null)
        {
            superEntity = org.andromda.cartridges.spring.SuperEntity.Factory.newInstance();
        }
        return superEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO2ToEntity(org.andromda.cartridges.spring.SuperEntityVO2)
     */
    public org.andromda.cartridges.spring.SuperEntity superEntityVO2ToEntity(org.andromda.cartridges.spring.SuperEntityVO2 superEntityVO2)
    {
        // @todo verify behavior of superEntityVO2ToEntity
        org.andromda.cartridges.spring.SuperEntity entity = this.loadSuperEntityFromSuperEntityVO2(superEntityVO2);
        this.superEntityVO2ToEntity(superEntityVO2, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO2ToEntity(org.andromda.cartridges.spring.SuperEntityVO2, org.andromda.cartridges.spring.SuperEntity)
     */
    public void superEntityVO2ToEntity(
        org.andromda.cartridges.spring.SuperEntityVO2 source,
        org.andromda.cartridges.spring.SuperEntity target,
        boolean copyIfNull)
    {
        // @todo verify behavior of superEntityVO2ToEntity
        super.superEntityVO2ToEntity(source, target, copyIfNull);
    }

    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO1(org.andromda.cartridges.spring.SuperEntity, org.andromda.cartridges.spring.SuperEntityVO1)
     */
    public void toSuperEntityVO1(
        org.andromda.cartridges.spring.SuperEntity source,
        org.andromda.cartridges.spring.SuperEntityVO1 target)
    {
        // @todo verify behavior of toSuperEntityVO1
        super.toSuperEntityVO1(source, target);
    }


    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#toSuperEntityVO1(org.andromda.cartridges.spring.SuperEntity)
     */
    public org.andromda.cartridges.spring.SuperEntityVO1 toSuperEntityVO1(final org.andromda.cartridges.spring.SuperEntity entity)
    {
        // @todo verify behavior of toSuperEntityVO1
        return super.toSuperEntityVO1(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store,
     * a new, blank entity is created
     */
    private org.andromda.cartridges.spring.SuperEntity loadSuperEntityFromSuperEntityVO1(org.andromda.cartridges.spring.SuperEntityVO1 superEntityVO1)
    {
        // @todo implement loadSuperEntityFromSuperEntityVO1
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.loadSuperEntityFromSuperEntityVO1(org.andromda.cartridges.spring.SuperEntityVO1) not yet implemented.");

        /* A typical implementation looks like this:
        org.andromda.cartridges.spring.SuperEntity superEntity = this.load(superEntityVO1.getId());
        if (superEntity == null)
        {
            superEntity = org.andromda.cartridges.spring.SuperEntity.Factory.newInstance();
        }
        return superEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO1ToEntity(org.andromda.cartridges.spring.SuperEntityVO1)
     */
    public org.andromda.cartridges.spring.SuperEntity superEntityVO1ToEntity(org.andromda.cartridges.spring.SuperEntityVO1 superEntityVO1)
    {
        // @todo verify behavior of superEntityVO1ToEntity
        org.andromda.cartridges.spring.SuperEntity entity = this.loadSuperEntityFromSuperEntityVO1(superEntityVO1);
        this.superEntityVO1ToEntity(superEntityVO1, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.SuperEntityDao#superEntityVO1ToEntity(org.andromda.cartridges.spring.SuperEntityVO1, org.andromda.cartridges.spring.SuperEntity)
     */
    public void superEntityVO1ToEntity(
        org.andromda.cartridges.spring.SuperEntityVO1 source,
        org.andromda.cartridges.spring.SuperEntity target,
        boolean copyIfNull)
    {
        // @todo verify behavior of superEntityVO1ToEntity
        super.superEntityVO1ToEntity(source, target, copyIfNull);
    }

}