/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public interface GardenManageableDao
{
    public org.andromda.cartridges.spring.crud.Garden create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses);

    public org.andromda.cartridges.spring.crud.Garden readById(java.lang.Long id);

    public java.util.List read(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses);

    public java.util.List readAll();

    public java.util.Map readBackingLists();

    public org.andromda.cartridges.spring.crud.Garden update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses);

    public void delete(java.lang.Long[] ids);

}