package org.andromda.spring;

/**
 * Stores the information necessary to performa a property search.
 * 
 * @see PropertySearch
 */
public class Search
    implements java.io.Serializable
{
    private static final long serialVersionUID = -8060934999137370126L;
    
    /**
     * Constructs the search object.
     * 
     * @param parameters the parameters to use.
     * @param pageNumber the page number (if paging results).
     * @param pageSize the page size (if paging results).
     * @param eagerFetching whether or not the search will eagerly fetch the associations included in the search.
     */
    public Search(SearchParameter[] parameters, int pageNumber, int pageSize, boolean eagerFetching)
    {
        this.pageNumber = pageNumber;
        this.pageSize = pageSize;
        this.parameters = parameters;
        this.eagerFetching = eagerFetching;
    }
    
    /**
     * Constructs the search object.
     * 
     * @param parameters the parameters to use.
     * @param pageNumber the page number (if paging results).
     * @param pageSize the page size (if paging results).
     */
    public Search(SearchParameter[] parameters, int pageNumber, int pageSize)
    {
        this(parameters, pageNumber, pageSize, false);
    }
    
    
    /**
     * Constructs the search object.
     * 
     * @param parameters the parameters to use.
     */
    public Search(SearchParameter[] parameters)
    {
        this(parameters, -1, -1, false);
    }
    
    /**
     * Constructs the search object.
     * 
     * @param parameters the parameters to use.
     */
    public Search(SearchParameter[] parameters, boolean eagerFetching)
    {
        this(parameters, -1, -1, eagerFetching);
    }

    private int pageNumber;
   
    /**
     * Gets the page number (if paging the results).
     * 
     * @return the page number.
     */
    public int getPageNumber()
    {
        return this.pageNumber;
    }
    
    /**
     * Sets the page number (if paging the results).
     * 
     * @return the page number.
     */
    public void setPageNumber(int pageNumber)
    {
        this.pageNumber = pageNumber;
    }
    
    private int pageSize;
    
    /**
     * Gets the size of the page (if paging the results).
     * 
     * @return the page size.
     */
    public int getPageSize()
    {
        return this.pageSize;
    }
    
    /**
     * Sets the size of the page (if paging the results).
     * 
     * @param pageSize the page size.
     */
    public void setPageSize(int pageSize)
    {
        this.pageSize = pageSize;
    }

    private SearchParameter[] parameters;

    /**
     * Gets the search parameters for this search object.
     * 
     * @param the search parameters.
     */
    public SearchParameter[] getParameters()
    {
        return this.parameters;
    }

    /**
     * Sets the search parameters for this search object.
     * 
     * @param parameters
     */
    public void setParameters(SearchParameter[] parameters)
    {
        this.parameters = parameters;
    }
    
    private boolean eagerFetching;

    /**
     * Whether or not eager fetching is enabled (if it is enabled, all associations
     * queried will be fetched eagerly).
     * 
     * @return true/false
     */
    public boolean isEagerFetching()
    {
        return eagerFetching;
    }

    /**
     * Sets whether or not eager fetching is enabled (if it is enabled, all associations
     * queried will be fetched eagerly).
     * 
     * @param eagerFetching whether or not to eager fetch the results.
     */
    public void setEagerFetching(boolean eagerFetching)
    {
        this.eagerFetching = eagerFetching;
    }   
}