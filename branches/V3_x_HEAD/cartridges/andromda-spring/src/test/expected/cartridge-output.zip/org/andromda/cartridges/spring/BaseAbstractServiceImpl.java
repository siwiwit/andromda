/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.BaseAbstractService
 */
public abstract class BaseAbstractServiceImpl
    extends org.andromda.cartridges.spring.BaseAbstractServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.BaseAbstractService#operationOne()
     */
    protected  java.lang.String handleOperationOne()
        throws java.lang.Exception
    {
        // @todo implement protected  java.lang.String handleOperationOne()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.BaseAbstractService.handleOperationOne() Not implemented!");
    }

}