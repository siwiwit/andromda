/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ServiceTwo
 */
public class ServiceTwoImpl
    extends org.andromda.cartridges.spring.ServiceTwoBase
{

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationOne()
     */
    protected org.andromda.cartridges.spring.TestValueObject handleOperationOne()
        throws java.lang.Exception
    {
        // @todo implement protected org.andromda.cartridges.spring.TestValueObject handleOperationOne()
        return null;
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationThree()
     */
    protected boolean handleOperationThree()
        throws java.lang.Exception
    {
        // @todo implement protected boolean handleOperationThree()
        return false;
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#doSomething()
     */
    protected java.lang.String[] handleDoSomething()
        throws java.lang.Exception
    {
        // @todo implement protected java.lang.String[] handleDoSomething()
        return null;
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceTwo#operationTwo()
     */
    protected java.lang.String handleOperationTwo()
        throws java.lang.Exception
    {
        // @todo implement protected java.lang.String handleOperationTwo()
        return null;
    }

}