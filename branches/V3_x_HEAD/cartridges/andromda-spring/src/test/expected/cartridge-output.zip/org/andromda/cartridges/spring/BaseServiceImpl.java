/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.BaseService
 */
public class BaseServiceImpl
    extends org.andromda.cartridges.spring.BaseServiceBase
{

    /**
     * @see org.andromda.cartridges.spring.BaseService#baseOperation()
     */
    protected  java.lang.String handleBaseOperation()
        throws java.lang.Exception
    {
        // @todo implement protected  java.lang.String handleBaseOperation()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.BaseService.handleBaseOperation() Not implemented!");
    }

}