/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.ChildEntity
 */
public class ChildEntityDaoImpl
    extends org.andromda.cartridges.spring.ChildEntityDaoBase
{
    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#toChildEntityVO(org.andromda.cartridges.spring.ChildEntity, org.andromda.cartridges.spring.ChildEntityVO)
     */
    public void toChildEntityVO(
        org.andromda.cartridges.spring.ChildEntity sourceEntity, 
        org.andromda.cartridges.spring.ChildEntityVO targetVO)
    {
        // @todo verify behavior of toChildEntityVO
        super.toChildEntityVO(sourceEntity, targetVO);
        // WARNING! No conversion for targetVO.misMatchedAttribute (can't convert sourceEntity.getMisMatchedAttribute():java.sql.Timestamp to java.lang.Float
    }


    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#toChildEntityVO(org.andromda.cartridges.spring.ChildEntity)
     */
    public org.andromda.cartridges.spring.ChildEntityVO toChildEntityVO(final org.andromda.cartridges.spring.ChildEntity entity)
    {
        // @todo verify behavior of toChildEntityVO
        return super.toChildEntityVO(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store, 
     * a new, blank entity is created
     */
    private org.andromda.cartridges.spring.ChildEntity loadChildEntityFromChildEntityVO(org.andromda.cartridges.spring.ChildEntityVO childEntityVO)
    {
        // @todo implement loadChildEntityFromChildEntityVO
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.loadChildEntityFromChildEntityVO(org.andromda.cartridges.spring.ChildEntityVO) not yet implemented.");

        /* A typical implementation looks like this:        
        org.andromda.cartridges.spring.ChildEntity childEntity = this.load(childEntityVO.getId());
        if (childEntity == null)
        {
            childEntity = org.andromda.cartridges.spring.ChildEntity.Factory.newInstance();
        }
        return childEntity;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#childEntityVOToEntity(org.andromda.cartridges.spring.ChildEntityVO)
     */
    public org.andromda.cartridges.spring.ChildEntity childEntityVOToEntity(org.andromda.cartridges.spring.ChildEntityVO childEntityVO)
    {
        // @todo verify behavior of childEntityVOToEntity
        org.andromda.cartridges.spring.ChildEntity entity = this.loadChildEntityFromChildEntityVO(childEntityVO);
        this.childEntityVOToEntity(childEntityVO, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.ChildEntityDao#childEntityVOToEntity(org.andromda.cartridges.spring.ChildEntityVO, org.andromda.cartridges.spring.ChildEntity)
     */
    public void childEntityVOToEntity(
        org.andromda.cartridges.spring.ChildEntityVO sourceVO,
        org.andromda.cartridges.spring.ChildEntity targetEntity,
        boolean copyIfNull)
    {
        // @todo verify behavior of childEntityVOToEntity
        super.childEntityVOToEntity(sourceVO, targetEntity, copyIfNull);
        // No conversion for targetEntity.misMatchedAttribute (can't convert sourceVO.getMisMatchedAttribute():java.lang.Float to java.sql.Timestamp
    }

}