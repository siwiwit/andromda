/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public final class HouseManageableServiceBase
    implements HouseManageableService
{
    private org.andromda.cartridges.spring.crud.crud.HouseManageableDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.crud.HouseManageableDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.crud.HouseManageableDao getDao()
    {
        return this.dao;
    }

    public void create(java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] gardens)
        throws Exception
    {
        if (enumAttribute == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.HouseManageableService.create(java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] gardens) - 'enumAttribute' can not be null");
        }

        dao.create(something, enumAttribute, id, gardens);
    }

    public java.util.List read(java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] gardens)
        throws Exception
    {
        return toValueObjects(dao.read(something, enumAttribute, id, gardens));
    }

    public java.util.List readAll()
        throws Exception
    {
        return toValueObjects(dao.readAll());
    }

    public java.util.Map readBackingLists()
        throws Exception
    {
        return getDao().readBackingLists();
    }

    public void update(java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] gardens)
        throws Exception
    {
        if (enumAttribute == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.HouseManageableService.update(java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] gardens) - 'enumAttribute' can not be null");
        }

        if (id == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.HouseManageableService.update(java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] gardens) - 'id' can not be null");
        }

        dao.update(something, enumAttribute, id, gardens);
    }

    public void delete(java.lang.Long[] ids)
        throws Exception
    {
        if (ids == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.HouseManageableService.delete(java.lang.Long[] ids) - 'ids' can not be null");
        }

        dao.delete(ids);
    }


    private java.util.List toValueObjects(java.util.Collection entities)
    {
        final java.util.List list = new java.util.ArrayList();

        for (java.util.Iterator iterator = entities.iterator(); iterator.hasNext();)
        {
            list.add(toValueObject((org.andromda.cartridges.spring.crud.House)iterator.next()));
        }

        return list;
    }

    private org.andromda.cartridges.spring.crud.crud.HouseValueObject toValueObject(org.andromda.cartridges.spring.crud.House entity)
    {
        final org.andromda.cartridges.spring.crud.crud.HouseValueObject valueObject = new org.andromda.cartridges.spring.crud.crud.HouseValueObject();

        valueObject.setSomething(entity.getSomething());
        valueObject.setEnumAttribute(entity.getEnumAttribute());
        valueObject.setId(entity.getId());

        final java.util.Collection gardens = entity.getGardens();
        if (gardens.isEmpty())
        {
            valueObject.setGardens(java.util.Collections.EMPTY_LIST);
            valueObject.setGardensLabels(java.util.Collections.EMPTY_LIST);
        }
        else
        {
            final java.util.List values = new java.util.ArrayList();
            final java.util.List labels = new java.util.ArrayList();
            for (final java.util.Iterator iterator = gardens.iterator(); iterator.hasNext();)
            {
                final org.andromda.cartridges.spring.crud.Garden element = (org.andromda.cartridges.spring.crud.Garden)iterator.next();
                values.add(element.getId());
                labels.add(element.getInteger());
            }
            valueObject.setGardens(values);
            valueObject.setGardensLabels(labels);
        }

        return valueObject;
    }
}
