/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public class GardenValueObject
    implements java.io.Serializable
{
    private int integer;

    public int getInteger()
    {
        return this.integer;
    }

    public void setInteger(int integer)
    {
        this.integer = integer;
    }

    private java.lang.Integer intWrapper;

    public java.lang.Integer getIntWrapper()
    {
        return this.intWrapper;
    }

    public void setIntWrapper(java.lang.Integer intWrapper)
    {
        this.intWrapper = intWrapper;
    }

    private java.lang.Long id;

    public java.lang.Long getId()
    {
        return this.id;
    }

    public void setId(java.lang.Long id)
    {
        this.id = id;
    }

    private java.lang.Long[] houses;

    public java.lang.Long[] getHouses()
    {
        return this.houses;
    }

    public void setHouses(java.lang.Long[] houses)
    {
        this.houses = houses;
    }

}