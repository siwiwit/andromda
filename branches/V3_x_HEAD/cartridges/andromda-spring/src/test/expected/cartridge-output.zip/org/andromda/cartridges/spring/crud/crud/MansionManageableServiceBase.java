/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public final class MansionManageableServiceBase
    implements MansionManageableService
{
    private org.andromda.cartridges.spring.crud.crud.MansionManageableDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.crud.MansionManageableDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.crud.MansionManageableDao getDao()
    {
        return this.dao;
    }

    public org.andromda.cartridges.spring.crud.crud.MansionValueObject create(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion)
        throws Exception
    {
        if (name == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.create(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion) - 'name' can not be null");
        }

        if (enumAttribute == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.create(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion) - 'enumAttribute' can not be null");
        }

        if (mansion == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.create(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion) - 'mansion' can not be null");
        }

        return toValueObject(dao.create(name, id, something, enumAttribute, gardens, mansion));
    }

    public java.util.List read(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion)
        throws Exception
    {
        return toValueObjects(dao.read(name, id, something, enumAttribute, gardens, mansion));
    }

    public java.util.List readAll()
        throws Exception
    {
        return toValueObjects(dao.readAll());
    }

    public java.util.Map readBackingLists()
        throws Exception
    {
        return getDao().readBackingLists();
    }

    public org.andromda.cartridges.spring.crud.crud.MansionValueObject update(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion)
        throws Exception
    {
        if (name == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion) - 'name' can not be null");
        }

        if (id == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion) - 'id' can not be null");
        }

        if (enumAttribute == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion) - 'enumAttribute' can not be null");
        }

        if (mansion == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.update(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] gardens, java.lang.Long mansion) - 'mansion' can not be null");
        }

        return toValueObject(dao.update(name, id, something, enumAttribute, gardens, mansion));
    }

    public void delete(java.lang.Long[] ids)
        throws Exception
    {
        if (ids == null)
        {
            throw new IllegalArgumentException(
                "org.andromda.cartridges.spring.crud.crud.MansionManageableService.delete(java.lang.Long[] ids) - 'ids' can not be null");
        }

        dao.delete(ids);
    }


    private static java.util.List toValueObjects(java.util.Collection entities)
    {
        final java.util.List list = new java.util.ArrayList();

        for (java.util.Iterator iterator = entities.iterator(); iterator.hasNext();)
        {
            list.add(toValueObject((org.andromda.cartridges.spring.crud.Mansion)iterator.next()));
        }

        return list;
    }

    private static org.andromda.cartridges.spring.crud.crud.MansionValueObject toValueObject(org.andromda.cartridges.spring.crud.Mansion entity)
    {
        final org.andromda.cartridges.spring.crud.crud.MansionValueObject valueObject = new org.andromda.cartridges.spring.crud.crud.MansionValueObject();

        valueObject.setName(entity.getName());
        valueObject.setId(entity.getId());
        valueObject.setSomething(entity.getSomething());
        valueObject.setEnumAttribute(entity.getEnumAttribute());

        final java.util.Collection gardens = entity.getGardens();
        if (gardens.isEmpty())
        {
            valueObject.setGardens(null);
            valueObject.setGardensLabels(null);
        }
        else
        {
            final java.lang.Long[] values = new java.lang.Long[gardens.size()];
            final int[] labels = new int[gardens.size()];
            int counter = 0;
            for (final java.util.Iterator iterator = gardens.iterator(); iterator.hasNext();counter++)
            {
                final org.andromda.cartridges.spring.crud.Garden element = (org.andromda.cartridges.spring.crud.Garden)iterator.next();
                values[counter] = element.getId();
                labels[counter] = element.getInteger();
            }
            valueObject.setGardens(values);
            valueObject.setGardensLabels(labels);
        }

        final org.andromda.cartridges.spring.crud.Mansion mansion = entity.getMansion();
        if (mansion != null)
        {
            valueObject.setMansion(mansion.getId());
        }

        return valueObject;
    }
}
