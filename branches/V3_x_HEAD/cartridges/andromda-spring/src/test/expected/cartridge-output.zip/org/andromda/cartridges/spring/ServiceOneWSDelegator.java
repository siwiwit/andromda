/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring;

/**
 * Web service delegator for {@link org.andromda.cartridges.spring.ServiceOne}.
 *
 * @see org.andromda.cartridges.spring.ServiceOne
 */
public class ServiceOneWSDelegator
{

    /**
     * Gets an instance of {@link org.andromda.cartridges.spring.ServiceOne}
     */
    private final org.andromda.cartridges.spring.ServiceOne getServiceOne()
    {
        return org.andromda.spring.ServiceLocator.instance().getServiceOne();
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithVoidReturnType()
     */
    public void operationWithVoidReturnType()
        throws org.andromda.cartridges.spring.ServiceTestException
    {
        try
        {
            getServiceOne().operationWithVoidReturnType();
        }
        catch (Exception exception)
        {
            if (exception instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)cause;
            }
            throw new java.lang.RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSimpleReturnType()
     */
    public java.lang.String operationWithSimpleReturnType()
        throws org.andromda.cartridges.spring.ServiceTestException
    {
        try
        {
            return getServiceOne().operationWithSimpleReturnType();
        }
        catch (Exception exception)
        {
            if (exception instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)cause;
            }
            throw new java.lang.RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithComplexReturnType()
     */
    public java.util.Collection operationWithComplexReturnType()
        throws org.andromda.cartridges.spring.ServiceTestException
    {
        try
        {
            return getServiceOne().operationWithComplexReturnType();
        }
        catch (Exception exception)
        {
            if (exception instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)cause;
            }
            throw new java.lang.RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithSingleArgument(java.util.Date)
     */
    public java.lang.String operationWithSingleArgument(java.util.Date argumentOne)
        throws org.andromda.cartridges.spring.ServiceTestException
    {
        try
        {
            return getServiceOne().operationWithSingleArgument(argumentOne);
        }
        catch (Exception exception)
        {
            if (exception instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)cause;
            }
            throw new java.lang.RuntimeException(cause);
        }
    }

    /**
     * @see org.andromda.cartridges.spring.ServiceOne#operationWithMultipleArguments(java.lang.Long, java.lang.Boolean)
     */
    public void operationWithMultipleArguments(java.lang.Long firstArgument, java.lang.Boolean secondArgument)
        throws org.andromda.cartridges.spring.ServiceTestException, org.andromda.cartridges.spring.OperationTestException
    {
        try
        {
            getServiceOne().operationWithMultipleArguments(firstArgument, secondArgument);
        }
        catch (Exception exception)
        {
            if (exception instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)exception;
            }
            if (exception instanceof org.andromda.cartridges.spring.OperationTestException)
            {
                throw (org.andromda.cartridges.spring.OperationTestException)exception;
            }
            final Throwable cause = getRootCause(exception);
            if (cause instanceof org.andromda.cartridges.spring.ServiceTestException)
            {
                throw (org.andromda.cartridges.spring.ServiceTestException)cause;
            }
            if (cause instanceof org.andromda.cartridges.spring.OperationTestException)
            {
                throw (org.andromda.cartridges.spring.OperationTestException)cause;
            }
            throw new java.lang.RuntimeException(cause);
        }
    }

    /**
     * Finds the root cause of the parent exception
     * by traveling up the exception tree.
     */
    private static Throwable getRootCause(Throwable throwable)
    {
        if (throwable != null)
        {
            // Reflectively get any exception causes.
            try
            {
                Throwable targetException = null;

                // java.lang.reflect.InvocationTargetException
                String exceptionProperty = "targetException";
                if (org.apache.commons.beanutils.PropertyUtils.isReadable(throwable, exceptionProperty))
                {
                    targetException = (Throwable)org.apache.commons.beanutils.PropertyUtils.getProperty(throwable, exceptionProperty);
                }
                else
                {
                    exceptionProperty = "causedByException";
                    //javax.ejb.EJBException
                    if (org.apache.commons.beanutils.PropertyUtils.isReadable(throwable, exceptionProperty))
                    {
                        targetException = (Throwable)org.apache.commons.beanutils.PropertyUtils.getProperty(throwable, exceptionProperty);
                    }
                }
                if (targetException != null)
                {
                    throwable = targetException;
                }
            }
            catch (Exception exception)
            {
                // just print the exception and continue
                exception.printStackTrace();
            }
            if (throwable.getCause() != null)
            {
                throwable = throwable.getCause();
                throwable = getRootCause(throwable);
            }
        }
        return throwable;
    }
}