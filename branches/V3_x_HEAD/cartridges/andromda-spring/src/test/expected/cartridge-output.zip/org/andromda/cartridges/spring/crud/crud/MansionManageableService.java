/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public interface MansionManageableService
{
    public org.andromda.cartridges.spring.crud.crud.MansionValueObject create(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] houses, java.lang.Long[] gardens)
        throws Exception;

    public java.util.List read(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] houses, java.lang.Long[] gardens)
        throws Exception;

    public java.util.List readAll()
        throws Exception;

    public java.util.Map readBackingLists()
        throws Exception;

    public org.andromda.cartridges.spring.crud.crud.MansionValueObject update(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] houses, java.lang.Long[] gardens)
        throws Exception;

    public void delete(java.lang.Long[] ids)
        throws Exception;

}
