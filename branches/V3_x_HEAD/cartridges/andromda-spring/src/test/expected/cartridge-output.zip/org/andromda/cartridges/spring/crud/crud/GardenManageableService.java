/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public interface GardenManageableService
{
    public org.andromda.cartridges.spring.crud.crud.GardenValueObject create(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception;

    public org.andromda.cartridges.spring.crud.crud.GardenValueObject readById(java.lang.Long id)
        throws Exception;

    public java.util.List read(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception;

    public java.util.List readAll()
        throws Exception;

    public java.util.Map readBackingLists()
        throws Exception;

    public org.andromda.cartridges.spring.crud.crud.GardenValueObject update(int integer, java.lang.Integer intWrapper, java.lang.Long id, java.lang.Long room, java.lang.Long[] houses)
        throws Exception;

    public void delete(java.lang.Long[] ids)
        throws Exception;

}
