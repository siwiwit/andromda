/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public interface RoomManageableDao
{
    public org.andromda.cartridges.spring.crud.Room create(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long[] hello);

    public java.util.List read(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long[] hello);

    public java.util.List readAll();

    public java.util.Map readBackingLists();

    public org.andromda.cartridges.spring.crud.Room update(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long[] hello);

    public void delete(java.lang.Long[] ids);

}