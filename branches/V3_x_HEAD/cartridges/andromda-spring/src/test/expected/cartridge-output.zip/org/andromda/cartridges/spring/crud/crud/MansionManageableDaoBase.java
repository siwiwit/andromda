/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import net.sf.hibernate.Session;
import net.sf.hibernate.Criteria;
import net.sf.hibernate.expression.MatchMode;
import net.sf.hibernate.expression.Expression;

public final class MansionManageableDaoBase
    extends org.springframework.orm.hibernate.support.HibernateDaoSupport
    implements MansionManageableDao
{
    private org.andromda.cartridges.spring.crud.MansionDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.MansionDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.MansionDao getDao()
    {
        return this.dao;
    }

    private org.andromda.cartridges.spring.crud.HouseDao housesDao = null;

    public void setHousesDao(org.andromda.cartridges.spring.crud.HouseDao housesDao)
    {
        this.housesDao = housesDao;
    }

    protected org.andromda.cartridges.spring.crud.HouseDao getHousesDao()
    {
        return this.housesDao;
    }

    private org.andromda.cartridges.spring.crud.RoomDao roomDao = null;

    public void setRoomDao(org.andromda.cartridges.spring.crud.RoomDao roomDao)
    {
        this.roomDao = roomDao;
    }

    protected org.andromda.cartridges.spring.crud.RoomDao getRoomDao()
    {
        return this.roomDao;
    }

    private org.andromda.cartridges.spring.crud.GardenDao gardensDao = null;

    public void setGardensDao(org.andromda.cartridges.spring.crud.GardenDao gardensDao)
    {
        this.gardensDao = gardensDao;
    }

    protected org.andromda.cartridges.spring.crud.GardenDao getGardensDao()
    {
        return this.gardensDao;
    }

    private org.andromda.cartridges.spring.crud.MansionDao mansionDao = null;

    public void setMansionDao(org.andromda.cartridges.spring.crud.MansionDao mansionDao)
    {
        this.mansionDao = mansionDao;
    }

    protected org.andromda.cartridges.spring.crud.MansionDao getMansionDao()
    {
        return this.mansionDao;
    }

    private java.util.Set findHouseByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private java.util.Set findRoomByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.RoomImpl.class);
            criteria.add(Expression.in("specificId", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private java.util.Set findGardenByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private java.util.Set findMansionByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.MansionImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public org.andromda.cartridges.spring.crud.Mansion create(java.lang.String name, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] houses, java.lang.Long room, java.lang.Long[] gardens, java.lang.Long mansion)
    {
        final org.andromda.cartridges.spring.crud.Mansion entity = new org.andromda.cartridges.spring.crud.MansionImpl();
        entity.setName(name);
        entity.setSomething(something);
        entity.setEnumAttribute(enumAttribute);
        entity.setId(id);
        final java.util.Set housesEntities = (houses != null && houses.length > 0)
            ? this.findHouseByIds(houses)
            : java.util.Collections.EMPTY_SET;

        entity.setHouses(housesEntities);

        org.andromda.cartridges.spring.crud.Room roomEntity = null;
        if (room != null)
        {
            roomEntity = (org.andromda.cartridges.spring.crud.Room)getRoomDao().load(room);
        }

        entity.setRoom(roomEntity);

        final java.util.Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : java.util.Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);

        org.andromda.cartridges.spring.crud.Mansion mansionEntity = null;
        if (mansion != null)
        {
            mansionEntity = (org.andromda.cartridges.spring.crud.Mansion)getMansionDao().load(mansion);
        }

        entity.setMansion(mansionEntity);


        return (org.andromda.cartridges.spring.crud.Mansion)this.getDao().create(entity);
    }

    public org.andromda.cartridges.spring.crud.Mansion readById(java.lang.Long id)
    {
        return getDao().load(id);
    }

    public java.util.List read(java.lang.String name, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] houses, java.lang.Long room, java.lang.Long[] gardens, java.lang.Long mansion)
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.MansionImpl.class);

            if (name != null)
                criteria.add(Expression.ilike("name", name, MatchMode.START));
            if (something != null)
                criteria.add(Expression.ilike("something", something, MatchMode.START));
            if (enumAttribute != null)
            criteria.add(Expression.eq("enumAttribute", enumAttribute));
            if (id != null)
            criteria.add(Expression.eq("id", id));
            if (houses != null && houses.length > 0) criteria.createCriteria("houses").add(Expression.in("id", houses));
            if (room != null) criteria.createCriteria("room").add(Expression.eq("specificId", room));
            if (gardens != null && gardens.length > 0) criteria.createCriteria("gardens").add(Expression.in("id", gardens));
            if (mansion != null) criteria.createCriteria("mansion").add(Expression.eq("id", mansion));
            criteria.setMaxResults(250);

            return criteria.list();
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public java.util.List readAll()
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.MansionImpl.class);
            criteria.setMaxResults(250);
            return criteria.list();
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public java.util.Map readBackingLists()
    {
        final java.util.Map lists = new java.util.HashMap();
        final Session session = this.getSession();

        try
        {
            lists.put("houses", session.createQuery("select item.id, item.id from org.andromda.cartridges.spring.crud.House item order by item.id").list());
            lists.put("room", session.createQuery("select item.specificId, item.specificId from org.andromda.cartridges.spring.crud.Room item order by item.specificId").list());
            lists.put("gardens", session.createQuery("select item.id, item.integer from org.andromda.cartridges.spring.crud.Garden item order by item.integer").list());
            lists.put("mansion", session.createQuery("select item.id, item.id from org.andromda.cartridges.spring.crud.Mansion item order by item.id").list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
        return lists;
    }

    public org.andromda.cartridges.spring.crud.Mansion update(java.lang.String name, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long id, java.lang.Long[] houses, java.lang.Long room, java.lang.Long[] gardens, java.lang.Long mansion)
    {
        final org.andromda.cartridges.spring.crud.Mansion entity = (org.andromda.cartridges.spring.crud.Mansion) this.getDao().load(id);

        entity.setName(name);
        entity.setSomething(something);
        entity.setEnumAttribute(enumAttribute);
        final java.util.Set housesEntities = (houses != null && houses.length > 0)
            ? this.findHouseByIds(houses)
            : java.util.Collections.EMPTY_SET;

        entity.setHouses(housesEntities);

        org.andromda.cartridges.spring.crud.Room roomEntity = null;
        if (room != null)
        {
            roomEntity = getRoomDao().load(room);
        }

        entity.setRoom(roomEntity);

        final java.util.Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : java.util.Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);

        org.andromda.cartridges.spring.crud.Mansion mansionEntity = null;
        if (mansion != null)
        {
            mansionEntity = (org.andromda.cartridges.spring.crud.Mansion) getMansionDao().load(mansion);
        }

        entity.setMansion(mansionEntity);


        this.getDao().update(entity);
        return entity;
    }

    public void delete(java.lang.Long[] ids)
    {
        final Session session = getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            final java.util.List list = criteria.list();
            getHibernateTemplate().deleteAll(list);
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

}