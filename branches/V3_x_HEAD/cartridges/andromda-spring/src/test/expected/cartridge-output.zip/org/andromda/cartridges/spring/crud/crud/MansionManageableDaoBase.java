/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

import net.sf.hibernate.Session;
import net.sf.hibernate.Criteria;
import net.sf.hibernate.expression.MatchMode;
import net.sf.hibernate.expression.Expression;

public final class MansionManageableDaoBase
    extends org.springframework.orm.hibernate.support.HibernateDaoSupport
    implements MansionManageableDao
{
    private org.andromda.cartridges.spring.crud.MansionDao dao;

    public void setDao(org.andromda.cartridges.spring.crud.MansionDao dao)
    {
        this.dao = dao;
    }

    protected org.andromda.cartridges.spring.crud.MansionDao getDao()
    {
        return this.dao;
    }

    private org.andromda.cartridges.spring.crud.HouseDao housesDao = null;

    public void setHousesDao(org.andromda.cartridges.spring.crud.HouseDao housesDao)
    {
        this.housesDao = housesDao;
    }

    protected org.andromda.cartridges.spring.crud.HouseDao getHousesDao()
    {
        return this.housesDao;
    }

    private org.andromda.cartridges.spring.crud.GardenDao $member.daoName = null;

    public void ${member.daoSetterName}(org.andromda.cartridges.spring.crud.GardenDao $member.daoName)
    {
        this.$member.daoName = $member.daoName;
    }

    protected org.andromda.cartridges.spring.crud.GardenDao ${member.daoGetterName}()
    {
        return this.$member.daoName;
    }

    private java.util.Set findHouseByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private java.util.Set findRoomByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.RoomImpl.class);
            criteria.add(Expression.in("specificId", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private java.util.Set findGardenByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.GardenImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    private java.util.Set findMansionByIds(java.lang.Long[] ids)
    {
        final Session session = this.getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.MansionImpl.class);
            criteria.add(Expression.in("id", ids));
            return new java.util.HashSet(criteria.list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public org.andromda.cartridges.spring.crud.Mansion create(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] houses, java.lang.Long[] gardens)
    {
        final org.andromda.cartridges.spring.crud.Mansion entity = new org.andromda.cartridges.spring.crud.MansionImpl();
        entity.setName(name);
        entity.setId(id);
        entity.setSomething(something);
        entity.setEnumAttribute(enumAttribute);
        final java.util.Set housesEntities = (houses != null && houses.length > 0)
            ? this.findHouseByIds(houses)
            : java.util.Collections.EMPTY_SET;

        entity.setHouses(housesEntities);

        final java.util.Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : java.util.Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);


        return (org.andromda.cartridges.spring.crud.Mansion)this.getDao().create(entity);
    }

    public java.util.List read(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] houses, java.lang.Long[] gardens)
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.MansionImpl.class);

            if (name != null)
                criteria.add(Expression.ilike("name", name, MatchMode.START));
            if (id != null)
            criteria.add(Expression.eq("id", id));
            if (something != null)
                criteria.add(Expression.ilike("something", something, MatchMode.START));
            if (enumAttribute != null)
            criteria.add(Expression.eq("enumAttribute", enumAttribute));
            if (houses != null && houses.length > 0) criteria.createCriteria("houses").add(Expression.in("id", houses));
            if (gardens != null && gardens.length > 0) criteria.createCriteria("gardens").add(Expression.in("$member.manageableIdentifier.name", gardens));
            criteria.setMaxResults(250);

            return criteria.list();
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public java.util.List readAll()
    {
        final Session session = getSession(false);

        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.MansionImpl.class);
            criteria.setMaxResults(250);
            return criteria.list();
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

    public java.util.Map readBackingLists()
    {
        final java.util.Map lists = new java.util.HashMap();
        final Session session = this.getSession();

        try
        {
            lists.put("houses", session.createQuery("select item.id, item.id from org.andromda.cartridges.spring.crud.House item order by item.id").list());
            lists.put("gardens", session.createQuery("select item.id, item.integer from org.andromda.cartridges.spring.crud.Garden item order by item.integer").list());
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
        return lists;
    }

    public org.andromda.cartridges.spring.crud.Mansion update(java.lang.String name, java.lang.Long id, java.lang.String something, org.andromda.cartridges.spring.crud.Futurenum enumAttribute, java.lang.Long[] houses, java.lang.Long[] gardens)
    {
        final org.andromda.cartridges.spring.crud.Mansion entity = (org.andromda.cartridges.spring.crud.Mansion) this.getDao().load(id);

        entity.setName(name);
        entity.setSomething(something);
        entity.setEnumAttribute(enumAttribute);
        final java.util.Set housesEntities = (houses != null && houses.length > 0)
            ? this.findHouseByIds(houses)
            : java.util.Collections.EMPTY_SET;

        entity.setHouses(housesEntities);

        final java.util.Set gardensEntities = (gardens != null && gardens.length > 0)
            ? this.findGardenByIds(gardens)
            : java.util.Collections.EMPTY_SET;

        entity.setGardens(gardensEntities);


        this.getDao().update(entity);
        return entity;
    }

    public void delete(java.lang.Long[] ids)
    {
        final Session session = getSession(false);
        try
        {
            final Criteria criteria = session.createCriteria(org.andromda.cartridges.spring.crud.HouseImpl.class);
            criteria.add(Expression.in("id", ids));
            final java.util.List list = criteria.list();
            getHibernateTemplate().deleteAll(list);
        }
        catch (net.sf.hibernate.HibernateException ex)
        {
            throw super.convertHibernateAccessException(ex);
        }
    }

}