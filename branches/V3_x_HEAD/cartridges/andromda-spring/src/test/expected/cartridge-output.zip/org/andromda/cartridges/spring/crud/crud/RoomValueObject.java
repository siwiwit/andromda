/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public class RoomValueObject
    implements java.io.Serializable
{
    private java.util.Date date;

    public java.util.Date getDate()
    {
        return this.date;
    }

    public void setDate(java.util.Date date)
    {
        this.date = date;
    }

    private java.lang.Long specificId;

    public java.lang.Long getSpecificId()
    {
        return this.specificId;
    }

    public void setSpecificId(java.lang.Long specificId)
    {
        this.specificId = specificId;
    }

    private java.lang.Long named;

    public java.lang.Long getNamed()
    {
        return this.named;
    }

    public void setNamed(java.lang.Long named)
    {
        this.named = named;
    }

    private java.lang.Long[] hello;

    public java.lang.Long[] getHello()
    {
        return this.hello;
    }

    public void setHello(java.lang.Long[] hello)
    {
        this.hello = hello;
    }

    private int[] helloLabels;

    public int[] getHelloLabels()
    {
        return this.helloLabels;
    }

    public void setHelloLabels(int[] helloLabels)
    {
        this.helloLabels = helloLabels;
    }

}