/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.spring.crud.crud;

public interface RoomManageableService
{
    public org.andromda.cartridges.spring.crud.crud.RoomValueObject create(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long named, java.lang.Long[] hello)
        throws Exception;

    public org.andromda.cartridges.spring.crud.crud.RoomValueObject readById(java.lang.Long specificId)
        throws Exception;

    public java.util.List read(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long named, java.lang.Long[] hello)
        throws Exception;

    public java.util.List readAll()
        throws Exception;

    public java.util.Map readBackingLists()
        throws Exception;

    public org.andromda.cartridges.spring.crud.crud.RoomValueObject update(java.util.Date date, java.lang.Long specificId, java.lang.Long[] gardens, java.lang.Long named, java.lang.Long[] hello)
        throws Exception;

    public void delete(java.lang.Long[] ids)
        throws Exception;

}
