/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.spring;

/**
 * @see org.andromda.cartridges.spring.EntityOne
 */
public class EntityOneDaoImpl
    extends org.andromda.cartridges.spring.EntityOneDaoBase
{
    /**
     * @see @see org.andromda.cartridges.spring.EntityOneDao#toValueObject(org.andromda.cartridges.spring.EntityOne, org.andromda.cartridges.spring.TestValueObject)
     */
    public void toValueObject(
        org.andromda.cartridges.spring.EntityOne sourceEntity, 
        org.andromda.cartridges.spring.TestValueObject targetVO)
    {
        // @todo verify behavior of toValueObject
        super.toValueObject(sourceEntity, targetVO);
    }


    /**
     * @see org.andromda.cartridges.spring.EntityOneDao#toValueObject(org.andromda.cartridges.spring.EntityOne)
     */
    public org.andromda.cartridges.spring.TestValueObject toValueObject(final org.andromda.cartridges.spring.EntityOne entity)
    {
        // @todo verify behavior of toValueObject
        return super.toValueObject(entity);
    }


    /**
     * Retrieves the entity object that is associated with the specified value object
     * from the object store. If no such entity object exists in the object store, 
     * a new, blank entity is created
     */
    private org.andromda.cartridges.spring.EntityOne loadEntityOneFromTestValueObject(org.andromda.cartridges.spring.TestValueObject valueObject)
    {
        // @todo implement loadEntityOneFromTestValueObject
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.spring.loadEntityOneFromTestValueObject(org.andromda.cartridges.spring.TestValueObject) not yet implemented.");

        /* A typical implementation looks like this:        
        org.andromda.cartridges.spring.EntityOne entityOne = this.load(valueObject.getId());
        if (entityOne == null)
        {
            entityOne = org.andromda.cartridges.spring.EntityOne.Factory.newInstance();
        }
        return entityOne;
        */
    }

    
    /**
     * @see org.andromda.cartridges.spring.EntityOneDao#valueObjectToEntity(org.andromda.cartridges.spring.TestValueObject)
     */
    public org.andromda.cartridges.spring.EntityOne valueObjectToEntity(org.andromda.cartridges.spring.TestValueObject valueObject)
    {
        // @todo verify behavior of valueObjectToEntity
        org.andromda.cartridges.spring.EntityOne entity = this.loadEntityOneFromTestValueObject(valueObject);
        this.valueObjectToEntity(valueObject, entity, true);
        return entity;
    }


    /**
     * @see org.andromda.cartridges.spring.EntityOneDao#valueObjectToEntity(org.andromda.cartridges.spring.TestValueObject, org.andromda.cartridges.spring.EntityOne)
     */
    public void valueObjectToEntity(
        org.andromda.cartridges.spring.TestValueObject sourceVO,
        org.andromda.cartridges.spring.EntityOne targetEntity,
        boolean copyIfNull)
    {
        // @todo verify behavior of valueObjectToEntity
        super.valueObjectToEntity(sourceVO, targetEntity, copyIfNull);
    }

}