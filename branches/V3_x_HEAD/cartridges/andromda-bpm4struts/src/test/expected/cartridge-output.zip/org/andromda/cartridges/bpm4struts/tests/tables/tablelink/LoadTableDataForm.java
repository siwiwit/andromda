/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>loadTableData</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.tables.tablelink.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.Controller#loadTableData
 */
public interface LoadTableDataForm
{
    /**
     * Sets the <code>multiboxThing</code> field.
     *
     * 
     */
    public void setMultiboxThing(java.lang.String[] multiboxThing);

    /**
     * Gets the <code>multiboxThing</code> field.
     *
     * 
     */
    public java.lang.String[] getMultiboxThing();
    
    /**
     * Resets the <code>multiboxThing</code> field.
     */
    public void resetMultiboxThing();

    /**
     * This field is a collection type, and this method allows you to set it into the form.
     *
     * 
     *
     * @see #setTableData#sArray(Object[])
     */
    public void setTableData(java.util.Collection tableData);

    /**
     * This field is a collection type, and this method allows you to get it from the form.
     *
     * 
     *
     * @see #getTableData#sArray()
     */
    public java.util.Collection getTableData();

    /**
     * This field is a collection type, and this method allows you to set it as an
     * array into the form, conversion will be automatically performed.
     *
     * 
     *
     * @see #setTableData(java.util.Collection)
     */
    public void setTableDataAsArray(Object[] tableData);

    /**
     * This field is a collection type, and this method allows you to get it as an
     * array from the form, conversion will be automatically performed.
     *
     * 
     *
     * @see #getTableData()
     */
    public java.lang.Object[] getTableDataAsArray();

    /**
     * Resets the <code>tableData</code> field.
     */
    public void resetTableData();

}
