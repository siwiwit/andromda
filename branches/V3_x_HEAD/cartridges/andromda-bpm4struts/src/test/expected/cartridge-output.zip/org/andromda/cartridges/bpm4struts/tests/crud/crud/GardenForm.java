/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.crud.crud;

public final class GardenForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.util.List manageableList = null;

    public java.util.List getManageableList()
    {
        return this.manageableList;
    }

    public void setManageableList(java.util.List manageableList)
    {
        this.manageableList = manageableList;
    }

    private java.lang.Long[] selectedRows = null;

    public java.lang.Long[] getSelectedRows()
    {
        return this.selectedRows;
    }

    public void setSelectedRows(java.lang.Long[] selectedRows)
    {
        this.selectedRows = selectedRows;
    }

    private int integer;

    public int getInteger()
    {
        return this.integer;
    }

    public void setInteger(int integer)
    {
        this.integer = integer;
    }

    private java.lang.Integer intWrapper;

    public java.lang.Integer getIntWrapper()
    {
        return this.intWrapper;
    }

    public void setIntWrapper(java.lang.Integer intWrapper)
    {
        this.intWrapper = intWrapper;
    }

    private java.lang.Long id;

    public java.lang.Long getId()
    {
        return this.id;
    }

    public void setId(java.lang.Long id)
    {
        this.id = id;
    }

    private java.lang.Long room;

    public java.lang.Long getRoom()
    {
        return this.room;
    }

    public void setRoom(java.lang.Long room)
    {
        this.room = room;
    }

    private java.util.List roomBackingList;

    public java.util.List getRoomBackingList()
    {
        return this.roomBackingList;
    }

    public void setRoomBackingList(java.util.List roomBackingList)
    {
        this.roomBackingList = roomBackingList;
    }

    private java.lang.Long[] houses;

    public java.lang.Long[] getHouses()
    {
        return this.houses;
    }

    public void setHouses(java.lang.Long[] houses)
    {
        this.houses = houses;
    }

    private java.util.List housesBackingList;

    public java.util.List getHousesBackingList()
    {
        return this.housesBackingList;
    }

    public void setHousesBackingList(java.util.List housesBackingList)
    {
        this.housesBackingList = housesBackingList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        integer = 0;
        intWrapper = null;
        id = null;
        room = null;
        roomBackingList = null;
        houses = null;
        housesBackingList = null;
    }
}