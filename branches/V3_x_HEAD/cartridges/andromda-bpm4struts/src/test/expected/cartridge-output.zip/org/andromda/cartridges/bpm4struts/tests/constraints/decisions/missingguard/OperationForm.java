/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.constraints.decisions.missingguard;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>operation</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.constraints.decisions.missingguard.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.constraints.decisions.missingguard.Controller#operation
 */
public interface OperationForm
{
}
