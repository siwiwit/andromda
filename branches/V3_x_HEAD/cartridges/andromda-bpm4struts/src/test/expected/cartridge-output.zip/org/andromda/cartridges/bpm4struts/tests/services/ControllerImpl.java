/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.services;

import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @see org.andromda.cartridges.bpm4struts.tests.services.Controller
 */
public class ControllerImpl extends Controller
{
    /**
     * @see org.andromda.cartridges.bpm4struts.tests.services.Controller#crapmeout(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.services.CrapmeoutForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void crapmeout(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.services.CrapmeoutForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // nothing to be done for this operation, there are no properties that can be set
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.services.Controller#anOperation(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.services.AnOperationForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void anOperation(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.services.AnOperationForm form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.setOne("one-test");
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.services.Controller#anOperation1(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.services.AnOperation1Form, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void anOperation1(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.services.AnOperation1Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.setOne("one-test");
        // this property receives a default value, just to have the application running on dummy data
        form.setTwo((int)115276);
    }

    /**
     * @see org.andromda.cartridges.bpm4struts.tests.services.Controller#anOperation2(org.apache.struts.action.ActionMapping, org.andromda.cartridges.bpm4struts.tests.services.AnOperation2Form, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public final void anOperation2(ActionMapping mapping, org.andromda.cartridges.bpm4struts.tests.services.AnOperation2Form form, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        // this property receives a default value, just to have the application running on dummy data
        form.setOne("one-test");
        // this property receives a default value, just to have the application running on dummy data
        form.setTwo((int)115276);
        // this property receives a default value, just to have the application running on dummy data
        form.setThree("three-test");
    }

}