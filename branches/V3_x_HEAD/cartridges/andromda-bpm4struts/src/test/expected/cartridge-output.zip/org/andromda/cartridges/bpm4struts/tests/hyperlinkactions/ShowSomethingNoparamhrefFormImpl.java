/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.hyperlinkactions;

public class ShowSomethingNoparamhrefFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -18042318541L;

    private java.lang.String someParameter;
    private java.lang.Object[] someParameterValueList;
    private java.lang.Object[] someParameterLabelList;
    private java.lang.String parameterWithDefaultValue;
    private java.lang.Object[] parameterWithDefaultValueValueList;
    private java.lang.Object[] parameterWithDefaultValueLabelList;

    public ShowSomethingNoparamhrefFormImpl()
    {
    }

    /**
     * Resets the given <code>someParameter</code>.
     */
    public void resetSomeParameter()
    {
        this.someParameter = null;
    }

    public void setSomeParameter(java.lang.String someParameter)
    {
        this.someParameter = someParameter;
    }

    /**
     * 
     */
    public java.lang.String getSomeParameter()
    {
        return this.someParameter;
    }
    
    public java.lang.Object[] getSomeParameterBackingList()
    {
        java.lang.Object[] values = this.someParameterValueList;
        java.lang.Object[] labels = this.someParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getSomeParameterValueList()
    {
        return this.someParameterValueList;
    }

    public void setSomeParameterValueList(java.lang.Object[] someParameterValueList)
    {
        this.someParameterValueList = someParameterValueList;
    }

    public java.lang.Object[] getSomeParameterLabelList()
    {
        return this.someParameterLabelList;
    }

    public void setSomeParameterLabelList(java.lang.Object[] someParameterLabelList)
    {
        this.someParameterLabelList = someParameterLabelList;
    }

    public void setSomeParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowSomethingNoparamhrefFormImpl.setSomeParameterBackingList requires non-null property arguments");
        }

        this.someParameterValueList = null;
        this.someParameterLabelList = null;

        if (items != null)
        {
            this.someParameterValueList = new java.lang.Object[items.size()];
            this.someParameterLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.someParameterValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.someParameterLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowSomethingNoparamhrefFormImpl.setSomeParameterBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>parameterWithDefaultValue</code>.
     */
    public void resetParameterWithDefaultValue()
    {
        this.parameterWithDefaultValue = null;
    }

    public void setParameterWithDefaultValue(java.lang.String parameterWithDefaultValue)
    {
        this.parameterWithDefaultValue = parameterWithDefaultValue;
    }

    /**
     * 
     */
    public java.lang.String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }
    
    public java.lang.Object[] getParameterWithDefaultValueBackingList()
    {
        java.lang.Object[] values = this.parameterWithDefaultValueValueList;
        java.lang.Object[] labels = this.parameterWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getParameterWithDefaultValueValueList()
    {
        return this.parameterWithDefaultValueValueList;
    }

    public void setParameterWithDefaultValueValueList(java.lang.Object[] parameterWithDefaultValueValueList)
    {
        this.parameterWithDefaultValueValueList = parameterWithDefaultValueValueList;
    }

    public java.lang.Object[] getParameterWithDefaultValueLabelList()
    {
        return this.parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueLabelList(java.lang.Object[] parameterWithDefaultValueLabelList)
    {
        this.parameterWithDefaultValueLabelList = parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowSomethingNoparamhrefFormImpl.setParameterWithDefaultValueBackingList requires non-null property arguments");
        }

        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;

        if (items != null)
        {
            this.parameterWithDefaultValueValueList = new java.lang.Object[items.size()];
            this.parameterWithDefaultValueLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.parameterWithDefaultValueValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.parameterWithDefaultValueLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowSomethingNoparamhrefFormImpl.setParameterWithDefaultValueBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public java.lang.String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("someParameter", this.someParameter);
        builder.append("parameterWithDefaultValue", this.parameterWithDefaultValue);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.someParameter = null;
        this.someParameterValueList = null;
        this.someParameterLabelList = null;
        this.parameterWithDefaultValue = null;
        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public java.lang.String toString()
        {
            return label + "=" + value;
        }
    }
}