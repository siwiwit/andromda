/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.formscope;

public class FormScopeFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 13591324371L;

    private java.lang.String eventParam;
    private java.lang.Object[] eventParamValueList;
    private java.lang.Object[] eventParamLabelList;
    private java.lang.String pageVar;
    private java.lang.Object[] pageVarValueList;
    private java.lang.Object[] pageVarLabelList;

    public FormScopeFormImpl()
    {
    }

    /**
     * Resets the given <code>eventParam</code>.
     */
    public void resetEventParam()
    {
        this.eventParam = null;
    }

    public void setEventParam(java.lang.String eventParam)
    {
        this.eventParam = eventParam;
    }

    /**
     * 
     */
    public java.lang.String getEventParam()
    {
        return this.eventParam;
    }
    
    public java.lang.Object[] getEventParamBackingList()
    {
        java.lang.Object[] values = this.eventParamValueList;
        java.lang.Object[] labels = this.eventParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getEventParamValueList()
    {
        return this.eventParamValueList;
    }

    public void setEventParamValueList(java.lang.Object[] eventParamValueList)
    {
        this.eventParamValueList = eventParamValueList;
    }

    public java.lang.Object[] getEventParamLabelList()
    {
        return this.eventParamLabelList;
    }

    public void setEventParamLabelList(java.lang.Object[] eventParamLabelList)
    {
        this.eventParamLabelList = eventParamLabelList;
    }

    public void setEventParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormScopeFormImpl.setEventParamBackingList requires non-null property arguments");
        }

        this.eventParamValueList = null;
        this.eventParamLabelList = null;

        if (items != null)
        {
            this.eventParamValueList = new java.lang.Object[items.size()];
            this.eventParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.eventParamValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.eventParamLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormScopeFormImpl.setEventParamBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>pageVar</code>.
     */
    public void resetPageVar()
    {
        this.pageVar = null;
    }

    public void setPageVar(java.lang.String pageVar)
    {
        this.pageVar = pageVar;
    }

    /**
     * 
     */
    public java.lang.String getPageVar()
    {
        return this.pageVar;
    }
    
    public java.lang.Object[] getPageVarBackingList()
    {
        java.lang.Object[] values = this.pageVarValueList;
        java.lang.Object[] labels = this.pageVarLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getPageVarValueList()
    {
        return this.pageVarValueList;
    }

    public void setPageVarValueList(java.lang.Object[] pageVarValueList)
    {
        this.pageVarValueList = pageVarValueList;
    }

    public java.lang.Object[] getPageVarLabelList()
    {
        return this.pageVarLabelList;
    }

    public void setPageVarLabelList(java.lang.Object[] pageVarLabelList)
    {
        this.pageVarLabelList = pageVarLabelList;
    }

    public void setPageVarBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormScopeFormImpl.setPageVarBackingList requires non-null property arguments");
        }

        this.pageVarValueList = null;
        this.pageVarLabelList = null;

        if (items != null)
        {
            this.pageVarValueList = new java.lang.Object[items.size()];
            this.pageVarLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.pageVarValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.pageVarLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("FormScopeFormImpl.setPageVarBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
    }

    public java.lang.String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("eventParam", this.eventParam);
        builder.append("pageVar", this.pageVar);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.eventParam = null;
        this.eventParamValueList = null;
        this.eventParamLabelList = null;
        this.pageVar = null;
        this.pageVarValueList = null;
        this.pageVarLabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("customFormKey");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("customFormKey");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    final String[] values = request.getParameterValues(name);

                    if (values.length == 1)
                    {
                        parameters.put(name, values[0]);
                    }
                    else
                    {
                        parameters.put(name, values);
                    }
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public java.lang.String toString()
        {
            return label + "=" + value;
        }
    }
}