/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.services;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.services.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.services.Controller#anOperation
 */
public interface AnOperationForm
{
    /**
     * Sets the <code>one</code> field.
     *
     * 
     */
    public void setOne(java.lang.String one);

    /**
     * Gets the <code>one</code> field.
     *
     * 
     */
    public java.lang.String getOne();
    
    /**
     * Resets the <code>one</code> field.
     */
    public void resetOne();

}
