/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.tables.tablelink;

public class ShowTableDataActionWithBadTableLinkFormImpl
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -11830391911L;

    private java.lang.String thisParameterNameDoesNotExistAsTableColumn;
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList;
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList;
    private java.util.List firstRowSelection = null;
    private java.lang.Object[] firstValueList;
    private java.lang.Object[] firstLabelList;
    private java.lang.String[] multiboxThing;
    private java.lang.Object[] multiboxThingValueList;
    private java.lang.Object[] multiboxThingLabelList;
    private java.lang.String parameterWithDefaultValue;
    private java.lang.Object[] parameterWithDefaultValueValueList;
    private java.lang.Object[] parameterWithDefaultValueLabelList;
    private java.util.Collection tableData = null;
    private java.lang.Object[] tableDataValueList;
    private java.lang.Object[] tableDataLabelList;
    private java.lang.String third;
    private java.lang.Object[] thirdValueList;
    private java.lang.Object[] thirdLabelList;
    private java.lang.String second;
    private java.lang.Object[] secondValueList;
    private java.lang.Object[] secondLabelList;
    private java.util.List thisOneShouldbeNamedFirstRowSelection = null;
    private java.lang.Object[] thisOneShouldbeNamedFirstValueList;
    private java.lang.Object[] thisOneShouldbeNamedFirstLabelList;
    private java.lang.String formParam2;
    private java.lang.Object[] formParam2ValueList;
    private java.lang.Object[] formParam2LabelList;
    private java.util.Collection tableDataNoExportTypes = null;
    private java.lang.Object[] tableDataNoExportTypesValueList;
    private java.lang.Object[] tableDataNoExportTypesLabelList;
    private java.util.Collection tableDataDefaultExportTypes = null;
    private java.lang.Object[] tableDataDefaultExportTypesValueList;
    private java.lang.Object[] tableDataDefaultExportTypesLabelList;
    private java.lang.String two;
    private java.lang.Object[] twoValueList;
    private java.lang.Object[] twoLabelList;
    private java.lang.String unknownParameter;
    private java.lang.Object[] unknownParameterValueList;
    private java.lang.Object[] unknownParameterLabelList;
    private int formParam1;
    private java.lang.Object[] formParam1ValueList;
    private java.lang.Object[] formParam1LabelList;
    private java.util.Collection tableDataNotSortable = null;
    private java.lang.Object[] tableDataNotSortableValueList;
    private java.lang.Object[] tableDataNotSortableLabelList;
    private java.lang.String fourth;
    private java.lang.Object[] fourthValueList;
    private java.lang.Object[] fourthLabelList;

    public ShowTableDataActionWithBadTableLinkFormImpl()
    {
    }

    /**
     * Resets the given <code>thisParameterNameDoesNotExistAsTableColumn</code>.
     */
    public void resetThisParameterNameDoesNotExistAsTableColumn()
    {
        this.thisParameterNameDoesNotExistAsTableColumn = null;
    }

    public void setThisParameterNameDoesNotExistAsTableColumn(java.lang.String thisParameterNameDoesNotExistAsTableColumn)
    {
        this.thisParameterNameDoesNotExistAsTableColumn = thisParameterNameDoesNotExistAsTableColumn;
    }

    /**
     * 
     */
    public java.lang.String getThisParameterNameDoesNotExistAsTableColumn()
    {
        return this.thisParameterNameDoesNotExistAsTableColumn;
    }
    
    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnBackingList()
    {
        java.lang.Object[] values = this.thisParameterNameDoesNotExistAsTableColumnValueList;
        java.lang.Object[] labels = this.thisParameterNameDoesNotExistAsTableColumnLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnValueList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnValueList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnLabelList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnLabelList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setThisParameterNameDoesNotExistAsTableColumnBackingList requires non-null property arguments");
        }

        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;

        if (items != null)
        {
            this.thisParameterNameDoesNotExistAsTableColumnValueList = new java.lang.Object[items.size()];
            this.thisParameterNameDoesNotExistAsTableColumnLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.thisParameterNameDoesNotExistAsTableColumnValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thisParameterNameDoesNotExistAsTableColumnLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setThisParameterNameDoesNotExistAsTableColumnBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>firstRowSelection</code>.
     */
    public void resetFirst()
    {
        this.firstRowSelection = null;
    }

    public void setFirstRowSelection(java.util.List firstRowSelection)
    {
        this.firstRowSelection = firstRowSelection;
    }

    public java.util.List getFirstRowSelection()
    {
        return this.firstRowSelection;
    }

    public void setFirstRowSelectionAsArray(java.lang.Integer[] firstRowSelection)
    {
        this.firstRowSelection = (firstRowSelection == null) ? null : java.util.Arrays.asList(firstRowSelection);
    }

    public java.lang.Integer[] getFirstRowSelectionAsArray()
    {
        return (firstRowSelection == null) ? null : (java.lang.Integer[])firstRowSelection.toArray(new java.lang.Integer[firstRowSelection.size()]);
    }

    public java.lang.Object[] getFirstBackingList()
    {
        java.lang.Object[] values = this.firstValueList;
        java.lang.Object[] labels = this.firstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFirstValueList()
    {
        return this.firstValueList;
    }

    public void setFirstValueList(java.lang.Object[] firstValueList)
    {
        this.firstValueList = firstValueList;
    }

    public java.lang.Object[] getFirstLabelList()
    {
        return this.firstLabelList;
    }

    public void setFirstLabelList(java.lang.Object[] firstLabelList)
    {
        this.firstLabelList = firstLabelList;
    }

    public void setFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setFirstBackingList requires non-null property arguments");
        }

        this.firstValueList = null;
        this.firstLabelList = null;

        if (items != null)
        {
            this.firstValueList = new java.lang.Object[items.size()];
            this.firstLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.firstValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.firstLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setFirstBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>multiboxThing</code>.
     */
    public void resetMultiboxThing()
    {
        this.multiboxThing = null;
    }

    public void setMultiboxThing(java.lang.String[] multiboxThing)
    {
        this.multiboxThing = multiboxThing;
    }

    /**
     * 
     */
    public java.lang.String[] getMultiboxThing()
    {
        return this.multiboxThing;
    }
    
    public java.lang.Object[] getMultiboxThingBackingList()
    {
        java.lang.Object[] values = this.multiboxThingValueList;
        java.lang.Object[] labels = this.multiboxThingLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getMultiboxThingValueList()
    {
        return this.multiboxThingValueList;
    }

    public void setMultiboxThingValueList(java.lang.Object[] multiboxThingValueList)
    {
        this.multiboxThingValueList = multiboxThingValueList;
    }

    public java.lang.Object[] getMultiboxThingLabelList()
    {
        return this.multiboxThingLabelList;
    }

    public void setMultiboxThingLabelList(java.lang.Object[] multiboxThingLabelList)
    {
        this.multiboxThingLabelList = multiboxThingLabelList;
    }

    public void setMultiboxThingBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setMultiboxThingBackingList requires non-null property arguments");
        }

        this.multiboxThingValueList = null;
        this.multiboxThingLabelList = null;

        if (items != null)
        {
            this.multiboxThingValueList = new java.lang.Object[items.size()];
            this.multiboxThingLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.multiboxThingValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.multiboxThingLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setMultiboxThingBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>parameterWithDefaultValue</code>.
     */
    public void resetParameterWithDefaultValue()
    {
        this.parameterWithDefaultValue = null;
    }

    public void setParameterWithDefaultValue(java.lang.String parameterWithDefaultValue)
    {
        this.parameterWithDefaultValue = parameterWithDefaultValue;
    }

    /**
     * 
     */
    public java.lang.String getParameterWithDefaultValue()
    {
        return this.parameterWithDefaultValue;
    }
    
    public java.lang.Object[] getParameterWithDefaultValueBackingList()
    {
        java.lang.Object[] values = this.parameterWithDefaultValueValueList;
        java.lang.Object[] labels = this.parameterWithDefaultValueLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getParameterWithDefaultValueValueList()
    {
        return this.parameterWithDefaultValueValueList;
    }

    public void setParameterWithDefaultValueValueList(java.lang.Object[] parameterWithDefaultValueValueList)
    {
        this.parameterWithDefaultValueValueList = parameterWithDefaultValueValueList;
    }

    public java.lang.Object[] getParameterWithDefaultValueLabelList()
    {
        return this.parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueLabelList(java.lang.Object[] parameterWithDefaultValueLabelList)
    {
        this.parameterWithDefaultValueLabelList = parameterWithDefaultValueLabelList;
    }

    public void setParameterWithDefaultValueBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setParameterWithDefaultValueBackingList requires non-null property arguments");
        }

        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;

        if (items != null)
        {
            this.parameterWithDefaultValueValueList = new java.lang.Object[items.size()];
            this.parameterWithDefaultValueLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.parameterWithDefaultValueValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.parameterWithDefaultValueLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setParameterWithDefaultValueBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>tableData</code>.
     */
    public void resetTableData()
    {
        this.tableData = null;
    }

    public void setTableData(java.util.Collection tableData)
    {
        this.tableData = tableData;
    }

    /**
     * 
     */
    public java.util.Collection getTableData()
    {
        return this.tableData;
    }

    public void setTableDataAsArray(Object[] tableData)
    {
        this.tableData = (tableData == null) ? null : java.util.Arrays.asList(tableData);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl#getTableData
     */
    public java.lang.Object[] getTableDataAsArray()
    {
        return (tableData == null) ? null : tableData.toArray();
    }
    
    public java.lang.Object[] getTableDataBackingList()
    {
        java.lang.Object[] values = this.tableDataValueList;
        java.lang.Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(java.lang.Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public java.lang.Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(java.lang.Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    public void setTableDataBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setTableDataBackingList requires non-null property arguments");
        }

        this.tableDataValueList = null;
        this.tableDataLabelList = null;

        if (items != null)
        {
            this.tableDataValueList = new java.lang.Object[items.size()];
            this.tableDataLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.tableDataValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setTableDataBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>third</code>.
     */
    public void resetThird()
    {
        this.third = null;
    }

    public void setThird(java.lang.String third)
    {
        this.third = third;
    }

    /**
     * 
     */
    public java.lang.String getThird()
    {
        return this.third;
    }
    
    public java.lang.Object[] getThirdBackingList()
    {
        java.lang.Object[] values = this.thirdValueList;
        java.lang.Object[] labels = this.thirdLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getThirdValueList()
    {
        return this.thirdValueList;
    }

    public void setThirdValueList(java.lang.Object[] thirdValueList)
    {
        this.thirdValueList = thirdValueList;
    }

    public java.lang.Object[] getThirdLabelList()
    {
        return this.thirdLabelList;
    }

    public void setThirdLabelList(java.lang.Object[] thirdLabelList)
    {
        this.thirdLabelList = thirdLabelList;
    }

    public void setThirdBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setThirdBackingList requires non-null property arguments");
        }

        this.thirdValueList = null;
        this.thirdLabelList = null;

        if (items != null)
        {
            this.thirdValueList = new java.lang.Object[items.size()];
            this.thirdLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.thirdValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thirdLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setThirdBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>second</code>.
     */
    public void resetSecond()
    {
        this.second = null;
    }

    public void setSecond(java.lang.String second)
    {
        this.second = second;
    }

    /**
     * 
     */
    public java.lang.String getSecond()
    {
        return this.second;
    }
    
    public java.lang.Object[] getSecondBackingList()
    {
        java.lang.Object[] values = this.secondValueList;
        java.lang.Object[] labels = this.secondLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getSecondValueList()
    {
        return this.secondValueList;
    }

    public void setSecondValueList(java.lang.Object[] secondValueList)
    {
        this.secondValueList = secondValueList;
    }

    public java.lang.Object[] getSecondLabelList()
    {
        return this.secondLabelList;
    }

    public void setSecondLabelList(java.lang.Object[] secondLabelList)
    {
        this.secondLabelList = secondLabelList;
    }

    public void setSecondBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setSecondBackingList requires non-null property arguments");
        }

        this.secondValueList = null;
        this.secondLabelList = null;

        if (items != null)
        {
            this.secondValueList = new java.lang.Object[items.size()];
            this.secondLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.secondValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.secondLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setSecondBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>thisOneShouldbeNamedFirstRowSelection</code>.
     */
    public void resetThisOneShouldbeNamedFirst()
    {
        this.thisOneShouldbeNamedFirstRowSelection = null;
    }

    public void setThisOneShouldbeNamedFirstRowSelection(java.util.List thisOneShouldbeNamedFirstRowSelection)
    {
        this.thisOneShouldbeNamedFirstRowSelection = thisOneShouldbeNamedFirstRowSelection;
    }

    public java.util.List getThisOneShouldbeNamedFirstRowSelection()
    {
        return this.thisOneShouldbeNamedFirstRowSelection;
    }

    public void setThisOneShouldbeNamedFirstRowSelectionAsArray(java.lang.String[] thisOneShouldbeNamedFirstRowSelection)
    {
        this.thisOneShouldbeNamedFirstRowSelection = (thisOneShouldbeNamedFirstRowSelection == null) ? null : java.util.Arrays.asList(thisOneShouldbeNamedFirstRowSelection);
    }

    public java.lang.String[] getThisOneShouldbeNamedFirstRowSelectionAsArray()
    {
        return (thisOneShouldbeNamedFirstRowSelection == null) ? null : (java.lang.String[])thisOneShouldbeNamedFirstRowSelection.toArray(new java.lang.String[thisOneShouldbeNamedFirstRowSelection.size()]);
    }

    public java.lang.Object[] getThisOneShouldbeNamedFirstBackingList()
    {
        java.lang.Object[] values = this.thisOneShouldbeNamedFirstValueList;
        java.lang.Object[] labels = this.thisOneShouldbeNamedFirstLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getThisOneShouldbeNamedFirstValueList()
    {
        return this.thisOneShouldbeNamedFirstValueList;
    }

    public void setThisOneShouldbeNamedFirstValueList(java.lang.Object[] thisOneShouldbeNamedFirstValueList)
    {
        this.thisOneShouldbeNamedFirstValueList = thisOneShouldbeNamedFirstValueList;
    }

    public java.lang.Object[] getThisOneShouldbeNamedFirstLabelList()
    {
        return this.thisOneShouldbeNamedFirstLabelList;
    }

    public void setThisOneShouldbeNamedFirstLabelList(java.lang.Object[] thisOneShouldbeNamedFirstLabelList)
    {
        this.thisOneShouldbeNamedFirstLabelList = thisOneShouldbeNamedFirstLabelList;
    }

    public void setThisOneShouldbeNamedFirstBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setThisOneShouldbeNamedFirstBackingList requires non-null property arguments");
        }

        this.thisOneShouldbeNamedFirstValueList = null;
        this.thisOneShouldbeNamedFirstLabelList = null;

        if (items != null)
        {
            this.thisOneShouldbeNamedFirstValueList = new java.lang.Object[items.size()];
            this.thisOneShouldbeNamedFirstLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.thisOneShouldbeNamedFirstValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thisOneShouldbeNamedFirstLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setThisOneShouldbeNamedFirstBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>formParam2</code>.
     */
    public void resetFormParam2()
    {
        this.formParam2 = null;
    }

    public void setFormParam2(java.lang.String formParam2)
    {
        this.formParam2 = formParam2;
    }

    /**
     * 
     */
    public java.lang.String getFormParam2()
    {
        return this.formParam2;
    }
    
    public java.lang.Object[] getFormParam2BackingList()
    {
        java.lang.Object[] values = this.formParam2ValueList;
        java.lang.Object[] labels = this.formParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFormParam2ValueList()
    {
        return this.formParam2ValueList;
    }

    public void setFormParam2ValueList(java.lang.Object[] formParam2ValueList)
    {
        this.formParam2ValueList = formParam2ValueList;
    }

    public java.lang.Object[] getFormParam2LabelList()
    {
        return this.formParam2LabelList;
    }

    public void setFormParam2LabelList(java.lang.Object[] formParam2LabelList)
    {
        this.formParam2LabelList = formParam2LabelList;
    }

    public void setFormParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setFormParam2BackingList requires non-null property arguments");
        }

        this.formParam2ValueList = null;
        this.formParam2LabelList = null;

        if (items != null)
        {
            this.formParam2ValueList = new java.lang.Object[items.size()];
            this.formParam2LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.formParam2ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.formParam2LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setFormParam2BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>tableDataNoExportTypes</code>.
     */
    public void resetTableDataNoExportTypes()
    {
        this.tableDataNoExportTypes = null;
    }

    public void setTableDataNoExportTypes(java.util.Collection tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = tableDataNoExportTypes;
    }

    /**
     * 
     */
    public java.util.Collection getTableDataNoExportTypes()
    {
        return this.tableDataNoExportTypes;
    }

    public void setTableDataNoExportTypesAsArray(Object[] tableDataNoExportTypes)
    {
        this.tableDataNoExportTypes = (tableDataNoExportTypes == null) ? null : java.util.Arrays.asList(tableDataNoExportTypes);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl#getTableDataNoExportTypes
     */
    public java.lang.Object[] getTableDataNoExportTypesAsArray()
    {
        return (tableDataNoExportTypes == null) ? null : tableDataNoExportTypes.toArray();
    }
    
    public java.lang.Object[] getTableDataNoExportTypesBackingList()
    {
        java.lang.Object[] values = this.tableDataNoExportTypesValueList;
        java.lang.Object[] labels = this.tableDataNoExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTableDataNoExportTypesValueList()
    {
        return this.tableDataNoExportTypesValueList;
    }

    public void setTableDataNoExportTypesValueList(java.lang.Object[] tableDataNoExportTypesValueList)
    {
        this.tableDataNoExportTypesValueList = tableDataNoExportTypesValueList;
    }

    public java.lang.Object[] getTableDataNoExportTypesLabelList()
    {
        return this.tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesLabelList(java.lang.Object[] tableDataNoExportTypesLabelList)
    {
        this.tableDataNoExportTypesLabelList = tableDataNoExportTypesLabelList;
    }

    public void setTableDataNoExportTypesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setTableDataNoExportTypesBackingList requires non-null property arguments");
        }

        this.tableDataNoExportTypesValueList = null;
        this.tableDataNoExportTypesLabelList = null;

        if (items != null)
        {
            this.tableDataNoExportTypesValueList = new java.lang.Object[items.size()];
            this.tableDataNoExportTypesLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.tableDataNoExportTypesValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataNoExportTypesLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setTableDataNoExportTypesBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>tableDataDefaultExportTypes</code>.
     */
    public void resetTableDataDefaultExportTypes()
    {
        this.tableDataDefaultExportTypes = null;
    }

    public void setTableDataDefaultExportTypes(java.util.Collection tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = tableDataDefaultExportTypes;
    }

    /**
     * 
     */
    public java.util.Collection getTableDataDefaultExportTypes()
    {
        return this.tableDataDefaultExportTypes;
    }

    public void setTableDataDefaultExportTypesAsArray(Object[] tableDataDefaultExportTypes)
    {
        this.tableDataDefaultExportTypes = (tableDataDefaultExportTypes == null) ? null : java.util.Arrays.asList(tableDataDefaultExportTypes);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl#getTableDataDefaultExportTypes
     */
    public java.lang.Object[] getTableDataDefaultExportTypesAsArray()
    {
        return (tableDataDefaultExportTypes == null) ? null : tableDataDefaultExportTypes.toArray();
    }
    
    public java.lang.Object[] getTableDataDefaultExportTypesBackingList()
    {
        java.lang.Object[] values = this.tableDataDefaultExportTypesValueList;
        java.lang.Object[] labels = this.tableDataDefaultExportTypesLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTableDataDefaultExportTypesValueList()
    {
        return this.tableDataDefaultExportTypesValueList;
    }

    public void setTableDataDefaultExportTypesValueList(java.lang.Object[] tableDataDefaultExportTypesValueList)
    {
        this.tableDataDefaultExportTypesValueList = tableDataDefaultExportTypesValueList;
    }

    public java.lang.Object[] getTableDataDefaultExportTypesLabelList()
    {
        return this.tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesLabelList(java.lang.Object[] tableDataDefaultExportTypesLabelList)
    {
        this.tableDataDefaultExportTypesLabelList = tableDataDefaultExportTypesLabelList;
    }

    public void setTableDataDefaultExportTypesBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setTableDataDefaultExportTypesBackingList requires non-null property arguments");
        }

        this.tableDataDefaultExportTypesValueList = null;
        this.tableDataDefaultExportTypesLabelList = null;

        if (items != null)
        {
            this.tableDataDefaultExportTypesValueList = new java.lang.Object[items.size()];
            this.tableDataDefaultExportTypesLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.tableDataDefaultExportTypesValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataDefaultExportTypesLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setTableDataDefaultExportTypesBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>two</code>.
     */
    public void resetTwo()
    {
        this.two = null;
    }

    public void setTwo(java.lang.String two)
    {
        this.two = two;
    }

    /**
     * 
     */
    public java.lang.String getTwo()
    {
        return this.two;
    }
    
    public java.lang.Object[] getTwoBackingList()
    {
        java.lang.Object[] values = this.twoValueList;
        java.lang.Object[] labels = this.twoLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTwoValueList()
    {
        return this.twoValueList;
    }

    public void setTwoValueList(java.lang.Object[] twoValueList)
    {
        this.twoValueList = twoValueList;
    }

    public java.lang.Object[] getTwoLabelList()
    {
        return this.twoLabelList;
    }

    public void setTwoLabelList(java.lang.Object[] twoLabelList)
    {
        this.twoLabelList = twoLabelList;
    }

    public void setTwoBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setTwoBackingList requires non-null property arguments");
        }

        this.twoValueList = null;
        this.twoLabelList = null;

        if (items != null)
        {
            this.twoValueList = new java.lang.Object[items.size()];
            this.twoLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.twoValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.twoLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setTwoBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>unknownParameter</code>.
     */
    public void resetUnknownParameter()
    {
        this.unknownParameter = null;
    }

    public void setUnknownParameter(java.lang.String unknownParameter)
    {
        this.unknownParameter = unknownParameter;
    }

    /**
     * 
     */
    public java.lang.String getUnknownParameter()
    {
        return this.unknownParameter;
    }
    
    public java.lang.Object[] getUnknownParameterBackingList()
    {
        java.lang.Object[] values = this.unknownParameterValueList;
        java.lang.Object[] labels = this.unknownParameterLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getUnknownParameterValueList()
    {
        return this.unknownParameterValueList;
    }

    public void setUnknownParameterValueList(java.lang.Object[] unknownParameterValueList)
    {
        this.unknownParameterValueList = unknownParameterValueList;
    }

    public java.lang.Object[] getUnknownParameterLabelList()
    {
        return this.unknownParameterLabelList;
    }

    public void setUnknownParameterLabelList(java.lang.Object[] unknownParameterLabelList)
    {
        this.unknownParameterLabelList = unknownParameterLabelList;
    }

    public void setUnknownParameterBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setUnknownParameterBackingList requires non-null property arguments");
        }

        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;

        if (items != null)
        {
            this.unknownParameterValueList = new java.lang.Object[items.size()];
            this.unknownParameterLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.unknownParameterValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.unknownParameterLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setUnknownParameterBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>formParam1</code>.
     */
    public void resetFormParam1()
    {
        this.formParam1 = 0;
    }

    public void setFormParam1(int formParam1)
    {
        this.formParam1 = formParam1;
    }

    /**
     * 
     */
    public int getFormParam1()
    {
        return this.formParam1;
    }
    
    public java.lang.Object[] getFormParam1BackingList()
    {
        java.lang.Object[] values = this.formParam1ValueList;
        java.lang.Object[] labels = this.formParam1LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFormParam1ValueList()
    {
        return this.formParam1ValueList;
    }

    public void setFormParam1ValueList(java.lang.Object[] formParam1ValueList)
    {
        this.formParam1ValueList = formParam1ValueList;
    }

    public java.lang.Object[] getFormParam1LabelList()
    {
        return this.formParam1LabelList;
    }

    public void setFormParam1LabelList(java.lang.Object[] formParam1LabelList)
    {
        this.formParam1LabelList = formParam1LabelList;
    }

    public void setFormParam1BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setFormParam1BackingList requires non-null property arguments");
        }

        this.formParam1ValueList = null;
        this.formParam1LabelList = null;

        if (items != null)
        {
            this.formParam1ValueList = new java.lang.Object[items.size()];
            this.formParam1LabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.formParam1ValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.formParam1LabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setFormParam1BackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>tableDataNotSortable</code>.
     */
    public void resetTableDataNotSortable()
    {
        this.tableDataNotSortable = null;
    }

    public void setTableDataNotSortable(java.util.Collection tableDataNotSortable)
    {
        this.tableDataNotSortable = tableDataNotSortable;
    }

    /**
     * 
     */
    public java.util.Collection getTableDataNotSortable()
    {
        return this.tableDataNotSortable;
    }

    public void setTableDataNotSortableAsArray(Object[] tableDataNotSortable)
    {
        this.tableDataNotSortable = (tableDataNotSortable == null) ? null : java.util.Arrays.asList(tableDataNotSortable);
    }

    /**
     * Returns this collection as an array, if the collection itself would be <code>null</code> this method
     * will also return <code>null</code>.
     *
     * @see org.andromda.cartridges.bpm4struts.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl#getTableDataNotSortable
     */
    public java.lang.Object[] getTableDataNotSortableAsArray()
    {
        return (tableDataNotSortable == null) ? null : tableDataNotSortable.toArray();
    }
    
    public java.lang.Object[] getTableDataNotSortableBackingList()
    {
        java.lang.Object[] values = this.tableDataNotSortableValueList;
        java.lang.Object[] labels = this.tableDataNotSortableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getTableDataNotSortableValueList()
    {
        return this.tableDataNotSortableValueList;
    }

    public void setTableDataNotSortableValueList(java.lang.Object[] tableDataNotSortableValueList)
    {
        this.tableDataNotSortableValueList = tableDataNotSortableValueList;
    }

    public java.lang.Object[] getTableDataNotSortableLabelList()
    {
        return this.tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableLabelList(java.lang.Object[] tableDataNotSortableLabelList)
    {
        this.tableDataNotSortableLabelList = tableDataNotSortableLabelList;
    }

    public void setTableDataNotSortableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setTableDataNotSortableBackingList requires non-null property arguments");
        }

        this.tableDataNotSortableValueList = null;
        this.tableDataNotSortableLabelList = null;

        if (items != null)
        {
            this.tableDataNotSortableValueList = new java.lang.Object[items.size()];
            this.tableDataNotSortableLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.tableDataNotSortableValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.tableDataNotSortableLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setTableDataNotSortableBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * Resets the given <code>fourth</code>.
     */
    public void resetFourth()
    {
        this.fourth = null;
    }

    public void setFourth(java.lang.String fourth)
    {
        this.fourth = fourth;
    }

    /**
     * 
     */
    public java.lang.String getFourth()
    {
        return this.fourth;
    }
    
    public java.lang.Object[] getFourthBackingList()
    {
        java.lang.Object[] values = this.fourthValueList;
        java.lang.Object[] labels = this.fourthLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        java.lang.Object[] backingList = new java.lang.Object[length];

        for (int i=0; i<length; i++)
        {
            backingList[i] = new LabelValue(labels[i], values[i]);
        }

        return backingList;
    }

    public java.lang.Object[] getFourthValueList()
    {
        return this.fourthValueList;
    }

    public void setFourthValueList(java.lang.Object[] fourthValueList)
    {
        this.fourthValueList = fourthValueList;
    }

    public java.lang.Object[] getFourthLabelList()
    {
        return this.fourthLabelList;
    }

    public void setFourthLabelList(java.lang.Object[] fourthLabelList)
    {
        this.fourthLabelList = fourthLabelList;
    }

    public void setFourthBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataActionWithBadTableLinkFormImpl.setFourthBackingList requires non-null property arguments");
        }

        this.fourthValueList = null;
        this.fourthLabelList = null;

        if (items != null)
        {
            this.fourthValueList = new java.lang.Object[items.size()];
            this.fourthLabelList = new java.lang.Object[items.size()];

            try
            {
                int i = 0;
                for (java.util.Iterator iterator = items.iterator(); iterator.hasNext(); i++)
                {
                    final java.lang.Object item = iterator.next();

                    this.fourthValueList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.fourthLabelList[i] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (Exception ex)
            {
                throw new java.lang.RuntimeException("ShowTableDataActionWithBadTableLinkFormImpl.setFourthBackingList encountered an exception", ex);
            }
        }
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        this.firstRowSelection = null;
        this.multiboxThing = null;
        this.thisOneShouldbeNamedFirstRowSelection = null;
    }

    public java.lang.String toString()
    {
        org.apache.commons.lang.builder.ToStringBuilder builder =
            new org.apache.commons.lang.builder.ToStringBuilder(this);
        builder.append("thisParameterNameDoesNotExistAsTableColumn", this.thisParameterNameDoesNotExistAsTableColumn);
        builder.append("firstRowSelection", this.firstRowSelection);
        builder.append("multiboxThing", this.multiboxThing);
        builder.append("parameterWithDefaultValue", this.parameterWithDefaultValue);
        builder.append("tableData", this.tableData);
        builder.append("third", this.third);
        builder.append("second", this.second);
        builder.append("thisOneShouldbeNamedFirstRowSelection", this.thisOneShouldbeNamedFirstRowSelection);
        builder.append("formParam2", this.formParam2);
        builder.append("tableDataNoExportTypes", this.tableDataNoExportTypes);
        builder.append("tableDataDefaultExportTypes", this.tableDataDefaultExportTypes);
        builder.append("two", this.two);
        builder.append("unknownParameter", this.unknownParameter);
        builder.append("formParam1", this.formParam1);
        builder.append("tableDataNotSortable", this.tableDataNotSortable);
        builder.append("fourth", this.fourth);
        return builder.toString();
    }

    /**
     * Allows you to clean all values from this form. Objects will be set to <code>null</code>, numeric values will be
     * set to zero and boolean values will be set to <code>false</code>. Backinglists for selectable fields will
     * also be set to <code>null</code>.
     */
    public void clean()
    {
        this.thisParameterNameDoesNotExistAsTableColumn = null;
        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;
        this.firstRowSelection = null;
        this.multiboxThing = null;
        this.multiboxThingValueList = null;
        this.multiboxThingLabelList = null;
        this.parameterWithDefaultValue = null;
        this.parameterWithDefaultValueValueList = null;
        this.parameterWithDefaultValueLabelList = null;
        this.tableData = null;
        this.tableDataValueList = null;
        this.tableDataLabelList = null;
        this.third = null;
        this.thirdValueList = null;
        this.thirdLabelList = null;
        this.second = null;
        this.secondValueList = null;
        this.secondLabelList = null;
        this.thisOneShouldbeNamedFirstRowSelection = null;
        this.formParam2 = null;
        this.formParam2ValueList = null;
        this.formParam2LabelList = null;
        this.tableDataNoExportTypes = null;
        this.tableDataNoExportTypesValueList = null;
        this.tableDataNoExportTypesLabelList = null;
        this.tableDataDefaultExportTypes = null;
        this.tableDataDefaultExportTypesValueList = null;
        this.tableDataDefaultExportTypesLabelList = null;
        this.two = null;
        this.twoValueList = null;
        this.twoLabelList = null;
        this.unknownParameter = null;
        this.unknownParameterValueList = null;
        this.unknownParameterLabelList = null;
        this.formParam1 = 0;
        this.formParam1ValueList = null;
        this.formParam1LabelList = null;
        this.tableDataNotSortable = null;
        this.tableDataNotSortableValueList = null;
        this.tableDataNotSortableLabelList = null;
        this.fourth = null;
        this.fourthValueList = null;
        this.fourthLabelList = null;
    }

    /**
     * Override to provide population of current form with request parameters when validation fails.
     *
     * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.ActionMapping, javax.servlet.http.HttpServletRequest)
     */
    public org.apache.struts.action.ActionErrors validate(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        final org.apache.struts.action.ActionErrors errors = super.validate(mapping, request);
        if (errors != null && !errors.isEmpty())
        {
            // we populate the current form with only the request parameters
            Object currentForm = request.getSession().getAttribute("form");
            // if we can't get the 'form' from the session, try from the request
            if (currentForm == null)
            {
                currentForm = request.getAttribute("form");
            }
            if (currentForm != null)
            {
                final java.util.Map parameters = new java.util.HashMap();
                for (final java.util.Enumeration names = request.getParameterNames(); names.hasMoreElements();)
                {
                    final String name = String.valueOf(names.nextElement());
                    parameters.put(name, request.getParameter(name));
                }
                try
                {
                    org.apache.commons.beanutils.BeanUtils.populate(currentForm, parameters);
                }
                catch (java.lang.Exception populateException)
                {
                    // ignore if we have an exception here (we just don't populate).
                }
            }
        }
        return errors;
    }

    public final static class LabelValue
    {
        private java.lang.Object label = null;
        private java.lang.Object value = null;

        public LabelValue(Object label, java.lang.Object value)
        {
            this.label = label;
            this.value = value;
        }

        public java.lang.Object getLabel()
        {
            return this.label;
        }

        public java.lang.Object getValue()
        {
            return this.value;
        }

        public java.lang.String toString()
        {
            return label + "=" + value;
        }
    }
}