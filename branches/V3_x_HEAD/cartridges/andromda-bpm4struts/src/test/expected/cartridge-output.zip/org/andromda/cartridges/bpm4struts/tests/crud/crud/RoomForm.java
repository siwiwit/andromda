/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.crud.crud;

public final class RoomForm
    extends org.apache.struts.validator.ValidatorForm
    implements java.io.Serializable
{
    private java.util.List manageableList = null;

    public java.util.List getManageableList()
    {
        return this.manageableList;
    }

    public void setManageableList(java.util.List manageableList)
    {
        this.manageableList = manageableList;
    }

    private java.lang.Long[] selectedRows = null;

    public java.lang.Long[] getSelectedRows()
    {
        return this.selectedRows;
    }

    public void setSelectedRows(java.lang.Long[] selectedRows)
    {
        this.selectedRows = selectedRows;
    }

    private java.util.Date date;

    public java.util.Date getDate()
    {
        return this.date;
    }

    public void setDate(java.util.Date date)
    {
        this.date = date;
    }

    private static final java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("dd-MM-yyyy");
    static { dateFormatter.setLenient(false); }

    public java.lang.String getDateAsString()
    {
        return (date == null) ? null : dateFormatter.format(date);
    }

    public void setDateAsString(java.lang.String date)
    {
        try
        {
            this.date = (org.apache.commons.lang.StringUtils.isBlank(date)) ? null : dateFormatter.parse(date);
        }
        catch (java.text.ParseException pe)
        {
            throw new java.lang.RuntimeException(pe);
        }
    }

    private java.lang.Long specificId;

    public java.lang.Long getSpecificId()
    {
        return this.specificId;
    }

    public void setSpecificId(java.lang.Long specificId)
    {
        this.specificId = specificId;
    }

    private java.lang.Long[] gardens;

    public java.lang.Long[] getGardens()
    {
        return this.gardens;
    }

    public void setGardens(java.lang.Long[] gardens)
    {
        this.gardens = gardens;
    }

    private java.util.List gardensBackingList;

    public java.util.List getGardensBackingList()
    {
        return this.gardensBackingList;
    }

    public void setGardensBackingList(java.util.List gardensBackingList)
    {
        this.gardensBackingList = gardensBackingList;
    }

    private java.lang.Long named;

    public java.lang.Long getNamed()
    {
        return this.named;
    }

    public void setNamed(java.lang.Long named)
    {
        this.named = named;
    }

    private java.util.List namedBackingList;

    public java.util.List getNamedBackingList()
    {
        return this.namedBackingList;
    }

    public void setNamedBackingList(java.util.List namedBackingList)
    {
        this.namedBackingList = namedBackingList;
    }

    /**
     * @see org.apache.struts.validator.ValidatorForm#reset(org.apache.struts.action.ActionMapping,javax.servlet.http.HttpServletRequest)
     */
    public void reset(org.apache.struts.action.ActionMapping mapping, javax.servlet.http.HttpServletRequest request)
    {
        date = null;
        specificId = null;
        gardens = null;
        gardensBackingList = null;
        named = null;
        namedBackingList = null;
    }
}