/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.crud.crud;

import org.apache.struts.actions.DispatchAction;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

public final class ManageHouse extends DispatchAction
{
    public ActionForward execute(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        request.getSession().setAttribute("manageableForm", actionForm);
        return super.execute(mapping, actionForm, request, response);
    }

    public ActionForward create(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm)actionForm;

        if (StringUtils.isNotBlank(request.getParameter("enumAttribute")) && !org.andromda.cartridges.bpm4struts.tests.crud.Futurenum.literals().contains(form.getEnumAttribute()))
        {
            throw new IllegalArgumentException("enumAttribute must be  one of " + org.andromda.cartridges.bpm4struts.tests.crud.Futurenum.literals());
        }

        .create(
            (StringUtils.isBlank(request.getParameter("something"))) ? null : form.getSomething()
            , (StringUtils.isBlank(request.getParameter("enumAttribute"))) ? null : org.andromda.cartridges.bpm4struts.tests.crud.Futurenum.fromString(form.getEnumAttribute())
            , (StringUtils.isBlank(request.getParameter("id"))) ? null : form.getId()
            , (StringUtils.isBlank(request.getParameter("gardens"))) ? null : form.getGardens()
            , (StringUtils.isBlank(request.getParameter("room"))) ? null : form.getRoom()
        );

        return preload(mapping, actionForm, request, response);
    }

    public ActionForward read(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm)actionForm;

        final java.util.List list = .read(
            (StringUtils.isBlank(request.getParameter("something"))) ? null : form.getSomething()
            , (StringUtils.isBlank(request.getParameter("enumAttribute"))) ? null : org.andromda.cartridges.bpm4struts.tests.crud.Futurenum.fromString(form.getEnumAttribute())
            , (StringUtils.isBlank(request.getParameter("id"))) ? null : form.getId()
            , (StringUtils.isBlank(request.getParameter("gardens"))) ? null : form.getGardens()
            , (StringUtils.isBlank(request.getParameter("room"))) ? null : form.getRoom()
        );
        form.setManageableList(list);

        if (list.size() >= 250)
        {
            saveMaxResultsWarning(request);
        }

        final java.util.Map backingLists = .readBackingLists();
        form.setGardensBackingList((java.util.List)backingLists.get("gardens"));
        form.setRoomBackingList((java.util.List)backingLists.get("room"));

        return mapping.getInputForward();
    }

    public ActionForward preload(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm)actionForm;

        final java.util.List list = .readAll();
        form.setManageableList(list);


        if (list.size() >= 250)
        {
            saveMaxResultsWarning(request);
        }

        final java.util.Map backingLists = .readBackingLists();
        if (StringUtils.isNotBlank(request.getParameter("ref_Garden")))
        {
            final java.lang.Long[] array = new java.lang.Long[1];
            array[0] = new java.lang.Long(request.getParameter("ref_Garden"));
            form.setGardens(array);
        }
        form.setGardensBackingList((java.util.List)backingLists.get("gardens"));
        if (StringUtils.isNotBlank(request.getParameter("ref_Room")))
        {
            form.setRoom(new java.lang.Long(request.getParameter("ref_Room")));
        }
        form.setRoomBackingList((java.util.List)backingLists.get("room"));

        return mapping.getInputForward();
    }

    protected ActionForward unspecified(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        return preload(mapping, actionForm, request, response);
    }

    public ActionForward update(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm) actionForm;

        if (StringUtils.isNotBlank(request.getParameter("enumAttribute")) && !org.andromda.cartridges.bpm4struts.tests.crud.Futurenum.literals().contains(form.getEnumAttribute()))
        {
            throw new IllegalArgumentException("enumAttribute must be  one of " + org.andromda.cartridges.bpm4struts.tests.crud.Futurenum.literals());
        }

        .update(
            (StringUtils.isBlank(request.getParameter("something"))) ? null : form.getSomething()
            , (StringUtils.isBlank(request.getParameter("enumAttribute"))) ? null : org.andromda.cartridges.bpm4struts.tests.crud.Futurenum.fromString(form.getEnumAttribute())
            , (StringUtils.isBlank(request.getParameter("id"))) ? null : form.getId()
            , (StringUtils.isBlank(request.getParameter("gardens"))) ? null : form.getGardens()
            , (StringUtils.isBlank(request.getParameter("room"))) ? null : form.getRoom()
        );

        return preload(mapping, actionForm, request, response);
    }

    public ActionForward delete(ActionMapping mapping, ActionForm actionForm, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        final org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm form = (org.andromda.cartridges.bpm4struts.tests.crud.crud.HouseForm) actionForm;

        final java.lang.Long[] selectedRows = form.getSelectedRows();
        if (selectedRows != null && selectedRows.length > 0)
        {
            .delete(selectedRows);
        }

        return preload(mapping, actionForm, request, response);
    }

    private void saveMaxResultsWarning(HttpServletRequest request)
    {
        final HttpSession session = request.getSession();

        ActionMessages messages = (ActionMessages)session.getAttribute(org.apache.struts.Globals.MESSAGE_KEY);
        if (messages == null)
        {
            messages = new ActionMessages();
            session.setAttribute(org.apache.struts.Globals.MESSAGE_KEY, messages);
        }
        messages.add("org.andromda.bpm4struts.warningmessages", new ActionMessage("maximum.results.fetched.warning", "250"));
    }

}
