// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.meta;

/**
 * @see org.andromda.cartridges.meta.AwithOperations
 */
public class AwithOperationsImpl
    extends org.andromda.cartridges.meta.AwithOperations
{
    public AwithOperationsImpl()
    {
        super();
    }

    public AwithOperationsImpl(int x)
    {
        super(x);
    }

    /**
     * Copy-constructor from other AwithOperations
     *
     * @param otherBean, cannot be <code>null</code>
     * @throws java.lang.NullPointerException if the argument is <code>null</code>
     */
    public AwithOperationsImpl(AwithOperations otherBean)
    {
        this(otherBean.getX());
    }

    /**
     * @see org.andromda.cartridges.meta.AwithOperations#operation1()
     */
    public void operation1()
    {
        // @todo implement public void operation1()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.meta.AwithOperations.operation1() Not implemented!");
    }

}
