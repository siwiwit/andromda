//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface OperationTestMetafacade
    extends org.andromda.metafacades.uml.OperationFacade
{

    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return always <code>true</code>
     */
    public boolean isOperationTestMetafacadeMetaType();

   /**
    * 
    */
    public org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier();

   /**
    * 
    */
    public boolean isTestAttribute();

}