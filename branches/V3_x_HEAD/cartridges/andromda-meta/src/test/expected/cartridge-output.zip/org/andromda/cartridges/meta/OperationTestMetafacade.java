// license-header java merge-point
//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface OperationTestMetafacade
    extends org.andromda.metafacades.uml.OperationFacade
{

    /**
     * Indicates the metafacade type (used for metafacade mappings).
     *
     * @return boolean always <code>true</code>
     */
    public boolean isOperationTestMetafacadeMetaType();

   /**
    * 
    * @return org.andromda.cartridges.meta.ClassifierTestMetafacade
    */
    public org.andromda.cartridges.meta.ClassifierTestMetafacade getTestClassifier();

   /**
    * 
    * @return boolean
    */
    public boolean isTestAttribute();
}