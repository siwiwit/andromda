// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.meta;

/**
 * @see org.andromda.cartridges.meta.CostPosition
 */
public class CostPositionImpl
    extends org.andromda.cartridges.meta.CostPosition
{
    public CostPositionImpl()
    {
        super();
    }

    public CostPositionImpl(java.lang.String name, double price)
    {
        super(name, price);
    }

    /**
     * Copy-constructor from other CostPosition
     *
     * @param otherBean, cannot be <code>null</code>
     * @throws java.lang.NullPointerException if the argument is <code>null</code>
     */
    public CostPositionImpl(CostPosition otherBean)
    {
        this(otherBean.getName(), otherBean.getPrice());
    }

    /**
     * @see org.andromda.cartridges.meta.CostPosition#calcTotal()
     */
    public double calcTotal()
    {
        // @todo implement public double calcTotal()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.meta.CostPosition.calcTotal() Not implemented!");
    }

}
