// license-header java merge-point
/**
 * This is only generated once! It will never be overwritten.
 * You can (and have to!) safely modify it by hand.
 */
package org.andromda.cartridges.meta;

/**
 * @see org.andromda.cartridges.meta.CompositeCostPosition
 */
public class CompositeCostPositionImpl
    extends org.andromda.cartridges.meta.CompositeCostPosition
{
    public CompositeCostPositionImpl()
    {
        super();
    }

    public CompositeCostPositionImpl(java.lang.String name, double price)
    {
       super(name, price);
    }

    public CompositeCostPositionImpl(java.lang.String name, double price, java.util.Collection subPositions)
    {
        super(name, price, subPositions);
    }

    /**
     * Copy-constructor from other CompositeCostPosition
     *
     * @param otherBean, cannot be <code>null</code>
     * @throws java.lang.NullPointerException if the argument is <code>null</code>
     */
    public CompositeCostPositionImpl(CompositeCostPosition otherBean)
    {
        this(otherBean.getName(), otherBean.getPrice(), otherBean.getSubPositions());
    }

    /**
     * @see org.andromda.cartridges.meta.CompositeCostPosition#calcTotal()
     */
    public double calcTotal()
    {
        // @todo implement public double calcTotal()
        throw new java.lang.UnsupportedOperationException("org.andromda.cartridges.meta.CompositeCostPosition.calcTotal() Not implemented!");
    }

}
