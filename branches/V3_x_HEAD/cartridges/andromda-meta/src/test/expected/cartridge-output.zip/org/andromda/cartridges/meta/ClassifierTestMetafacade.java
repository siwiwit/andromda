//
// Attention: generated code (by Metafacade.vsl) - do not modify!
//
package org.andromda.cartridges.meta;

/**
 * 
 *
 * Metafacade interface to be used by AndroMDA cartridges.
 */
public interface ClassifierTestMetafacade
    extends org.andromda.metafacades.uml.ClassifierFacade
{

   /**
    * 
    */
    public java.lang.String getTestAttribute();

   /**
    * 
    */
    public java.util.Collection getTestOperations();

   /**
    * 
    */
    public boolean isTestMetafacade();

}