package org.andromda.cartridges.jsf.tests.constraints.packages.oneusecase;

/**
 * Stores all forward paths available in the use case OneUseCase UseCase2 keyed by forward name.
 */
final class OneUseCaseUseCase2Forwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("one-use-case-use-case2-usecase", "/org/andromda/cartridges/jsf/tests/constraints/packages/oneusecase/one-use-case-use-case2.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}