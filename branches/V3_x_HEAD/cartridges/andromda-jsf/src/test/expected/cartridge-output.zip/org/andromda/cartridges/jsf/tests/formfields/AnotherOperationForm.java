// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anotherOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.formfields.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.formfields.Controller#anotherOperation(java.lang.String notused, int unusedNumber)
 */
public interface AnotherOperationForm
{
    /**
     * 
     */
    public java.lang.String getNotused();

    /**
     * 
     */
    public void setNotused(java.lang.String notused);
    
    /**
     * 
     */
    public int getUnusedNumber();

    /**
     * 
     */
    public void setUnusedNumber(int unusedNumber);
    
}