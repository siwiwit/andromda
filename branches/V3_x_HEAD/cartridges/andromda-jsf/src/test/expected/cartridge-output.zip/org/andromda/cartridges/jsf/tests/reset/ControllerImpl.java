// license-header java merge-point
package org.andromda.cartridges.jsf.tests.reset;

/**
 * @see org.andromda.cartridges.jsf.tests.reset.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.reset.Controller#someOperation(java.lang.String firstParam)
     */
    public void someOperation(SomeOperationForm form) throws java.lang.Exception
    {
    }
    
}