// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * 
 */
public class State2Trigger2FormImpl
    implements java.io.Serializable, Operation2Form
{
    public State2Trigger2FormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String testParam2;

    /**
     * 
     */
    public java.lang.String getTestParam2()
    {
        return this.testParam2;
    }

    /**
     * Keeps track of whether or not the value of testParam2 has
     * be populated at least once.
     */
    private boolean testParam2Set = false;

    /**
     * Indicates whether or not the value for testParam2 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTestParam2Set()
    {
        return this.testParam2Set;
    }

    /**
     * 
     */
    public void setTestParam2(java.lang.String testParam2)
    {
        this.testParam2 = testParam2;
        this.testParam2Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] testParam2ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] testParam2LabelList;
    public java.lang.Object[] getTestParam2BackingList()
    {
        java.lang.Object[] values = this.testParam2ValueList;
        java.lang.Object[] labels = this.testParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTestParam2ValueList()
    {
        return this.testParam2ValueList;
    }

    public void setTestParam2ValueList(java.lang.Object[] testParam2ValueList)
    {
        this.testParam2ValueList = testParam2ValueList;
    }

    public java.lang.Object[] getTestParam2LabelList()
    {
        return this.testParam2LabelList;
    }

    public void setTestParam2LabelList(java.lang.Object[] testParam2LabelList)
    {
        this.testParam2LabelList = testParam2LabelList;
    }

    public void setTestParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State2Trigger2FormImpl.setTestParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.testParam2ValueList = null;
        this.testParam2LabelList = null;
        if (items != null)
        {
            this.testParam2ValueList = new java.lang.Object[items.size()];
            this.testParam2LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.testParam2ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.testParam2LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private int param4;

    /**
     * 
     */
    public int getParam4()
    {
        return this.param4;
    }

    /**
     * Keeps track of whether or not the value of param4 has
     * be populated at least once.
     */
    private boolean param4Set = false;

    /**
     * Indicates whether or not the value for param4 has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParam4Set()
    {
        return this.param4Set;
    }

    /**
     * 
     */
    public void setParam4(int param4)
    {
        this.param4 = param4;
        this.param4Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] param4ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] param4LabelList;
    public java.lang.Object[] getParam4BackingList()
    {
        java.lang.Object[] values = this.param4ValueList;
        java.lang.Object[] labels = this.param4LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getParam4ValueList()
    {
        return this.param4ValueList;
    }

    public void setParam4ValueList(java.lang.Object[] param4ValueList)
    {
        this.param4ValueList = param4ValueList;
    }

    public java.lang.Object[] getParam4LabelList()
    {
        return this.param4LabelList;
    }

    public void setParam4LabelList(java.lang.Object[] param4LabelList)
    {
        this.param4LabelList = param4LabelList;
    }

    public void setParam4BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State2Trigger2FormImpl.setParam4BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.param4ValueList = null;
        this.param4LabelList = null;
        if (items != null)
        {
            this.param4ValueList = new java.lang.Object[items.size()];
            this.param4LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.param4ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.param4LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private int decisionTestParam;

    /**
     * 
     */
    public int getDecisionTestParam()
    {
        return this.decisionTestParam;
    }

    /**
     * Keeps track of whether or not the value of decisionTestParam has
     * be populated at least once.
     */
    private boolean decisionTestParamSet = false;

    /**
     * Indicates whether or not the value for decisionTestParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDecisionTestParamSet()
    {
        return this.decisionTestParamSet;
    }

    /**
     * 
     */
    public void setDecisionTestParam(int decisionTestParam)
    {
        this.decisionTestParam = decisionTestParam;
        this.decisionTestParamSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] decisionTestParamValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] decisionTestParamLabelList;
    public java.lang.Object[] getDecisionTestParamBackingList()
    {
        java.lang.Object[] values = this.decisionTestParamValueList;
        java.lang.Object[] labels = this.decisionTestParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getDecisionTestParamValueList()
    {
        return this.decisionTestParamValueList;
    }

    public void setDecisionTestParamValueList(java.lang.Object[] decisionTestParamValueList)
    {
        this.decisionTestParamValueList = decisionTestParamValueList;
    }

    public java.lang.Object[] getDecisionTestParamLabelList()
    {
        return this.decisionTestParamLabelList;
    }

    public void setDecisionTestParamLabelList(java.lang.Object[] decisionTestParamLabelList)
    {
        this.decisionTestParamLabelList = decisionTestParamLabelList;
    }

    public void setDecisionTestParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State2Trigger2FormImpl.setDecisionTestParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.decisionTestParamValueList = null;
        this.decisionTestParamLabelList = null;
        if (items != null)
        {
            this.decisionTestParamValueList = new java.lang.Object[items.size()];
            this.decisionTestParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.decisionTestParamValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.decisionTestParamLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String testParam;

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }

    /**
     * Keeps track of whether or not the value of testParam has
     * be populated at least once.
     */
    private boolean testParamSet = false;

    /**
     * Indicates whether or not the value for testParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTestParamSet()
    {
        return this.testParamSet;
    }

    /**
     * 
     */
    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
        this.testParamSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] testParamValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] testParamLabelList;
    public java.lang.Object[] getTestParamBackingList()
    {
        java.lang.Object[] values = this.testParamValueList;
        java.lang.Object[] labels = this.testParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTestParamValueList()
    {
        return this.testParamValueList;
    }

    public void setTestParamValueList(java.lang.Object[] testParamValueList)
    {
        this.testParamValueList = testParamValueList;
    }

    public java.lang.Object[] getTestParamLabelList()
    {
        return this.testParamLabelList;
    }

    public void setTestParamLabelList(java.lang.Object[] testParamLabelList)
    {
        this.testParamLabelList = testParamLabelList;
    }

    public void setTestParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("State2Trigger2FormImpl.setTestParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.testParamValueList = null;
        this.testParamLabelList = null;
        if (items != null)
        {
            this.testParamValueList = new java.lang.Object[items.size()];
            this.testParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.testParamValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.testParamLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();
    
    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     * 
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }
    
    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message 
     * instances stored within this form.
     * 
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 3119262259452261955L;
}