package org.andromda.presentation.jsf;

import org.apache.commons.lang.StringUtils;

/**
 * Utilities used within the JSF Cartridge
 * 
 * @author Chad Brandon
 */
public class JsfUtils
{
    /**
     * The location of the temporary directoy used the JSF cartridge.
     */
    private static final String TEMPORARY_DIRECTORY;

    /**
     * Perform any constant initialization.
     */
    static
    {
        // - initialize the TEMPORARY_DIRECTORY
        final String tmpDir = System.getProperty("java.io.tmpdir");
        final StringBuffer directory = new StringBuffer(tmpDir);
        if (!directory.toString().endsWith("/"))
        {
            directory.append("/");
        }
        final String userName = System.getProperty("user.name");
        if (StringUtils.isNotBlank(userName))
        {
            directory.append(userName).append("/");
        }
        directory.append(".andromda/jsf-cartridge/");
        TEMPORARY_DIRECTORY = directory.toString();
    }
    
    /**
     * Attempts to serialize the given <code>form</code> to disk so that it
     * can later be retrieved when the user's session times out.
     * @param session the session from which to create the serialization path.
     * @param form the form to serialize.
     */
    public static void serializeForm(final javax.servlet.http.HttpSession session, final Object form)
    {
        java.io.ObjectOutputStream objectStream = null;
        try
        {
            final java.io.File serializationFile = new java.io.File(getFormSerializationPath(session));
            final java.io.File parent = serializationFile.getParentFile();
            if (parent != null)
            {
                parent.mkdirs();
            }
            final java.io.FileOutputStream fileStream = new java.io.FileOutputStream(serializationFile.toString());
            objectStream = new java.io.ObjectOutputStream(fileStream);
            objectStream.writeObject(form);
        }
        catch (final Exception exception)
        {
            // - ignore if we couldn't serialize the form.
        }
        finally
        {
            if (objectStream != null)
            {
                try
                {
                    objectStream.close();
                }
                catch (java.io.IOException exception)
                {
                    // - ignore
                }
            }
        }
    }
    
    /**
     * Retrieves the current serialized form for the given session.
     * @param session the session.
     * @return the serialized form.
     * @throws Exception
     */
    public static Object getSerializedForm(final javax.servlet.http.HttpSession session)
    {
        Object form = null;
        java.io.ObjectInputStream objectStream = null;
        try
        {
            java.io.FileInputStream fileStream = new java.io.FileInputStream(getFormSerializationPath(session));
            objectStream = new java.io.ObjectInputStream(fileStream);
            form = objectStream.readObject();
        }
        catch (final Exception exception)
        {
            // - ignore if we couldn't retrieve the serialized form
        }
        finally
        {
            if (objectStream != null)
            {
                try
                {
                    objectStream.close();
                }
                catch (java.io.IOException exception)
                {
                    // - ignore
                }
            }
        }
        return form;
    }
    
    /**
     * Removes the serialized form (if present) for the given <code>session</code>
     * 
     * @param session the session for which to remove the serialized form.
     */
    public static void deleteSerializedForm(final javax.servlet.http.HttpSession session)
    {
        final java.io.File serializationFile = 
            new java.io.File(getFormSerializationPath(session));
        serializationFile.delete();
        final java.io.File directory = serializationFile.getParentFile();
        if (directory != null)
        {
            directory.delete();
        }
    }
   
    /**
     * The name of the file storing the serialized form.
     */
    private static final String SERIALIZED_FORM_FILE_NAME = "/form.ser";
    
    /**
     * Retrieves the path in which the serialized form will be stored.
     * @param session the session containing the unique id in which to create the path.
     * @return the path to which serialization occurs.
     */
    private static String getFormSerializationPath(final javax.servlet.http.HttpSession session)
    {
        return TEMPORARY_DIRECTORY + session.getId() + SERIALIZED_FORM_FILE_NAME;
    }
    
    /**
     * The pattern used for matching the message key.
     */
    private static final java.util.regex.Pattern messageKeyPattern = java.util.regex.Pattern.compile("(.*)(\\{\\s*([\\w|\\.+]*)\\s*\\})(.*)");
    
    /**
     * Attempts to extract a resource key from the given message based on a specified pattern.
     *
     * @param message the message from which to extract the key
     * @return the retrieved string matching the pattern.
     */
    public static String extractMessageKey(String message)
    {
        String matched = null;
        if (message != null)
        {
            final java.util.regex.Matcher matcher = messageKeyPattern.matcher(message.replaceAll("[\\s]+", " "));
            try
            {
                if (matcher.matches())
                {
                    matched = matcher.group(3);
                }
            }
            catch (java.lang.IllegalStateException ex)
            {
                // no match was found ignore
            }
        }
        return matched;
    }
}
