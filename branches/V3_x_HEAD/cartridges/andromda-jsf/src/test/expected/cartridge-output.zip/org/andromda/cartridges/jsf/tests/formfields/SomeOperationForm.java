// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>someOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.formfields.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.formfields.Controller#someOperation(java.util.Date date, int number, java.util.Collection collection, java.lang.String selectable, java.io.File file, java.lang.Integer integerClass, java.util.Set setClass, java.util.Map mapClass, java.lang.Boolean booleanClass, boolean bool, java.lang.Float floatClass)
 */
public interface SomeOperationForm
{
    /**
     * 
     */
    public java.util.Date getDate();

    /**
     * 
     */
    public void setDate(java.util.Date date);
    
    /**
     * 
     */
    public int getNumber();

    /**
     * 
     */
    public void setNumber(int number);
    
    /**
     * 
     */
    public java.util.List getCollection();

    /**
     * 
     */
    public void setCollection(java.util.List collection);
    
    /**
     * 
     */
    public java.lang.String getSelectable();

    /**
     * 
     */
    public void setSelectable(java.lang.String selectable);

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the current elements from that list.
     * <p>
     * <i>Please note that the elements from that list are key value pairs, so you will
     * need to call <code>getLabel()</code> and <code>getValue()</code> to get the label and
     * value for this entry respectively.</i>
     *
     * @see #getSelectable()
     * @see #getSelectableValueList()
     * @see #getSelectableLabelList()
     * @see @see #setSelectableLabelList(java.util.Collection, java.lang.String, java.lang.String)
     * @see #setSelectableLabelList(java.util.Collection, java.lang.String, java.lang.String, java.lang.Class)
     */
    public java.lang.Object[] getSelectableBackingList();

    /**
     * Convenient method to quickly set the value and label backing list for the
     * selectable property. This method takes a collection of objects, as well as
     * the property names to query these objects in order to find the corresponding
     * values and labels.
     * <p>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the selectable backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setSelectableBackingList(valueObjects, "id", "name")</code>
     * <p>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @param labelProperty the name of the property to query on each object to retrieve
     *        the corresponding label, cannot be <code>null</code>
     * @param valuePropertyType the type to convert the valueProperty.  If null, no conversion is attempted.
     *        You'll want to specify this when (for example) the type of your valueProperties is of java.lang.String and
     *        you want it to be converted to java.lang.Long.  If the value can not be converted, no conversion
     *        occurs and the method backing list will be populated with values of the existing type.
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or
     *         if the caller does not have access one of the object's properties, if an exception was thrown while
     *         accessing a property or if the property does not exist on at least one of the items
     *
     * @see #getSelectable()
     * @see #getSelectableValueList()
     * @see #getSelectableLabelList()
     * @see #getSelectableLabelList()
     */
    public void setSelectableBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType);
    
    /**
     * Convenient method to quickly set the value and label backing list for the
     * selectable property. This method takes a collection of objects, as well as
     * the property names to query these objects in order to find the corresponding
     * values and labels.
     * <p>
     * Let's say you have a set of value objects with the following properties:
     * <ul>
     *  <li><code>id</code></li>
     *  <li><code>code</code></li>
     *  <li><code>name</code></li>
     *  <li><code>description</code></li>
     * </ul>
     * But you need to populate the selectable backing list with the <code>id</code> properties as the values and the
     * <code>name</code> properties as the labels then you would make a call like this:
     * <code>setSelectableBackingList(valueObjects, "id", "name")</code>
     * <p>
     * This method knows how to handle primitive property types as it simply delegates to
     * <code>org.apache.commons.beanutils.PropertyUtils.getProperty(Object, String)</code>.
     *
     * @param items The items from which to read the properties, if this argument is <code>null</code> this method
     *        will simply clear the existing values and labels
     * @param valueProperty the name of the property to query on each object to retrieve
     *        the corresponding value, cannot be <code>null</code>
     * @param labelProperty the name of the property to query on each object to retrieve
     *        the corresponding label, cannot be <code>null</code>
     * @throws java.lang.IllegalArgumentException if the valueProperty or labelProperty is <code>null</code>
     * @throws java.lang.RuntimeException if one of the items in the collection is <code>null</code>, or
     *         if the caller does not have access one of the object's properties, if an exception was thrown while
     *         accessing a property or if the property does not exist on at least one of the items
     *
     * @see #getSelectable()
     * @see #getSelectableValueList()
     * @see #getSelectableLabelList()
     * @see #getSelectableLabelList()
     */
    public void setSelectableBackingList(java.util.Collection items, String valueProperty, String labelProperty);

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the values from that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public java.lang.Object[] getSelectableValueList();

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to set the values for that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public void setSelectableValueList(java.lang.Object[] selectableValueList);

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to retrieve the labels from that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public java.lang.Object[] getSelectableLabelList();

    /**
     * The <code>selectable</code> field can be selected from a list,
     * this method allows you to set the labels for that list.
     *
     * @see #getSelectable()
     * @see #getSelectableBackingList()
     */
    public void setSelectableLabelList(java.lang.Object[] selectableLabelList);
    
    /**
     * 
     */
    public boolean isBool();

    /**
     * 
     */
    public void setBool(boolean bool);
    
    /**
     * 
     */
    public oracle.adf.view.faces.model.UploadedFile getFile();

    /**
     * 
     */
    public void setFile(oracle.adf.view.faces.model.UploadedFile file);
    
    /**
     * 
     */
    public java.lang.Integer getIntegerClass();

    /**
     * 
     */
    public void setIntegerClass(java.lang.Integer integerClass);
    
    /**
     * 
     */
    public java.util.List getSetClass();

    /**
     * 
     */
    public void setSetClass(java.util.List setClass);
    
    /**
     * 
     */
    public java.util.Map getMapClass();

    /**
     * 
     */
    public void setMapClass(java.util.Map mapClass);
    
    /**
     * 
     */
    public java.lang.Boolean getBooleanClass();

    /**
     * 
     */
    public void setBooleanClass(java.lang.Boolean booleanClass);
    
    /**
     * 
     */
    public java.lang.Float getFloatClass();

    /**
     * 
     */
    public void setFloatClass(java.lang.Float floatClass);
    
}