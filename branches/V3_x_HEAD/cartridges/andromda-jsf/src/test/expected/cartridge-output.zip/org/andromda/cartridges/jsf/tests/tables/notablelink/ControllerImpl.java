// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.notablelink;

/**
 * @see org.andromda.cartridges.jsf.tests.tables.notablelink.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.tables.notablelink.Controller#loadTableData()
     */
    public void loadTableData()
    {
    }
    
    /**
     * This dummy variable is used to populate the "tableData" table.
     * You may delete it when you add you own code in this controller.
     */
    private static final java.util.List tableData =
        java.util.Arrays.asList(new Object[] {
            new TableData("first.name-1", "second-1", "third-1", "fourth-1", "fifth.name-1"),
            new TableData("first.name-2", "second-2", "third-2", "fourth-2", "fifth.name-2"),
            new TableData("first.name-3", "second-3", "third-3", "fourth-3", "fifth.name-3"),
            new TableData("first.name-4", "second-4", "third-4", "fourth-4", "fifth.name-4"),
            new TableData("first.name-5", "second-5", "third-5", "fourth-5", "fifth.name-5"),
            new TableData("first.name-6", "second-6", "third-6", "fourth-6", "fifth.name-6"),
            new TableData("first.name-7", "second-7", "third-7", "fourth-7", "fifth.name-7"),
            new TableData("first.name-8", "second-8", "third-8", "fourth-8", "fifth.name-8"),
            new TableData("first.name-9", "second-9", "third-9", "fourth-9", "fifth.name-9"),
            new TableData("first.name-10", "second-10", "third-10", "fourth-10", "fifth.name-10"),
            new TableData("first.name-11", "second-11", "third-11", "fourth-11", "fifth.name-11"),
            new TableData("first.name-12", "second-12", "third-12", "fourth-12", "fifth.name-12"),
            new TableData("first.name-13", "second-13", "third-13", "fourth-13", "fifth.name-13"),
            new TableData("first.name-14", "second-14", "third-14", "fourth-14", "fifth.name-14"),
            new TableData("first.name-15", "second-15", "third-15", "fourth-15", "fifth.name-15"),
            new TableData("first.name-16", "second-16", "third-16", "fourth-16", "fifth.name-16"),
            new TableData("first.name-17", "second-17", "third-17", "fourth-17", "fifth.name-17"),
            new TableData("first.name-18", "second-18", "third-18", "fourth-18", "fifth.name-18"),
            new TableData("first.name-19", "second-19", "third-19", "fourth-19", "fifth.name-19"),
            new TableData("first.name-20", "second-20", "third-20", "fourth-20", "fifth.name-20")
        });

    /**
     * This inner class is used in the dummy implementation in order to get the web application
     * running without any manual programming.
     * You may delete this class when you add you own code in this controller.
     */
    public static final class TableData implements java.io.Serializable
    {
        private String firstName = null;
        private String second = null;
        private String third = null;
        private String fourth = null;
        private String fifthName = null;

        public TableData(String firstName, String second, String third, String fourth, String fifthName)
        {
            this.firstName = firstName;
            this.second = second;
            this.third = third;
            this.fourth = fourth;
            this.fifthName = fifthName;
        }
        
        public void setFirstName(String firstName)
        {
            this.firstName = firstName;
        }

        public String getFirstName()
        {
            return this.firstName;
        }
        
        public void setSecond(String second)
        {
            this.second = second;
        }

        public String getSecond()
        {
            return this.second;
        }
        
        public void setThird(String third)
        {
            this.third = third;
        }

        public String getThird()
        {
            return this.third;
        }
        
        public void setFourth(String fourth)
        {
            this.fourth = fourth;
        }

        public String getFourth()
        {
            return this.fourth;
        }
        
        public void setFifthName(String fifthName)
        {
            this.fifthName = fifthName;
        }

        public String getFifthName()
        {
            return this.fifthName;
        }
        
    }
    /**
     * This dummy variable is used to populate the "customTable" table.
     * You may delete it when you add you own code in this controller.
     */
    private static final org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTable =
        new org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[]
        {
            new org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow("one-1", 2, new java.util.Date(), 4),
            new org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow("one-2", 2, new java.util.Date(), 4),
            new org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow("one-3", 2, new java.util.Date(), 4),
            new org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow("one-4", 2, new java.util.Date(), 4),
            new org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow("one-5", 2, new java.util.Date(), 4)
        };
}