// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>duplicateName</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller#duplicateName(java.lang.String diffParam)
 */
public interface DuplicateNameForm
{
    /**
     * 
     */
    public java.lang.String getDiffParam();

    /**
     * 
     */
    public void setDiffParam(java.lang.String diffParam);
    
}