package org.andromda.cartridges.jsf.tests.hyperlinkactions;

import java.io.IOException;

import javax.faces.FactoryFinder;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * This filter handles the population of forms for the <em>show something</code>
 * view.
 */
public class ShowSomethingPopulator
    implements Filter
{

    private FilterConfig config;

    /**
     * Initialize the filter
     * 
     * @param config the configuration
     * @see javax.servlet.Filter#setFilterConfig(FilterConfig)
     */
    public void init(FilterConfig config)
    {
        this.config = config;
    }

    /**
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(
        ServletRequest request,
        ServletResponse response,
        FilterChain chain) throws IOException, ServletException
    {
        this.populateFormAndViewVariables(request, response, null);
        chain.doFilter(request, response);
    }
    
    private void populateFormAndViewVariables(final ServletRequest request, final ServletResponse response, Object form)
        throws ServletException
    {
        // - we need to retrieve the faces context differently since we're outside of the
        //   faces servlet
        final LifecycleFactory lifecycleFactory =
            (LifecycleFactory)FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY);
        final Lifecycle lifecycle = lifecycleFactory.getLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE);
        final FacesContextFactory facesContextFactory =
            (FacesContextFactory)FactoryFinder.getFactory(FactoryFinder.FACES_CONTEXT_FACTORY);
        final FacesContext facesContext =
            facesContextFactory.getFacesContext(
                this.config.getServletContext(),
                request,
                response,
                lifecycle);
        final javax.faces.el.VariableResolver variableResolver = facesContext.getApplication().getVariableResolver();
        if (form == null)
        {  
            form = variableResolver.resolveVariable(facesContext, "form");
        }
        else
        {
            // - since the form argument is not null, set it as the "form" in the session 
            //   (to replace the existing "form" attribute)
            ((javax.servlet.http.HttpSession)facesContext.getExternalContext().getSession(true)).setAttribute("form", form);
        }
        try
        {
            // - populate the forms
            if (form != null)
            {    
                org.andromda.cartridges.jsf.tests.hyperlinkactions.ShowSomethingParamhrefFormImpl hyperlinkactionsShowSomethingParamhrefForm =
                    (org.andromda.cartridges.jsf.tests.hyperlinkactions.ShowSomethingParamhrefFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "hyperlinkactionsShowSomethingParamhrefForm");
                // - populate the hyperlinkactionsShowSomethingParamhrefForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, hyperlinkactionsShowSomethingParamhrefForm);
                request.setAttribute("hyperlinkactionsShowSomethingParamhrefForm", hyperlinkactionsShowSomethingParamhrefForm);
                org.andromda.cartridges.jsf.tests.hyperlinkactions.ShowSomethingNoparamhrefFormImpl hyperlinkactionsShowSomethingNoparamhrefForm =
                    (org.andromda.cartridges.jsf.tests.hyperlinkactions.ShowSomethingNoparamhrefFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "hyperlinkactionsShowSomethingNoparamhrefForm");
                // - populate the hyperlinkactionsShowSomethingNoparamhrefForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, hyperlinkactionsShowSomethingNoparamhrefForm);
                request.setAttribute("hyperlinkactionsShowSomethingNoparamhrefForm", hyperlinkactionsShowSomethingNoparamhrefForm);
            }
        }
        catch (final Throwable throwable)
        {
            throw new ServletException(throwable);
        }
    }


    /**
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy()
    {
        this.config = null;
    }
}