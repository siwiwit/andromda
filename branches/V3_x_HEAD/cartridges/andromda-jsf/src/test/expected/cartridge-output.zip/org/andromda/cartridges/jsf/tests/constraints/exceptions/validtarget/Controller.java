// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget;

/**
 * 
 */
public abstract class Controller
    implements java.io.Serializable
{

    public java.lang.String aX()
    {
        String forward = null;
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        final Object currentForm = this.resolveVariable("form");
        try
        {
            try
            {
                forward = _c();
            }
            catch (final Throwable throwable)
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _c()
    {
        java.lang.String forward = null;
        forward = ((org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget.Controller)this.resolveVariable("controller")).validExceptionTarget();
        return forward;
    }

    public java.lang.String aY()
    {
        String forward = null;
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        final Object currentForm = this.resolveVariable("form");
        try
        {
            try
            {
                forward = _b();
            }
            catch (final Throwable throwable)
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _b()
    {
        java.lang.String forward = null;
        forward = _c();
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _c()
    {
        java.lang.String forward = null;
        forward = ((org.andromda.cartridges.jsf.tests.constraints.exceptions.validtarget.Controller)this.resolveVariable("controller")).validExceptionTarget();
        return forward;
    }

    public java.lang.String validExceptionTarget()
    {
        String forward = null;
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        final Object currentForm = this.resolveVariable("form");
        try
        {
            try
            {
                forward = "valid-exception-target-a";
            }
            catch (final Throwable throwable)
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Gets the current faces context.  This object is the point
     * from which to retrieve any request, session, etc information.
     *
     * @return the JSF faces context instance.
     */
    protected javax.faces.context.FacesContext getContext()
    {
        return javax.faces.context.FacesContext.getCurrentInstance();
    }

    /**
     * A helper method that gets the current request from the faces
     * context.
     *
     * @return the current HttpServletRequest instance.
     */
    protected javax.servlet.http.HttpServletRequest getRequest()
    {
        return (javax.servlet.http.HttpServletRequest)this.getContext().getExternalContext().getRequest();
    }

    /**
     * A helper method that gets the current reponse from the faces
     * context.
     *
     * @return the current HttpServletReponse instance.
     */
    protected javax.servlet.http.HttpServletResponse getResponse()
    {
        return (javax.servlet.http.HttpServletResponse)this.getContext().getExternalContext().getResponse();
    }

    /**
     * A helper method that gets the current session from the faces
     * context.
     *
     * @param create If the create parameter is true, create (if necessary) and return a
     *        session instance associated with the current request. If the create
     *        parameter is false return any existing session instance associated with the
     *        current request, or return null if there is no such session.
     * @return the current HttpSession instance.
     */
    protected javax.servlet.http.HttpSession getSession(final boolean create)
    {
        return (javax.servlet.http.HttpSession)this.getContext().getExternalContext().getSession(create);
    }
    
    /**
     * Attempts to resolve the variable, given, the <code>name</code> of
     * the variable using the faces context variable resolver instance.
     * 
     * @return the resolved variable or null if not found.
     */
    protected java.lang.Object resolveVariable(final String name)
    {
        oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        Object variable = adfContext.getProcessScope().get(name);
        // - if we couldn't get the variable from the regular ADF context, see if
        //   the session contains an ADF context with the variable
        if (variable == null)
        {
            final javax.servlet.http.HttpSession session = this.getSession(false);
            if (session != null)
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = 
                    (org.andromda.presentation.jsf.AdfFacesContextWrapper)session.getAttribute("AndroMDAADFContext");
                adfContext = contextWrapper != null ? contextWrapper.getCurrentInstance() : null;
            }
            variable = adfContext != null ? adfContext.getProcessScope().get(name) : null;
        }
        // - finally try resolving it in the standard JSF manner
        if (variable == null)
        {
            final javax.faces.context.FacesContext context = this.getContext();
            variable = context != null ? context.getApplication().getVariableResolver().resolveVariable(context, name) : null;
        }
        return variable;
    }

    /**
     * Finds the root cause of the given <code>throwable</code> and
     * adds the message taken from that cause to the faces context messages.
     *
     * @param throwable the exception information to add.
     */
    private final void addExceptionMessage(
        Throwable throwable)
    {
        String message = null;
        final Throwable rootCause = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(throwable);
        if (rootCause != null)
        {
            message = rootCause.toString();
        }
        if (message == null || message.trim().length() == 0)
        {
            message = throwable.toString();
        }
        this.addErrorMessage(message);
    }

    /**
     * Adds the given error <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addErrorMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_ERROR, message);
    }

    /**
     * Adds the given warning <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addWarningMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_WARN, message);
    }

    /**
     * Adds the given info <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addInfoMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_INFO, message);
    }

    /**
     * Adds the given fatal <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addFatalMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_FATAL, message);
    }

    /**
     * Adds a message to the faces context (which will show up on your view when using the
     * lt;h:messages/gt; tag).
     *
     * @param severity the severity of the message
     * @param message the message to add.
     */
    protected void addMessage(final javax.faces.application.FacesMessage.Severity severity, final String message)
    {
        final javax.faces.application.FacesMessage facesMessage = new javax.faces.application.FacesMessage(severity, message, message);
        final oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        final Object form = adfContext.getProcessScope().get("form");
        if (form != null)
        {
            try
            {
                final java.lang.reflect.Method method = form.getClass().getMethod(
                    "addJsfMessages", 
                    new Class[]{javax.faces.application.FacesMessage.class});
                method.invoke(form, new Object[]{facesMessage});  
            }
            catch (final Exception exception)
            {
                throw new RuntimeException(exception);
            }
        }
    }
    
    /**
     * Copies all matching properties from the <code>fromForm</code> to the given
     * <code>toForm</code> overridding any previously set values.
     */
    protected void copyForm(final Object fromForm, final Object toForm)
    {
        org.andromda.presentation.jsf.FormPopulator.populateForm(fromForm, toForm, true);
    }
}