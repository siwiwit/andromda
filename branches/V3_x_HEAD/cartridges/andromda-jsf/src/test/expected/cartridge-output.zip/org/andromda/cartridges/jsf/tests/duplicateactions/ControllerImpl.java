// license-header java merge-point
package org.andromda.cartridges.jsf.tests.duplicateactions;

/**
 * @see org.andromda.cartridges.jsf.tests.duplicateactions.Controller
 */
public class ControllerImpl
    extends Controller
{

}