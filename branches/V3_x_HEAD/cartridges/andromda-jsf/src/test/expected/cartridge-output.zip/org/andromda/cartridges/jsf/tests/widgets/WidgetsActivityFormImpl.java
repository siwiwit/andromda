// license-header java merge-point
package org.andromda.cartridges.jsf.tests.widgets;

/**
 * 
 */
public class WidgetsActivityFormImpl
    implements java.io.Serializable    
{
    public WidgetsActivityFormImpl()
    {
    }

    private java.lang.String textFieldTest;

    /**
     * 
     */
    public java.lang.String getTextFieldTest()
    {
        return this.textFieldTest;
    }
    
    /**
     * Keeps track of whether or not the value of textFieldTest has
     * be populated at least once.
     */
    private boolean textFieldTestSet = false;
    
    /**
     * Indicates whether or not the value for textFieldTest has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isTextFieldTestSet()
    {
        return this.textFieldTestSet;
    }

    /**
     * 
     */
    public void setTextFieldTest(java.lang.String textFieldTest)
    {
        this.textFieldTest = textFieldTest;
        this.textFieldTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] textFieldTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] textFieldTestLabelList;
    public java.lang.Object[] getTextFieldTestBackingList()
    {
        java.lang.Object[] values = this.textFieldTestValueList;
        java.lang.Object[] labels = this.textFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTextFieldTestValueList()
    {
        return this.textFieldTestValueList;
    }

    public void setTextFieldTestValueList(java.lang.Object[] textFieldTestValueList)
    {
        this.textFieldTestValueList = textFieldTestValueList;
    }

    public java.lang.Object[] getTextFieldTestLabelList()
    {
        return this.textFieldTestLabelList;
    }

    public void setTextFieldTestLabelList(java.lang.Object[] textFieldTestLabelList)
    {
        this.textFieldTestLabelList = textFieldTestLabelList;
    }

    public void setTextFieldTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setTextFieldTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.textFieldTestValueList = null;
        this.textFieldTestLabelList = null;
        if (items != null)
        {
            this.textFieldTestValueList = new java.lang.Object[items.size()];
            this.textFieldTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.textFieldTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.textFieldTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String passwordFieldTest;

    /**
     * 
     */
    public java.lang.String getPasswordFieldTest()
    {
        return this.passwordFieldTest;
    }
    
    /**
     * Keeps track of whether or not the value of passwordFieldTest has
     * be populated at least once.
     */
    private boolean passwordFieldTestSet = false;
    
    /**
     * Indicates whether or not the value for passwordFieldTest has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isPasswordFieldTestSet()
    {
        return this.passwordFieldTestSet;
    }

    /**
     * 
     */
    public void setPasswordFieldTest(java.lang.String passwordFieldTest)
    {
        this.passwordFieldTest = passwordFieldTest;
        this.passwordFieldTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] passwordFieldTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] passwordFieldTestLabelList;
    public java.lang.Object[] getPasswordFieldTestBackingList()
    {
        java.lang.Object[] values = this.passwordFieldTestValueList;
        java.lang.Object[] labels = this.passwordFieldTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getPasswordFieldTestValueList()
    {
        return this.passwordFieldTestValueList;
    }

    public void setPasswordFieldTestValueList(java.lang.Object[] passwordFieldTestValueList)
    {
        this.passwordFieldTestValueList = passwordFieldTestValueList;
    }

    public java.lang.Object[] getPasswordFieldTestLabelList()
    {
        return this.passwordFieldTestLabelList;
    }

    public void setPasswordFieldTestLabelList(java.lang.Object[] passwordFieldTestLabelList)
    {
        this.passwordFieldTestLabelList = passwordFieldTestLabelList;
    }

    public void setPasswordFieldTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setPasswordFieldTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.passwordFieldTestValueList = null;
        this.passwordFieldTestLabelList = null;
        if (items != null)
        {
            this.passwordFieldTestValueList = new java.lang.Object[items.size()];
            this.passwordFieldTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.passwordFieldTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.passwordFieldTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String textAreaTest;

    /**
     * 
     */
    public java.lang.String getTextAreaTest()
    {
        return this.textAreaTest;
    }
    
    /**
     * Keeps track of whether or not the value of textAreaTest has
     * be populated at least once.
     */
    private boolean textAreaTestSet = false;
    
    /**
     * Indicates whether or not the value for textAreaTest has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isTextAreaTestSet()
    {
        return this.textAreaTestSet;
    }

    /**
     * 
     */
    public void setTextAreaTest(java.lang.String textAreaTest)
    {
        this.textAreaTest = textAreaTest;
        this.textAreaTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] textAreaTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] textAreaTestLabelList;
    public java.lang.Object[] getTextAreaTestBackingList()
    {
        java.lang.Object[] values = this.textAreaTestValueList;
        java.lang.Object[] labels = this.textAreaTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTextAreaTestValueList()
    {
        return this.textAreaTestValueList;
    }

    public void setTextAreaTestValueList(java.lang.Object[] textAreaTestValueList)
    {
        this.textAreaTestValueList = textAreaTestValueList;
    }

    public java.lang.Object[] getTextAreaTestLabelList()
    {
        return this.textAreaTestLabelList;
    }

    public void setTextAreaTestLabelList(java.lang.Object[] textAreaTestLabelList)
    {
        this.textAreaTestLabelList = textAreaTestLabelList;
    }

    public void setTextAreaTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setTextAreaTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.textAreaTestValueList = null;
        this.textAreaTestLabelList = null;
        if (items != null)
        {
            this.textAreaTestValueList = new java.lang.Object[items.size()];
            this.textAreaTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.textAreaTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.textAreaTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private boolean checkboxTest;

    /**
     * 
     */
    public boolean isCheckboxTest()
    {
        return this.checkboxTest;
    }
    
    /**
     * Keeps track of whether or not the value of checkboxTest has
     * be populated at least once.
     */
    private boolean checkboxTestSet = false;
    
    /**
     * Indicates whether or not the value for checkboxTest has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isCheckboxTestSet()
    {
        return this.checkboxTestSet;
    }

    /**
     * 
     */
    public void setCheckboxTest(boolean checkboxTest)
    {
        this.checkboxTest = checkboxTest;
        this.checkboxTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] checkboxTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] checkboxTestLabelList;
    public java.lang.Object[] getCheckboxTestBackingList()
    {
        java.lang.Object[] values = this.checkboxTestValueList;
        java.lang.Object[] labels = this.checkboxTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCheckboxTestValueList()
    {
        return this.checkboxTestValueList;
    }

    public void setCheckboxTestValueList(java.lang.Object[] checkboxTestValueList)
    {
        this.checkboxTestValueList = checkboxTestValueList;
    }

    public java.lang.Object[] getCheckboxTestLabelList()
    {
        return this.checkboxTestLabelList;
    }

    public void setCheckboxTestLabelList(java.lang.Object[] checkboxTestLabelList)
    {
        this.checkboxTestLabelList = checkboxTestLabelList;
    }

    public void setCheckboxTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setCheckboxTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.checkboxTestValueList = null;
        this.checkboxTestLabelList = null;
        if (items != null)
        {
            this.checkboxTestValueList = new java.lang.Object[items.size()];
            this.checkboxTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.checkboxTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.checkboxTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String radioButtonsTest;

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest()
    {
        return this.radioButtonsTest;
    }
    
    /**
     * Keeps track of whether or not the value of radioButtonsTest has
     * be populated at least once.
     */
    private boolean radioButtonsTestSet = false;
    
    /**
     * Indicates whether or not the value for radioButtonsTest has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isRadioButtonsTestSet()
    {
        return this.radioButtonsTestSet;
    }

    /**
     * 
     */
    public void setRadioButtonsTest(java.lang.String radioButtonsTest)
    {
        this.radioButtonsTest = radioButtonsTest;
        this.radioButtonsTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] radioButtonsTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] radioButtonsTestLabelList;
    public java.lang.Object[] getRadioButtonsTestBackingList()
    {
        java.lang.Object[] values = this.radioButtonsTestValueList;
        java.lang.Object[] labels = this.radioButtonsTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTestValueList()
    {
        return this.radioButtonsTestValueList;
    }

    public void setRadioButtonsTestValueList(java.lang.Object[] radioButtonsTestValueList)
    {
        this.radioButtonsTestValueList = radioButtonsTestValueList;
    }

    public java.lang.Object[] getRadioButtonsTestLabelList()
    {
        return this.radioButtonsTestLabelList;
    }

    public void setRadioButtonsTestLabelList(java.lang.Object[] radioButtonsTestLabelList)
    {
        this.radioButtonsTestLabelList = radioButtonsTestLabelList;
    }

    public void setRadioButtonsTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setRadioButtonsTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.radioButtonsTestValueList = null;
        this.radioButtonsTestLabelList = null;
        if (items != null)
        {
            this.radioButtonsTestValueList = new java.lang.Object[items.size()];
            this.radioButtonsTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.radioButtonsTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.radioButtonsTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String radioButtonsTest2;

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest2()
    {
        return this.radioButtonsTest2;
    }
    
    /**
     * Keeps track of whether or not the value of radioButtonsTest2 has
     * be populated at least once.
     */
    private boolean radioButtonsTest2Set = false;
    
    /**
     * Indicates whether or not the value for radioButtonsTest2 has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isRadioButtonsTest2Set()
    {
        return this.radioButtonsTest2Set;
    }

    /**
     * 
     */
    public void setRadioButtonsTest2(java.lang.String radioButtonsTest2)
    {
        this.radioButtonsTest2 = radioButtonsTest2;
        this.radioButtonsTest2Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] radioButtonsTest2ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] radioButtonsTest2LabelList;
    public java.lang.Object[] getRadioButtonsTest2BackingList()
    {
        java.lang.Object[] values = this.radioButtonsTest2ValueList;
        java.lang.Object[] labels = this.radioButtonsTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTest2ValueList()
    {
        return this.radioButtonsTest2ValueList;
    }

    public void setRadioButtonsTest2ValueList(java.lang.Object[] radioButtonsTest2ValueList)
    {
        this.radioButtonsTest2ValueList = radioButtonsTest2ValueList;
    }

    public java.lang.Object[] getRadioButtonsTest2LabelList()
    {
        return this.radioButtonsTest2LabelList;
    }

    public void setRadioButtonsTest2LabelList(java.lang.Object[] radioButtonsTest2LabelList)
    {
        this.radioButtonsTest2LabelList = radioButtonsTest2LabelList;
    }

    public void setRadioButtonsTest2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setRadioButtonsTest2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.radioButtonsTest2ValueList = null;
        this.radioButtonsTest2LabelList = null;
        if (items != null)
        {
            this.radioButtonsTest2ValueList = new java.lang.Object[items.size()];
            this.radioButtonsTest2LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.radioButtonsTest2ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.radioButtonsTest2LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String radioButtonsTest3;

    /**
     * 
     */
    public java.lang.String getRadioButtonsTest3()
    {
        return this.radioButtonsTest3;
    }
    
    /**
     * Keeps track of whether or not the value of radioButtonsTest3 has
     * be populated at least once.
     */
    private boolean radioButtonsTest3Set = false;
    
    /**
     * Indicates whether or not the value for radioButtonsTest3 has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isRadioButtonsTest3Set()
    {
        return this.radioButtonsTest3Set;
    }

    /**
     * 
     */
    public void setRadioButtonsTest3(java.lang.String radioButtonsTest3)
    {
        this.radioButtonsTest3 = radioButtonsTest3;
        this.radioButtonsTest3Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] radioButtonsTest3ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] radioButtonsTest3LabelList;
    public java.lang.Object[] getRadioButtonsTest3BackingList()
    {
        java.lang.Object[] values = this.radioButtonsTest3ValueList;
        java.lang.Object[] labels = this.radioButtonsTest3LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getRadioButtonsTest3ValueList()
    {
        return this.radioButtonsTest3ValueList;
    }

    public void setRadioButtonsTest3ValueList(java.lang.Object[] radioButtonsTest3ValueList)
    {
        this.radioButtonsTest3ValueList = radioButtonsTest3ValueList;
    }

    public java.lang.Object[] getRadioButtonsTest3LabelList()
    {
        return this.radioButtonsTest3LabelList;
    }

    public void setRadioButtonsTest3LabelList(java.lang.Object[] radioButtonsTest3LabelList)
    {
        this.radioButtonsTest3LabelList = radioButtonsTest3LabelList;
    }

    public void setRadioButtonsTest3BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setRadioButtonsTest3BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.radioButtonsTest3ValueList = null;
        this.radioButtonsTest3LabelList = null;
        if (items != null)
        {
            this.radioButtonsTest3ValueList = new java.lang.Object[items.size()];
            this.radioButtonsTest3LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.radioButtonsTest3ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.radioButtonsTest3LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String selectTest;

    /**
     * 
     */
    public java.lang.String getSelectTest()
    {
        return this.selectTest;
    }
    
    /**
     * Keeps track of whether or not the value of selectTest has
     * be populated at least once.
     */
    private boolean selectTestSet = false;
    
    /**
     * Indicates whether or not the value for selectTest has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isSelectTestSet()
    {
        return this.selectTestSet;
    }

    /**
     * 
     */
    public void setSelectTest(java.lang.String selectTest)
    {
        this.selectTest = selectTest;
        this.selectTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] selectTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] selectTestLabelList;
    public java.lang.Object[] getSelectTestBackingList()
    {
        java.lang.Object[] values = this.selectTestValueList;
        java.lang.Object[] labels = this.selectTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSelectTestValueList()
    {
        return this.selectTestValueList;
    }

    public void setSelectTestValueList(java.lang.Object[] selectTestValueList)
    {
        this.selectTestValueList = selectTestValueList;
    }

    public java.lang.Object[] getSelectTestLabelList()
    {
        return this.selectTestLabelList;
    }

    public void setSelectTestLabelList(java.lang.Object[] selectTestLabelList)
    {
        this.selectTestLabelList = selectTestLabelList;
    }

    public void setSelectTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setSelectTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.selectTestValueList = null;
        this.selectTestLabelList = null;
        if (items != null)
        {
            this.selectTestValueList = new java.lang.Object[items.size()];
            this.selectTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.selectTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.selectTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String hiddenTest;

    /**
     * 
     */
    public java.lang.String getHiddenTest()
    {
        return this.hiddenTest;
    }
    
    /**
     * Keeps track of whether or not the value of hiddenTest has
     * be populated at least once.
     */
    private boolean hiddenTestSet = false;
    
    /**
     * Indicates whether or not the value for hiddenTest has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isHiddenTestSet()
    {
        return this.hiddenTestSet;
    }

    /**
     * 
     */
    public void setHiddenTest(java.lang.String hiddenTest)
    {
        this.hiddenTest = hiddenTest;
        this.hiddenTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] hiddenTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] hiddenTestLabelList;
    public java.lang.Object[] getHiddenTestBackingList()
    {
        java.lang.Object[] values = this.hiddenTestValueList;
        java.lang.Object[] labels = this.hiddenTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getHiddenTestValueList()
    {
        return this.hiddenTestValueList;
    }

    public void setHiddenTestValueList(java.lang.Object[] hiddenTestValueList)
    {
        this.hiddenTestValueList = hiddenTestValueList;
    }

    public java.lang.Object[] getHiddenTestLabelList()
    {
        return this.hiddenTestLabelList;
    }

    public void setHiddenTestLabelList(java.lang.Object[] hiddenTestLabelList)
    {
        this.hiddenTestLabelList = hiddenTestLabelList;
    }

    public void setHiddenTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setHiddenTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.hiddenTestValueList = null;
        this.hiddenTestLabelList = null;
        if (items != null)
        {
            this.hiddenTestValueList = new java.lang.Object[items.size()];
            this.hiddenTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.hiddenTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.hiddenTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String textFieldTest2;

    /**
     * 
     */
    public java.lang.String getTextFieldTest2()
    {
        return this.textFieldTest2;
    }
    
    /**
     * Keeps track of whether or not the value of textFieldTest2 has
     * be populated at least once.
     */
    private boolean textFieldTest2Set = false;
    
    /**
     * Indicates whether or not the value for textFieldTest2 has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isTextFieldTest2Set()
    {
        return this.textFieldTest2Set;
    }

    /**
     * 
     */
    public void setTextFieldTest2(java.lang.String textFieldTest2)
    {
        this.textFieldTest2 = textFieldTest2;
        this.textFieldTest2Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] textFieldTest2ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] textFieldTest2LabelList;
    public java.lang.Object[] getTextFieldTest2BackingList()
    {
        java.lang.Object[] values = this.textFieldTest2ValueList;
        java.lang.Object[] labels = this.textFieldTest2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTextFieldTest2ValueList()
    {
        return this.textFieldTest2ValueList;
    }

    public void setTextFieldTest2ValueList(java.lang.Object[] textFieldTest2ValueList)
    {
        this.textFieldTest2ValueList = textFieldTest2ValueList;
    }

    public java.lang.Object[] getTextFieldTest2LabelList()
    {
        return this.textFieldTest2LabelList;
    }

    public void setTextFieldTest2LabelList(java.lang.Object[] textFieldTest2LabelList)
    {
        this.textFieldTest2LabelList = textFieldTest2LabelList;
    }

    public void setTextFieldTest2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("WidgetsActivityFormImpl.setTextFieldTest2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.textFieldTest2ValueList = null;
        this.textFieldTest2LabelList = null;
        if (items != null)
        {
            this.textFieldTest2ValueList = new java.lang.Object[items.size()];
            this.textFieldTest2LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.textFieldTest2ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.textFieldTest2LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = 2808623508931104989L;
}