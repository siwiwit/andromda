// license-header java merge-point
package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * 
 */
public abstract class Controller
    implements java.io.Serializable
{
    /**
     * 
     */
    public abstract void operation1();

    /**
     * 
     */
    public abstract void operation2(Operation2Form form);

    /**
     * 
     */
    public abstract void operation3();

    /**
     * <p>
     * This method has practically the same name as the use-case, a
     * user reported an error with such construction. This test exists
     * to make sure it does not appear.
     * </p>
     */
    public abstract void deferringOperations(DeferringOperationsForm form);

    /**
     * <p>
     * The action deferring to this operation has no form field with
     * the same name and type.
     * </p>
     */
    public abstract void testMissingArgumentField(TestMissingArgumentFieldForm form);

    /**
     * <p>
     * This operation exists to test that parameters must have a
     * non-empty name.
     * </p>
     */
    public abstract void missingArgumentName(MissingArgumentNameForm form);

    /**
     * 
     */
    public abstract boolean testPageToPage(TestPageToPageForm form);


    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2FormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>deferringOperationsState2Trigger2Form</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2FormImpl getState2Trigger2Form()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "deferringOperationsState2Trigger2Form");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2FormImpl)this.resolveVariable("deferringOperationsState2Trigger2Form");
    }
    
    public java.lang.String state2Trigger2()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2FormImpl form =
                this.getState2Trigger2Form();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
                contextWrapper.getCurrentInstance().getProcessScope().put("form", form);
                // - add this temporary ADF context to the session so that we can retrieve from a view populator if required
                this.getSession(false).setAttribute("AndroMDAADFContext", contextWrapper);
                forward = _state3(form);
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _state3(final org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2FormImpl form)
    {
        java.lang.String forward = null;
        operation2(form);
        operation3();
        forward = "deferring-operations-state4";
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2bFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>deferringOperationsState2Trigger2bForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2bFormImpl getState2Trigger2bForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "deferringOperationsState2Trigger2bForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2bFormImpl)this.resolveVariable("deferringOperationsState2Trigger2bForm");
    }
    
    public java.lang.String state2Trigger2b()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2bFormImpl form =
                this.getState2Trigger2bForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
                contextWrapper.getCurrentInstance().getProcessScope().put("form", form);
                // - add this temporary ADF context to the session so that we can retrieve from a view populator if required
                this.getSession(false).setAttribute("AndroMDAADFContext", contextWrapper);
                forward = _state1(form);
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _state1(final org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2bFormImpl form)
    {
        java.lang.String forward = null;
        operation1();
        operation2(form);
        forward = "deferring-operations-state2";
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>deferringOperationsState4Trigger4Form</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl getState4Trigger4Form()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "deferringOperationsState4Trigger4Form");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl)this.resolveVariable("deferringOperationsState4Trigger4Form");
    }
    
    public java.lang.String state4Trigger4()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl form =
                this.getState4Trigger4Form();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
                contextWrapper.getCurrentInstance().getProcessScope().put("form", form);
                // - add this temporary ADF context to the session so that we can retrieve from a view populator if required
                this.getSession(false).setAttribute("AndroMDAADFContext", contextWrapper);
                forward = _state5(form);
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _state5(final org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl form)
    {
        java.lang.String forward = null;
        deferringOperations(form);
        testMissingArgumentField(form);
        forward = _state1(form);
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _state1(final org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl form)
    {
        java.lang.String forward = null;
        operation1();
        operation2(form);
        forward = "deferring-operations-state2";
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>deferringOperationsState4NullForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl getState4NullForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "deferringOperationsState4NullForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl)this.resolveVariable("deferringOperationsState4NullForm");
    }
    
    public java.lang.String state4Null()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl form =
                this.getState4NullForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
                contextWrapper.getCurrentInstance().getProcessScope().put("form", form);
                // - add this temporary ADF context to the session so that we can retrieve from a view populator if required
                this.getSession(false).setAttribute("AndroMDAADFContext", contextWrapper);
                forward = __testPageToPage(form);
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String __testPageToPage(final org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl form)
    {
        final String value = java.lang.String.valueOf(testPageToPage(form));
        if (value.equals("false"))
        {
            return "deferring-operations-state6";
        }
        if (value.equals("true"))
        {
            return "deferring-operations-state6";
        }
        // we take the last action in case we have an invalid return value from the controller
        return "deferring-operations-state6";
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.deferringoperations.DeferringOperationsFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>deferringOperationsDeferringOperationsForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.deferringoperations.DeferringOperationsFormImpl getDeferringOperationsForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "deferringOperationsDeferringOperationsForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.deferringoperations.DeferringOperationsFormImpl)this.resolveVariable("deferringOperationsDeferringOperationsForm");
    }
    
    public java.lang.String deferringOperations()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.deferringoperations.DeferringOperationsFormImpl form =
                this.getDeferringOperationsForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
                contextWrapper.getCurrentInstance().getProcessScope().put("form", form);
                // - add this temporary ADF context to the session so that we can retrieve from a view populator if required
                this.getSession(false).setAttribute("AndroMDAADFContext", contextWrapper);
                forward = _state1(form);
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _state1(final org.andromda.cartridges.jsf.tests.deferringoperations.DeferringOperationsFormImpl form)
    {
        java.lang.String forward = null;
        operation1();
        operation2(form);
        forward = "deferring-operations-state2";
        return forward;
    }

    /**
     * Gets the current faces context.  This object is the point
     * from which to retrieve any request, session, etc information.
     *
     * @return the JSF faces context instance.
     */
    protected javax.faces.context.FacesContext getContext()
    {
        return javax.faces.context.FacesContext.getCurrentInstance();
    }

    /**
     * A helper method that gets the current request from the faces
     * context.
     *
     * @return the current HttpServletRequest instance.
     */
    protected javax.servlet.http.HttpServletRequest getRequest()
    {
        return (javax.servlet.http.HttpServletRequest)this.getContext().getExternalContext().getRequest();
    }

    /**
     * A helper method that gets the current reponse from the faces
     * context.
     *
     * @return the current HttpServletReponse instance.
     */
    protected javax.servlet.http.HttpServletResponse getResponse()
    {
        return (javax.servlet.http.HttpServletResponse)this.getContext().getExternalContext().getResponse();
    }

    /**
     * A helper method that gets the current session from the faces
     * context.
     *
     * @param create If the create parameter is true, create (if necessary) and return a
     *        session instance associated with the current request. If the create
     *        parameter is false return any existing session instance associated with the
     *        current request, or return null if there is no such session.
     * @return the current HttpSession instance.
     */
    protected javax.servlet.http.HttpSession getSession(final boolean create)
    {
        return (javax.servlet.http.HttpSession)this.getContext().getExternalContext().getSession(create);
    }
    
    /**
     * Attempts to resolve the variable, given, the <code>name</code> of
     * the variable using the faces context variable resolver instance.
     * 
     * @return the resolved variable or null if not found.
     */
    protected java.lang.Object resolveVariable(final String name)
    {
        oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        Object variable = adfContext.getProcessScope().get(name);
        // - if we couldn't get the variable from the regular ADF context, see if
        //   the session contains an ADF context with the variable
        if (variable == null)
        {
            final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = 
                (org.andromda.presentation.jsf.AdfFacesContextWrapper)this.getSession(false).getAttribute("AndroMDAADFContext");
            adfContext = contextWrapper != null ? contextWrapper.getCurrentInstance() : null;
            variable = adfContext != null ? adfContext.getProcessScope().get(name) : null;
        }
        // - finally try resolving it in the standard JSF manner
        if (variable == null)
        {
            final javax.faces.context.FacesContext context = this.getContext();
            variable = context != null ? context.getApplication().getVariableResolver().resolveVariable(context, name) : null;
        }
        return variable;
    }

    /**
     * Finds the root cause of the given <code>throwable</code> and
     * adds the message taken from that cause to the faces context messages.
     *
     * @param throwable the exception information to add.
     */
    private final void addExceptionMessage(
        Throwable throwable)
    {
        String message = null;
        final Throwable rootCause = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(throwable);
        if (rootCause != null)
        {
            message = rootCause.toString();
        }
        if (message == null || message.trim().length() == 0)
        {
            message = throwable.toString();
        }
        this.addErrorMessage(message);
    }

    /**
     * Adds the given error <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addErrorMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_ERROR, message);
    }

    /**
     * Adds the given warning <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addWarningMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_WARN, message);
    }

    /**
     * Adds the given info <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addInfoMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_INFO, message);
    }

    /**
     * Adds the given fatal <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addFatalMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_FATAL, message);
    }

    /**
     * Adds a message to the faces context (which will show up on your view when using the
     * lt;h:messages/gt; tag).
     *
     * @param severity the severity of the message
     * @param message the message to add.
     */
    protected void addMessage(final javax.faces.application.FacesMessage.Severity severity, final String message)
    {
        final javax.faces.application.FacesMessage facesMessage = new javax.faces.application.FacesMessage(severity, message, message);
        final oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        final Object form = adfContext.getProcessScope().get("form");
        if (form != null)
        {
            try
            {
                final java.lang.reflect.Method method = form.getClass().getMethod(
                    "addJsfMessages", 
                    new Class[]{javax.faces.application.FacesMessage.class});
                method.invoke(form, new Object[]{facesMessage});  
            }
            catch (final Exception exception)
            {
                throw new RuntimeException(exception);
            }
        }
    }
    
    /**
     * Copies all matching properties from the <code>fromForm</code> to the given
     * <code>toForm</code> overridding any previously set values.
     */
    protected void copyForm(final Object fromForm, final Object toForm)
    {
        org.andromda.presentation.jsf.FormPopulator.populateForm(fromForm, toForm, true);
    }

    /**
     * Populates the form from the given parameters.  If the request parameter is null or an empty
     * string, then null is placed on the form.
     *
     * @param form the form to populate.
     * @param formatters any date or time formatters.
     */
    private final void populateFormFromRequestParameters(final Object form, final java.util.Map formatters)
    {
        try
        {
            final java.util.Map parameters = this.getContext().getExternalContext().getRequestParameterMap();
            for (final java.util.Iterator iterator = parameters.keySet().iterator(); iterator.hasNext();)
            {
                final String name = (String)iterator.next();
                if (org.apache.commons.beanutils.PropertyUtils.isWriteable(form, name))
                {
                    final java.beans.PropertyDescriptor descriptor =
                        org.apache.commons.beanutils.PropertyUtils.getPropertyDescriptor(form, name);
                    if (descriptor != null)
                    {
                        final String parameter = (String)parameters.get(name);
                        Object value = null;
                        // - only convert if the string is not empty
                        if (parameter != null && parameter.trim().length() > 0)
                        {
                            java.text.DateFormat formatter = (java.text.DateFormat)formatters.get(name);
                            // - if the formatter is available we use that, otherwise we attempt to convert
                            if (formatter != null)
                            {
                                try
                                {
                                    value = formatter.parse(parameter);
                                }
                                catch (java.text.ParseException parseException)
                                {
                                    // - try the default formatter (handles the default java.util.Date.toString() format)
                                    formatter = (java.text.DateFormat)formatters.get(null);
                                    value = formatter.parse(parameter); 
                                }
                            }
                            else
                            {
                                value = org.apache.commons.beanutils.ConvertUtils.convert(parameter, descriptor.getPropertyType());
                            }
                            org.apache.commons.beanutils.PropertyUtils.setProperty(form, name, value);
                        }
                    }
                }
            }
        }
        catch (final Throwable throwable)
        {
            throw new RuntimeException(throwable);
        }
    }
    
    /**
     * Finds the form (if one is present) on the given <code>component</code> having the given
     * <code>id</code>.
     * 
     * @param component the component to search.
     * @param id the id of the form.
     * @return the form or null if none was found.
     */
    private javax.faces.component.UIForm findForm(javax.faces.component.UIComponent component, String id)
    {
        javax.faces.component.UIForm foundForm = null;
        if (component != null)
        {
            for (final java.util.Iterator iterator = component.getFacetsAndChildren(); iterator.hasNext();)
            {
                final Object object = (javax.faces.component.UIComponent)iterator.next();
                if (object instanceof javax.faces.component.UIComponent)
                {
                    final javax.faces.component.UIComponent uiComponent = (javax.faces.component.UIComponent)object;
                    if (uiComponent instanceof javax.faces.component.UIForm)
                    {
                        final javax.faces.component.UIForm form = (javax.faces.component.UIForm)uiComponent;
                        if (form.getId().equals(id))
                        {
                            foundForm = form;
                            break;
                        }
                    }
                    foundForm = this.findForm(uiComponent, id);
                    if (foundForm != null)
                    {
                        break;
                    }
                }
            }
        }
        return foundForm;
    }
    
    /**
     * If the given <code>component</code> has an child input elements, this method findds
     * them all and populates them.  This is to get around the fact that when immediate is set to true
     * on a button that submits the form that the form isn't populated.
     * 
     * @param component the component to populate.
     */
    private void populateComponentInputs(javax.faces.component.UIComponent component)
    {
        if (component != null)
        {
            for (final java.util.Iterator iterator = component.getFacetsAndChildren(); iterator.hasNext();)
            {
                final javax.faces.component.UIComponent uiComponent = (javax.faces.component.UIComponent)iterator.next();
                if (uiComponent instanceof javax.faces.component.UIInput)
                {
                    try
                    {
                        final javax.faces.component.UIInput input = (javax.faces.component.UIInput)uiComponent;
                        input.validate(this.getContext());
                        input.updateModel(this.getContext());
                    }
                    catch (javax.faces.validator.ValidatorException exception)
                    {
                        // - ignore, no value is set (validate will be called by the regular
                        //   JSF lifecycle processing anyway, this is just called to populate the
                        //   local value
                    }
                }
                else
                {
                    this.populateComponentInputs(uiComponent);
                }
            }
        }
    }
}