package org.andromda.cartridges.jsf.tests.widgets;

/**
 * Stores all forward paths available in the use case Widgets Activity keyed by forward name.
 */
final class WidgetsActivityForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("widgets-activity-usecase", "/org/andromda/cartridges/jsf/tests/widgets/widgets-activity.jsf");
            forwards.put("show-widgets", "/org/andromda/cartridges/jsf/tests/widgets/show-widgets.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}