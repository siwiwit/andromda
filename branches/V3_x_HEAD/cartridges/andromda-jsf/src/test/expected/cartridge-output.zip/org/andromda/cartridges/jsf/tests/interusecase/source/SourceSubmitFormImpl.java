// license-header java merge-point
package org.andromda.cartridges.jsf.tests.interusecase.source;

/**
 * 
 */
public class SourceSubmitFormImpl
    implements java.io.Serializable    
{
    public SourceSubmitFormImpl()
    {
    }

    private int sourceParam1;

    /**
     * 
     */
    public int getSourceParam1()
    {
        return this.sourceParam1;
    }
    
    /**
     * Keeps track of whether or not the value of sourceParam1 has
     * be populated at least once.
     */
    private boolean sourceParam1Set = false;
    
    /**
     * Indicates whether or not the value for sourceParam1 has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isSourceParam1Set()
    {
        return this.sourceParam1Set;
    }

    /**
     * 
     */
    public void setSourceParam1(int sourceParam1)
    {
        this.sourceParam1 = sourceParam1;
        this.sourceParam1Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] sourceParam1ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] sourceParam1LabelList;
    public java.lang.Object[] getSourceParam1BackingList()
    {
        java.lang.Object[] values = this.sourceParam1ValueList;
        java.lang.Object[] labels = this.sourceParam1LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSourceParam1ValueList()
    {
        return this.sourceParam1ValueList;
    }

    public void setSourceParam1ValueList(java.lang.Object[] sourceParam1ValueList)
    {
        this.sourceParam1ValueList = sourceParam1ValueList;
    }

    public java.lang.Object[] getSourceParam1LabelList()
    {
        return this.sourceParam1LabelList;
    }

    public void setSourceParam1LabelList(java.lang.Object[] sourceParam1LabelList)
    {
        this.sourceParam1LabelList = sourceParam1LabelList;
    }

    public void setSourceParam1BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("SourceSubmitFormImpl.setSourceParam1BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.sourceParam1ValueList = null;
        this.sourceParam1LabelList = null;
        if (items != null)
        {
            this.sourceParam1ValueList = new java.lang.Object[items.size()];
            this.sourceParam1LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.sourceParam1ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.sourceParam1LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String sourceParam2;

    /**
     * 
     */
    public java.lang.String getSourceParam2()
    {
        return this.sourceParam2;
    }
    
    /**
     * Keeps track of whether or not the value of sourceParam2 has
     * be populated at least once.
     */
    private boolean sourceParam2Set = false;
    
    /**
     * Indicates whether or not the value for sourceParam2 has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isSourceParam2Set()
    {
        return this.sourceParam2Set;
    }

    /**
     * 
     */
    public void setSourceParam2(java.lang.String sourceParam2)
    {
        this.sourceParam2 = sourceParam2;
        this.sourceParam2Set = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] sourceParam2ValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] sourceParam2LabelList;
    public java.lang.Object[] getSourceParam2BackingList()
    {
        java.lang.Object[] values = this.sourceParam2ValueList;
        java.lang.Object[] labels = this.sourceParam2LabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSourceParam2ValueList()
    {
        return this.sourceParam2ValueList;
    }

    public void setSourceParam2ValueList(java.lang.Object[] sourceParam2ValueList)
    {
        this.sourceParam2ValueList = sourceParam2ValueList;
    }

    public java.lang.Object[] getSourceParam2LabelList()
    {
        return this.sourceParam2LabelList;
    }

    public void setSourceParam2LabelList(java.lang.Object[] sourceParam2LabelList)
    {
        this.sourceParam2LabelList = sourceParam2LabelList;
    }

    public void setSourceParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("SourceSubmitFormImpl.setSourceParam2BackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.sourceParam2ValueList = null;
        this.sourceParam2LabelList = null;
        if (items != null)
        {
            this.sourceParam2ValueList = new java.lang.Object[items.size()];
            this.sourceParam2LabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.sourceParam2ValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.sourceParam2LabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = 3454885452582950650L;
}