package org.andromda.cartridges.jsf.tests.formfields;

import java.io.IOException;

import javax.faces.context.FacesContext;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * This filter handles the population of forms for the <em>one</code>
 * view.
 */
public class OnePopulator
    implements Filter
{
    /**
     * @see javax.servlet.Filter#setFilterConfig(FilterConfig)
     */
    public void init(FilterConfig config)
    {
    }

    /**
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(
        ServletRequest request,
        ServletResponse response,
        FilterChain chain) throws IOException, ServletException
    {
        this.populateFormAndViewVariables(request, response, null);
        chain.doFilter(request, response);
    }
    
    private void populateFormAndViewVariables(final ServletRequest request, final ServletResponse response, Object form)
        throws ServletException
    {
        // - we need to retrieve the faces context different than normal because we're outside of the
        //   faces servlet
        final FacesContext facesContext = org.andromda.presentation.jsf.FacesContextUtils.getFacesContext(request, response);
                
        oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        final javax.faces.el.VariableResolver variableResolver = facesContext.getApplication().getVariableResolver();
        final javax.servlet.http.HttpSession session = ((javax.servlet.http.HttpServletRequest)request).getSession();
        if (form == null)
        {  
            // - first try getting the form from the ADF processScope
            form = adfContext.getProcessScope().get("form");
            // - if the form is null, try getting the current adfContext from the session (and then remove it from the session)
            if (form == null)
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = 
                    (org.andromda.presentation.jsf.AdfFacesContextWrapper)session.getAttribute("AndroMDAADFContext");
                adfContext = contextWrapper != null ? contextWrapper.getCurrentInstance() : null;    
                form = adfContext != null ? adfContext.getProcessScope().get("form") : null;   
                // - if the form is still null, see if we can get it from a serialized state
                if (form == null)
                {
                    form = org.andromda.presentation.jsf.JsfUtils.getSerializedForm(session);
                }
                if (form != null)
                {
                    // - add the form to the current process scope since it wasn't in the current one to begin with
                    oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance().getProcessScope().put("form", form);   
                }
            }
            else
            {
                // - remove the ADF context in the event that its present
                session.removeAttribute("AndroMDAADFContext");
            }
        }
        else
        {
            // - since the form argument is not null, set it as the "form" in the processScope 
            //   (to replace the existing "form" attribute)
            adfContext.getProcessScope().put("form", form);
        }
        try
        {
            // - populate the forms
            if (form != null)
            {    
                org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl formFieldsOneSubmitForm =
                    (org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "formFieldsOneSubmitForm");
                // - populate the formFieldsOneSubmitForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, formFieldsOneSubmitForm);
                request.setAttribute("formFieldsOneSubmitForm", formFieldsOneSubmitForm);
            }
            // - serialize the form
            if (form != null)
            {
                org.andromda.presentation.jsf.JsfUtils.serializeForm(session, form);
            }
            // - populate the view variables
            populateViewVariablesFromForm(request, form);
        }
        catch (final Throwable throwable)
        {
            throw new ServletException(throwable);
        }
    }
    
    /**
     * Populates all view variables represented by this populator from the given <code>form</code>.
     * This operation can be used from within controller operations in order to populate view variables (if its
     * required to populate them outside of the normal filter execution).
     *
     * @param request the current request (to which view variables are populated)
     * @param form the form from which to retrieve the view variables.
     */
    static void populateViewVariablesFromForm(final ServletRequest request, final Object form)
        throws Exception
    {
        if (form != null)
        {    
            final boolean selectableBackingListReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "selectableBackingList");
            if (selectableBackingListReadable)
            {
                request.setAttribute("selectableBackingList", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "selectableBackingList"));
            }
            final boolean multiSelectBackingListReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "multiSelectBackingList");
            if (multiSelectBackingListReadable)
            {
                request.setAttribute("multiSelectBackingList", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "multiSelectBackingList"));
            }
        }
    }
    
    /**
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy()
    {
    }
}