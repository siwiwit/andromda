package org.andromda.cartridges.jsf.tests.constraints.actions.triggerpresent;

/**
 * Stores all forward paths available in the use case TriggerPresent UseCase keyed by forward name.
 */
final class TriggerPresentUseCaseForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("some-page", "/org/andromda/cartridges/jsf/tests/constraints/actions/triggerpresent/some-page.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}