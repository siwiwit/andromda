// license-header java merge-point
package org.andromda.cartridges.jsf.tests.messages;

/**
 * @see org.andromda.cartridges.jsf.tests.messages.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.messages.Controller#doSomething()
     */
    public boolean doSomething() throws java.lang.Exception
    {
        return false;
    }
    
}