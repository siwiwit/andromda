// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard;

/**
 * 
 */
public abstract class Controller
    implements java.io.Serializable
{
    /**
     * 
     */
    public abstract java.lang.String operation();


    public java.lang.String decisionsMissingGuard()
    {
        String forward = null;
        try
        {
            try
            {
                forward = (org.andromda.cartridges.jsf.metafacades.JSFActionLogicImpl[something])
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _something()
    {
        java.lang.String forward = null;
        forward = (org.andromda.cartridges.jsf.metafacades.JSFForwardLogicImpl[unknown])
        return forward;
    }

    /**
     * 
     */
    private java.lang.String __operation()
    {
        final String value = java.lang.String.valueOf(operation());
        if (value.equals("someGuard"))
        {
            return (org.andromda.cartridges.jsf.metafacades.JSFForwardLogicImpl[something])
        }
        if (value.equals("$outcome.guard.name"))
        {
            return (org.andromda.cartridges.jsf.metafacades.JSFForwardLogicImpl[something])
        }
        // we take the last action in case we have an invalid return value from the controller
        return (org.andromda.cartridges.jsf.metafacades.JSFForwardLogicImpl[something])
    }

    /**
     * Gets the current faces context.  This object is the point
     * from which to retrieve any request, session, etc information.
     *
     * @return the JSF faces context instance.
     */
    protected javax.faces.context.FacesContext getContext()
    {
        return javax.faces.context.FacesContext.getCurrentInstance();
    }

    /**
     * A helper method that gets the current request from the faces
     * context.
     *
     * @return the current HttpServletRequest instance.
     */
    protected javax.servlet.http.HttpServletRequest getRequest()
    {
        return (javax.servlet.http.HttpServletRequest)this.getContext().getExternalContext().getRequest();
    }

    /**
     * A helper method that gets the current reponse from the faces
     * context.
     *
     * @return the current HttpServletReponse instance.
     */
    protected javax.servlet.http.HttpServletResponse getResponse()
    {
        return (javax.servlet.http.HttpServletResponse)this.getContext().getExternalContext().getResponse();
    }

    /**
     * A helper method that gets the current session from the faces
     * context.
     *
     * @param create If the create parameter is true, create (if necessary) and return a
     *        session instance associated with the current request. If the create
     *        parameter is false return any existing session instance associated with the
     *        current request, or return null if there is no such session.
     * @return the current HttpSession instance.
     */
    protected javax.servlet.http.HttpSession getSession(final boolean create)
    {
        return (javax.servlet.http.HttpSession)this.getContext().getExternalContext().getSession(create);
    }
    
    /**
     * Attempts to resolve the variable, given, the <code>name</code> of
     * the variable using the faces context variable resolver instance.
     * 
     * @return the resolved variable or null if not found.
     */
    protected java.lang.Object resolveVariable(final String name)
    {
        final javax.faces.context.FacesContext context = this.getContext();
        return context != null ? context.getApplication().getVariableResolver().resolveVariable(context, name) : null;    
    }

    /**
     * Finds the root cause of the given <code>throwable</code> and
     * adds the message taken from that cause to the faces context messages.
     *
     * @param throwable the exception information to add.
     */
    private final void addExceptionMessage(
        Throwable throwable)
    {
        String message = null;
        final Throwable rootCause = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(throwable);
        if (rootCause != null)
        {
            message = rootCause.toString();
        }
        if (message == null || message.trim().length() == 0)
        {
            message = throwable.toString();
        }
        this.addErrorMessage(message);
    }

    /**
     * Adds the given error <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addErrorMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_ERROR, message);
    }

    /**
     * Adds the given warning <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addWarningMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_WARN, message);
    }

    /**
     * Adds the given info <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addInfoMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_INFO, message);
    }

    /**
     * Adds the given fatal <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addFatalMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_FATAL, message);
    }

    /**
     * Adds a message to the faces context (which will show up on your view when using the
     * lt;h:messages/gt; tag).
     *
     * @param severity the severity of the message
     * @param message the message to add.
     */
    protected void addMessage(final javax.faces.application.FacesMessage.Severity severity, final String message)
    {
        final javax.faces.application.FacesMessage facesMessage = new javax.faces.application.FacesMessage(severity, message, message);
        javax.faces.context.FacesContext.getCurrentInstance().addMessage(
            null,
            facesMessage);
    }
    
    /**
     * Copies all matching properties from the <code>fromForm</code> to the given
     * <code>toForm</code> overridding any previously set values.
     */
    protected void copyForm(final Object fromForm, final Object toForm)
    {
        org.andromda.presentation.jsf.FormPopulator.populateForm(fromForm, toForm, true);
    }
}
