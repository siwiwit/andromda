package org.andromda.presentation.jsf;

import org.apache.commons.lang.StringUtils;

/**
 * Stores constants used by the JSF cartridge.
 *
 * @author Chad Brandon
 */
public class Constants
{
    /**
     * The location of the temporary directoy used the JSF cartridge.
     */
    public static final String TEMPORARY_DIRECTORY;

    /**
     * Perform any constant initialization.
     */
    static
    {
        // - initialize the TEMPORARY_DIRECTORY
        final String tmpDir = System.getProperty("java.io.tmpdir");
        final StringBuffer directory = new StringBuffer(tmpDir);
        if (!directory.toString().endsWith("/"))
        {
            directory.append("/");
        }
        final String userName = System.getProperty("user.name");
        if (StringUtils.isNotBlank(userName))
        {
            directory.append(userName).append("/");
        }
        directory.append(".andromda/jsf-cartridge/");
        TEMPORARY_DIRECTORY = directory.toString();
    }
}