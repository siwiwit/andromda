package org.andromda.presentation.jsf;


import javax.faces.FactoryFinder;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Contains utilities for dealing with the FacesContext.
 * 
 * @author Chad Brandon
 */
public class FacesContextUtils
{
    /**
     * Retrieves the current faces context given the <code>servletContext</code>, <code>request</code>,
     * and <code>response</code>.
     * 
     * @param servletContext the servlet context.
     * @param request the ServletRequest instance.
     * @param response the ServletResponse instance
     * @return the current faces context.
     */
    public static FacesContext getFacesContext(
        final ServletContext servletContext,
        final ServletRequest request,
        final ServletResponse response)
    {
        if (servletContext == null)
        {
            throw new IllegalArgumentException("'servletContext' can not be null");
        }
        if (request == null)
        {
            throw new IllegalArgumentException("'request' can not be null");
        }
        if (response == null)
        {
            throw new IllegalArgumentException("'response' can not be null");
        }
        final LifecycleFactory lifecycleFactory =
            (LifecycleFactory)FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY);
        final Lifecycle lifecycle = lifecycleFactory.getLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE);
        final FacesContextFactory facesContextFactory =
            (FacesContextFactory)FactoryFinder.getFactory(FactoryFinder.FACES_CONTEXT_FACTORY);
        final FacesContext facesContext = facesContextFactory.getFacesContext(
                servletContext,
                request,
                response,
                lifecycle);
        if (facesContext == null)
        {
            throw new RuntimeException("Could not retrieve the current faces context");
        }
        return facesContext;
    }
    
    /**
     * Attempts to resolve the variable having the given <code>name</code> from the given 
     * <code>servletContext</code>, <code>request</code>, and <code>response</code>
     * @param servletContext the servlet context.
     * @param request the ServletRequest instance.
     * @param response the ServletResponse instance
     * @param name the name of the variable to resolve.
     * @return
     */
    public static Object resolveVariable(
        final ServletContext servletContext,
        final ServletRequest request,
        final ServletResponse response,
        final String name)
    {
        final FacesContext facesContext = getFacesContext(servletContext,request,response);
        final javax.faces.el.VariableResolver variableResolver = facesContext.getApplication().getVariableResolver();
        return variableResolver.resolveVariable(
                facesContext,
                name);
    }
}
