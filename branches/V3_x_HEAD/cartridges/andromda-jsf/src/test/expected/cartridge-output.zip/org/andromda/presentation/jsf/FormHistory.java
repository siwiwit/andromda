package org.andromda.presentation.jsf;

/**
 * This class keeps track of the history of the flow of the application
 * as the user navigates through, the maximum size of the history can be
 * configured throught the maximumSize property (which is set through the 
 * <em>maximumFormsInHistory</em> namespace property.
 * 
 * @author Chad Brandon
 */
public class FormHistory
    implements java.io.Serializable
{
    /**
     * The max forms kept in history.
     */
    private static final int maximumSize = 5;
    
    /**
     * Keeps the previous forms that have been used in a history.
     */
    private java.util.Stack formHistory = new java.util.Stack();
    
    /**
     * Adds a form to the history.
     *
     * @param form the form to add.
     */
    public void addFormToHistory(final Object form)
    {
        if (form != null)
        {
            if (!this.formHistory.isEmpty())
            {
                // - check to see if the last form is of the same type, if so,
                //   replace the last form with this new form
                final int lastIndex = this.formHistory.size() - 1;
                final Object lastForm = this.formHistory.get(lastIndex);
                if (lastForm != null && lastForm.getClass() == form.getClass())
                {
                    this.formHistory.remove(lastIndex);
                }
                else if (this.formHistory.size() > maximumSize)
                {
                    // otherwise we remove the first form added in the list
                    this.formHistory.remove(0);
                }
            }
            this.formHistory.add(form);
        }
    }

    /**
     * Retrieves the last form from the history and removes it.
     *
     * @return the last form.
     */
    public Object getLastFormInHistory()
    {
        Object lastForm = null;
        if (!this.formHistory.isEmpty())
        {
            final int lastIndex = this.formHistory.size() - 1;
            lastForm = this.formHistory.get(lastIndex);
            this.formHistory.remove(lastIndex);
        }
        return lastForm;
    }
    
    private static final java.util.Map triggersAndFormBeanNamesByUseCase = new java.util.HashMap();
    
    /**
     * Attemps to retrieve the trigger method name with the No Table Link Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getNoTableLinkActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("No Table Link Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.tables.notablelink.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.tables.notablelink.ShowTableDataAgainFormImpl", controllerClass.getMethod("showTableDataAgain", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.notablelink.NoTableLinkActivityFormImpl", controllerClass.getMethod("noTableLinkActivity", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("No Table Link Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Table Link Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getTableLinkActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Table Link Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.tables.tablelink.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAgainFormImpl", controllerClass.getMethod("showTableDataAgain", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionFormImpl", controllerClass.getMethod("showTableDataHyperlinkAction", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataBadActionFormImpl", controllerClass.getMethod("showTableDataBadAction", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl", controllerClass.getMethod("showTableDataHyperlinkActionDuplicatingParameter", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkNotSpecifyingColumnFormImpl", controllerClass.getMethod("showTableDataHyperlinkNotSpecifyingColumn", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl", controllerClass.getMethod("showTableDataActionWithBadTableLink", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataRealisticFormActionFormImpl", controllerClass.getMethod("showTableDataRealisticFormAction", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataImageLinkActionFormImpl", controllerClass.getMethod("showTableDataImageLinkAction", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataGlobalTableActionFormImpl", controllerClass.getMethod("showTableDataGlobalTableAction", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataDuplicateGlobalTableActionFormImpl", controllerClass.getMethod("showTableDataDuplicateGlobalTableAction", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAnotherDuplicateGlobalTableActionFormImpl", controllerClass.getMethod("showTableDataAnotherDuplicateGlobalTableAction", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.tables.tablelink.TableLinkActivityFormImpl", controllerClass.getMethod("tableLinkActivity", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("Table Link Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the JspsCannotDeferCanStop 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getJspsCannotDeferCanStopTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("JspsCannotDeferCanStop");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.jsps.cannotdefercanstop.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.jsps.cannotdefercanstop.JspsCannotDeferCanStopFormImpl", controllerClass.getMethod("jspsCannotDeferCanStop", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("JspsCannotDeferCanStop", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the duplicate operation names 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDuplicateOperationNamesTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("duplicate operation names");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.controllers.duplicateoperationnames.DuplicateOperationNamesFormImpl", controllerClass.getMethod("duplicateOperationNames", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("duplicate operation names", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the OperationNameAsUseCase 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getOperationNameAsUseCaseTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("OperationNameAsUseCase");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.controllers.operationnameasusecase.OperationNameAsUseCaseFormImpl", controllerClass.getMethod("operationNameAsUseCase", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("OperationNameAsUseCase", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DecisionsReturnTypeVoid 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDecisionsReturnTypeVoidTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DecisionsReturnTypeVoid");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.decisions.returntypevoid.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.decisions.returntypevoid.DecisionsReturnTypeVoidFormImpl", controllerClass.getMethod("decisionsReturnTypeVoid", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("DecisionsReturnTypeVoid", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DecisionsMissingGuard 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDecisionsMissingGuardTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DecisionsMissingGuard");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard.DecisionsMissingGuardFormImpl", controllerClass.getMethod("decisionsMissingGuard", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("DecisionsMissingGuard", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DecisionsBadTarget 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDecisionsBadTargetTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DecisionsBadTarget");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.constraints.decisions.badtarget.DecisionsBadTargetFormImpl", controllerClass.getMethod("decisionsBadTarget", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("DecisionsBadTarget", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the SessionObject Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getSessionObjectActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("SessionObject Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.sessionobjects.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.sessionobjects.SessionObjectActivityFormImpl", controllerClass.getMethod("sessionObjectActivity", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("SessionObject Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Widgets Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getWidgetsActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Widgets Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.widgets.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.widgets.ShowWidgetsSubmitFormImpl", controllerClass.getMethod("showWidgetsSubmit", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.widgets.WidgetsActivityFormImpl", controllerClass.getMethod("widgetsActivity", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("Widgets Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the DeferringOperations 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getDeferringOperationsTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("DeferringOperations");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.deferringoperations.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2FormImpl", controllerClass.getMethod("state2Trigger2", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.State2Trigger2bFormImpl", controllerClass.getMethod("state2Trigger2b", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl", controllerClass.getMethod("state4Trigger4", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl", controllerClass.getMethod("state4Null", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.deferringoperations.DeferringOperationsFormImpl", controllerClass.getMethod("deferringOperations", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("DeferringOperations", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Messages Activity 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getMessagesActivityTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Messages Activity");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.messages.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.messages.ThreeSubmitFormImpl", controllerClass.getMethod("threeSubmit", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.messages.MessagesActivityFormImpl", controllerClass.getMethod("messagesActivity", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("Messages Activity", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the FormFields 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getFormFieldsTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("FormFields");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.formfields.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl", controllerClass.getMethod("oneSubmit", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.formfields.ThreeGoFormImpl", controllerClass.getMethod("threeGo", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.formfields.FormFieldsFormImpl", controllerClass.getMethod("formFields", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("FormFields", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Services 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getServicesTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Services");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.services.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.services.ServicesFormImpl", controllerClass.getMethod("services", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("Services", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    /**
     * Attemps to retrieve the trigger method name with the Reset 
     * for the given <code>form</code>.
     */ 
    public static java.lang.reflect.Method getResetTriggerMethod(final Object form)
    {
        final String formName = form != null ? form.getClass().getName() : "";
        java.util.Map map = (java.util.Map)triggersAndFormBeanNamesByUseCase.get("Reset");
        if (map == null)
        {
            final Class controllerClass = org.andromda.cartridges.jsf.tests.reset.Controller.class;
            try
            {
                map.put("org.andromda.cartridges.jsf.tests.reset.ResetPageSendWithResetFormImpl", controllerClass.getMethod("resetPageSendWithReset", (Class[])null));
                map.put("org.andromda.cartridges.jsf.tests.reset.ResetFormImpl", controllerClass.getMethod("reset", (Class[])null));
                triggersAndFormBeanNamesByUseCase.put("Reset", map);
            }
            catch (NoSuchMethodException exception)
            {
                throw new RuntimeException(exception);
            }
        }
        return (java.lang.reflect.Method)map.get(formName);
    }
    
    
}
