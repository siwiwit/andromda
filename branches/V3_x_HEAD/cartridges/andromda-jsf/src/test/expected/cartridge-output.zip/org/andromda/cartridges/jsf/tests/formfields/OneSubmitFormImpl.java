// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

/**
 * 
 */
public class OneSubmitFormImpl
    implements java.io.Serializable, SomeOperationForm
{
    public OneSubmitFormImpl()
    {
        java.text.DateFormat dateDateFormatter = new java.text.SimpleDateFormat("MM/dd/yyyy");
        dateDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("date", dateDateFormatter);
        java.text.DateFormat timeTimeFormatter = new java.text.SimpleDateFormat("HH:mm");
        this.dateTimeFormatters.put("time", timeTimeFormatter);
        java.text.DateFormat dateWithTimeDateFormatter = new java.text.SimpleDateFormat("dddd/MM/yyyy HH:mm:ss");
        dateWithTimeDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("dateWithTime", dateWithTimeDateFormatter);
        java.text.DateFormat dateWithoutCalendarDateFormatter = new java.text.SimpleDateFormat("MM/dd/yyyy");
        dateWithoutCalendarDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("dateWithoutCalendar", dateWithoutCalendarDateFormatter);
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.util.Date date;

    /**
     * 
     */
    public java.util.Date getDate()
    {
        return this.date;
    }

    /**
     * Keeps track of whether or not the value of date has
     * be populated at least once.
     */
    private boolean dateSet = false;

    /**
     * Indicates whether or not the value for date has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateSet()
    {
        return this.dateSet;
    }

    /**
     * 
     */
    public void setDate(java.util.Date date)
    {
        this.date = date;
        this.dateSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] dateValueList;
    
    /**
     * Stores the labels
     */
    private Object[] dateLabelList;
    public Object[] getDateBackingList()
    {
        Object[] values = this.dateValueList;
        Object[] labels = this.dateLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDateValueList()
    {
        return this.dateValueList;
    }

    public void setDateValueList(Object[] dateValueList)
    {
        this.dateValueList = dateValueList;
    }

    public Object[] getDateLabelList()
    {
        return this.dateLabelList;
    }

    public void setDateLabelList(Object[] dateLabelList)
    {
        this.dateLabelList = dateLabelList;
    }

    public void setDateBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setDateBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.dateValueList = null;
        this.dateLabelList = null;
        if (items != null)
        {
            this.dateValueList = new Object[items.size()];
            this.dateLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.dateValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.dateValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.dateValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.dateLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setDateBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setDateBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.Date time;

    /**
     * 
     */
    public java.util.Date getTime()
    {
        return this.time;
    }

    /**
     * Keeps track of whether or not the value of time has
     * be populated at least once.
     */
    private boolean timeSet = false;

    /**
     * Indicates whether or not the value for time has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTimeSet()
    {
        return this.timeSet;
    }

    /**
     * 
     */
    public void setTime(java.util.Date time)
    {
        this.time = time;
        this.timeSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] timeValueList;
    
    /**
     * Stores the labels
     */
    private Object[] timeLabelList;
    public Object[] getTimeBackingList()
    {
        Object[] values = this.timeValueList;
        Object[] labels = this.timeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTimeValueList()
    {
        return this.timeValueList;
    }

    public void setTimeValueList(Object[] timeValueList)
    {
        this.timeValueList = timeValueList;
    }

    public Object[] getTimeLabelList()
    {
        return this.timeLabelList;
    }

    public void setTimeLabelList(Object[] timeLabelList)
    {
        this.timeLabelList = timeLabelList;
    }

    public void setTimeBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setTimeBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.timeValueList = null;
        this.timeLabelList = null;
        if (items != null)
        {
            this.timeValueList = new Object[items.size()];
            this.timeLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.timeValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.timeValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.timeValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.timeLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTimeBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTimeBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String text;

    /**
     * 
     */
    public java.lang.String getText()
    {
        return this.text;
    }

    /**
     * Keeps track of whether or not the value of text has
     * be populated at least once.
     */
    private boolean textSet = false;

    /**
     * Indicates whether or not the value for text has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextSet()
    {
        return this.textSet;
    }

    /**
     * 
     */
    public void setText(java.lang.String text)
    {
        this.text = text;
        this.textSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] textValueList;
    
    /**
     * Stores the labels
     */
    private Object[] textLabelList;
    public Object[] getTextBackingList()
    {
        Object[] values = this.textValueList;
        Object[] labels = this.textLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTextValueList()
    {
        return this.textValueList;
    }

    public void setTextValueList(Object[] textValueList)
    {
        this.textValueList = textValueList;
    }

    public Object[] getTextLabelList()
    {
        return this.textLabelList;
    }

    public void setTextLabelList(Object[] textLabelList)
    {
        this.textLabelList = textLabelList;
    }

    public void setTextBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setTextBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.textValueList = null;
        this.textLabelList = null;
        if (items != null)
        {
            this.textValueList = new Object[items.size()];
            this.textLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.textValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.textValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.textValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.textLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTextBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTextBackingList(items, valueProperty, labelProperty, null);
    }
    


    private int number;

    /**
     * 
     */
    public int getNumber()
    {
        return this.number;
    }

    /**
     * Keeps track of whether or not the value of number has
     * be populated at least once.
     */
    private boolean numberSet = false;

    /**
     * Indicates whether or not the value for number has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isNumberSet()
    {
        return this.numberSet;
    }

    /**
     * 
     */
    public void setNumber(int number)
    {
        this.number = number;
        this.numberSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] numberValueList;
    
    /**
     * Stores the labels
     */
    private Object[] numberLabelList;
    public Object[] getNumberBackingList()
    {
        Object[] values = this.numberValueList;
        Object[] labels = this.numberLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getNumberValueList()
    {
        return this.numberValueList;
    }

    public void setNumberValueList(Object[] numberValueList)
    {
        this.numberValueList = numberValueList;
    }

    public Object[] getNumberLabelList()
    {
        return this.numberLabelList;
    }

    public void setNumberLabelList(Object[] numberLabelList)
    {
        this.numberLabelList = numberLabelList;
    }

    public void setNumberBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setNumberBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.numberValueList = null;
        this.numberLabelList = null;
        if (items != null)
        {
            this.numberValueList = new Object[items.size()];
            this.numberLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.numberValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.numberValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.numberValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.numberLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setNumberBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setNumberBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.List collection;

    /**
     * 
     */
    public java.util.List getCollection()
    {
        return this.collection;
    }

    /**
     * Keeps track of whether or not the value of collection has
     * be populated at least once.
     */
    private boolean collectionSet = false;

    /**
     * Indicates whether or not the value for collection has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCollectionSet()
    {
        return this.collectionSet;
    }

    /**
     * 
     */
    public void setCollection(java.util.List collection)
    {
        this.collection = collection;
        this.collectionSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] collectionValueList;
    
    /**
     * Stores the labels
     */
    private Object[] collectionLabelList;
    public Object[] getCollectionBackingList()
    {
        Object[] values = this.collectionValueList;
        Object[] labels = this.collectionLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getCollectionValueList()
    {
        return this.collectionValueList;
    }

    public void setCollectionValueList(Object[] collectionValueList)
    {
        this.collectionValueList = collectionValueList;
    }

    public Object[] getCollectionLabelList()
    {
        return this.collectionLabelList;
    }

    public void setCollectionLabelList(Object[] collectionLabelList)
    {
        this.collectionLabelList = collectionLabelList;
    }

    public void setCollectionBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setCollectionBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.collectionValueList = null;
        this.collectionLabelList = null;
        if (items != null)
        {
            this.collectionValueList = new Object[items.size()];
            this.collectionLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.collectionValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.collectionValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.collectionValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.collectionLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setCollectionBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setCollectionBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection collectionBackingValue;

    public void setCollectionBackingValue(java.util.Collection collectionBackingValue)
    {
        this.collectionBackingValue = collectionBackingValue;
    }
    
    public java.util.Collection getCollectionBackingValue()
    {
        return this.collectionBackingValue;
    }


    private java.lang.String selectable;

    /**
     * 
     */
    public java.lang.String getSelectable()
    {
        return this.selectable;
    }

    /**
     * Keeps track of whether or not the value of selectable has
     * be populated at least once.
     */
    private boolean selectableSet = false;

    /**
     * Indicates whether or not the value for selectable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSelectableSet()
    {
        return this.selectableSet;
    }

    /**
     * 
     */
    public void setSelectable(java.lang.String selectable)
    {
        this.selectable = selectable;
        this.selectableSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] selectableValueList;
    
    /**
     * Stores the labels
     */
    private Object[] selectableLabelList;
    public Object[] getSelectableBackingList()
    {
        Object[] values = this.selectableValueList;
        Object[] labels = this.selectableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSelectableValueList()
    {
        return this.selectableValueList;
    }

    public void setSelectableValueList(Object[] selectableValueList)
    {
        this.selectableValueList = selectableValueList;
    }

    public Object[] getSelectableLabelList()
    {
        return this.selectableLabelList;
    }

    public void setSelectableLabelList(Object[] selectableLabelList)
    {
        this.selectableLabelList = selectableLabelList;
    }

    public void setSelectableBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setSelectableBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.selectableValueList = null;
        this.selectableLabelList = null;
        if (items != null)
        {
            this.selectableValueList = new Object[items.size()];
            this.selectableLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.selectableValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.selectableValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.selectableValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.selectableLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setSelectableBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setSelectableBackingList(items, valueProperty, labelProperty, null);
    }
    


    private boolean bool;

    /**
     * 
     */
    public boolean isBool()
    {
        return this.bool;
    }

    /**
     * Keeps track of whether or not the value of bool has
     * be populated at least once.
     */
    private boolean boolSet = false;

    /**
     * Indicates whether or not the value for bool has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBoolSet()
    {
        return this.boolSet;
    }

    /**
     * 
     */
    public void setBool(boolean bool)
    {
        this.bool = bool;
        this.boolSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] boolValueList;
    
    /**
     * Stores the labels
     */
    private Object[] boolLabelList;
    public Object[] getBoolBackingList()
    {
        Object[] values = this.boolValueList;
        Object[] labels = this.boolLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getBoolValueList()
    {
        return this.boolValueList;
    }

    public void setBoolValueList(Object[] boolValueList)
    {
        this.boolValueList = boolValueList;
    }

    public Object[] getBoolLabelList()
    {
        return this.boolLabelList;
    }

    public void setBoolLabelList(Object[] boolLabelList)
    {
        this.boolLabelList = boolLabelList;
    }

    public void setBoolBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setBoolBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.boolValueList = null;
        this.boolLabelList = null;
        if (items != null)
        {
            this.boolValueList = new Object[items.size()];
            this.boolLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.boolValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.boolValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.boolValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.boolLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setBoolBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setBoolBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.List multiSelect;

    /**
     * 
     */
    public java.util.List getMultiSelect()
    {
        return this.multiSelect;
    }

    /**
     * Keeps track of whether or not the value of multiSelect has
     * be populated at least once.
     */
    private boolean multiSelectSet = false;

    /**
     * Indicates whether or not the value for multiSelect has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiSelectSet()
    {
        return this.multiSelectSet;
    }

    /**
     * 
     */
    public void setMultiSelect(java.util.List multiSelect)
    {
        this.multiSelect = multiSelect;
        this.multiSelectSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] multiSelectValueList;
    
    /**
     * Stores the labels
     */
    private Object[] multiSelectLabelList;
    public Object[] getMultiSelectBackingList()
    {
        Object[] values = this.multiSelectValueList;
        Object[] labels = this.multiSelectLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMultiSelectValueList()
    {
        return this.multiSelectValueList;
    }

    public void setMultiSelectValueList(Object[] multiSelectValueList)
    {
        this.multiSelectValueList = multiSelectValueList;
    }

    public Object[] getMultiSelectLabelList()
    {
        return this.multiSelectLabelList;
    }

    public void setMultiSelectLabelList(Object[] multiSelectLabelList)
    {
        this.multiSelectLabelList = multiSelectLabelList;
    }

    public void setMultiSelectBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setMultiSelectBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;
        if (items != null)
        {
            this.multiSelectValueList = new Object[items.size()];
            this.multiSelectLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.multiSelectValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.multiSelectValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.multiSelectValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.multiSelectLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setMultiSelectBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setMultiSelectBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection multiSelectBackingValue;

    public void setMultiSelectBackingValue(java.util.Collection multiSelectBackingValue)
    {
        this.multiSelectBackingValue = multiSelectBackingValue;
    }
    
    public java.util.Collection getMultiSelectBackingValue()
    {
        return this.multiSelectBackingValue;
    }


    private java.lang.String title;

    /**
     * <p>
     * should not conflict with the use-cases title property in the
     * resource bundle
     * </p>
     */
    public java.lang.String getTitle()
    {
        return this.title;
    }

    /**
     * Keeps track of whether or not the value of title has
     * be populated at least once.
     */
    private boolean titleSet = false;

    /**
     * Indicates whether or not the value for title has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTitleSet()
    {
        return this.titleSet;
    }

    /**
     * <p>
     * should not conflict with the use-cases title property in the
     * resource bundle
     * </p>
     */
    public void setTitle(java.lang.String title)
    {
        this.title = title;
        this.titleSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] titleValueList;
    
    /**
     * Stores the labels
     */
    private Object[] titleLabelList;
    public Object[] getTitleBackingList()
    {
        Object[] values = this.titleValueList;
        Object[] labels = this.titleLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getTitleValueList()
    {
        return this.titleValueList;
    }

    public void setTitleValueList(Object[] titleValueList)
    {
        this.titleValueList = titleValueList;
    }

    public Object[] getTitleLabelList()
    {
        return this.titleLabelList;
    }

    public void setTitleLabelList(Object[] titleLabelList)
    {
        this.titleLabelList = titleLabelList;
    }

    public void setTitleBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setTitleBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.titleValueList = null;
        this.titleLabelList = null;
        if (items != null)
        {
            this.titleValueList = new Object[items.size()];
            this.titleLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.titleValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.titleValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.titleValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.titleLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setTitleBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setTitleBackingList(items, valueProperty, labelProperty, null);
    }
    


    private oracle.adf.view.faces.model.UploadedFile file;

    /**
     * 
     */
    public oracle.adf.view.faces.model.UploadedFile getFile()
    {
        return this.file;
    }

    /**
     * Keeps track of whether or not the value of file has
     * be populated at least once.
     */
    private boolean fileSet = false;

    /**
     * Indicates whether or not the value for file has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFileSet()
    {
        return this.fileSet;
    }

    /**
     * 
     */
    public void setFile(oracle.adf.view.faces.model.UploadedFile file)
    {
        this.file = file;
        this.fileSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] fileValueList;
    
    /**
     * Stores the labels
     */
    private Object[] fileLabelList;
    public Object[] getFileBackingList()
    {
        Object[] values = this.fileValueList;
        Object[] labels = this.fileLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFileValueList()
    {
        return this.fileValueList;
    }

    public void setFileValueList(Object[] fileValueList)
    {
        this.fileValueList = fileValueList;
    }

    public Object[] getFileLabelList()
    {
        return this.fileLabelList;
    }

    public void setFileLabelList(Object[] fileLabelList)
    {
        this.fileLabelList = fileLabelList;
    }

    public void setFileBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setFileBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.fileValueList = null;
        this.fileLabelList = null;
        if (items != null)
        {
            this.fileValueList = new Object[items.size()];
            this.fileLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.fileValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.fileValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.fileValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.fileLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setFileBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setFileBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String multiFormat;

    /**
     * 
     */
    public java.lang.String getMultiFormat()
    {
        return this.multiFormat;
    }

    /**
     * Keeps track of whether or not the value of multiFormat has
     * be populated at least once.
     */
    private boolean multiFormatSet = false;

    /**
     * Indicates whether or not the value for multiFormat has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiFormatSet()
    {
        return this.multiFormatSet;
    }

    /**
     * 
     */
    public void setMultiFormat(java.lang.String multiFormat)
    {
        this.multiFormat = multiFormat;
        this.multiFormatSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] multiFormatValueList;
    
    /**
     * Stores the labels
     */
    private Object[] multiFormatLabelList;
    public Object[] getMultiFormatBackingList()
    {
        Object[] values = this.multiFormatValueList;
        Object[] labels = this.multiFormatLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMultiFormatValueList()
    {
        return this.multiFormatValueList;
    }

    public void setMultiFormatValueList(Object[] multiFormatValueList)
    {
        this.multiFormatValueList = multiFormatValueList;
    }

    public Object[] getMultiFormatLabelList()
    {
        return this.multiFormatLabelList;
    }

    public void setMultiFormatLabelList(Object[] multiFormatLabelList)
    {
        this.multiFormatLabelList = multiFormatLabelList;
    }

    public void setMultiFormatBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setMultiFormatBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.multiFormatValueList = null;
        this.multiFormatLabelList = null;
        if (items != null)
        {
            this.multiFormatValueList = new Object[items.size()];
            this.multiFormatLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.multiFormatValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.multiFormatValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.multiFormatValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.multiFormatLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setMultiFormatBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setMultiFormatBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.Date dateWithTime;

    /**
     * 
     */
    public java.util.Date getDateWithTime()
    {
        return this.dateWithTime;
    }

    /**
     * Keeps track of whether or not the value of dateWithTime has
     * be populated at least once.
     */
    private boolean dateWithTimeSet = false;

    /**
     * Indicates whether or not the value for dateWithTime has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateWithTimeSet()
    {
        return this.dateWithTimeSet;
    }

    /**
     * 
     */
    public void setDateWithTime(java.util.Date dateWithTime)
    {
        this.dateWithTime = dateWithTime;
        this.dateWithTimeSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] dateWithTimeValueList;
    
    /**
     * Stores the labels
     */
    private Object[] dateWithTimeLabelList;
    public Object[] getDateWithTimeBackingList()
    {
        Object[] values = this.dateWithTimeValueList;
        Object[] labels = this.dateWithTimeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDateWithTimeValueList()
    {
        return this.dateWithTimeValueList;
    }

    public void setDateWithTimeValueList(Object[] dateWithTimeValueList)
    {
        this.dateWithTimeValueList = dateWithTimeValueList;
    }

    public Object[] getDateWithTimeLabelList()
    {
        return this.dateWithTimeLabelList;
    }

    public void setDateWithTimeLabelList(Object[] dateWithTimeLabelList)
    {
        this.dateWithTimeLabelList = dateWithTimeLabelList;
    }

    public void setDateWithTimeBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setDateWithTimeBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.dateWithTimeValueList = null;
        this.dateWithTimeLabelList = null;
        if (items != null)
        {
            this.dateWithTimeValueList = new Object[items.size()];
            this.dateWithTimeLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.dateWithTimeValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.dateWithTimeValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.dateWithTimeValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.dateWithTimeLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setDateWithTimeBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setDateWithTimeBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.Date dateWithoutCalendar;

    /**
     * 
     */
    public java.util.Date getDateWithoutCalendar()
    {
        return this.dateWithoutCalendar;
    }

    /**
     * Keeps track of whether or not the value of dateWithoutCalendar has
     * be populated at least once.
     */
    private boolean dateWithoutCalendarSet = false;

    /**
     * Indicates whether or not the value for dateWithoutCalendar has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateWithoutCalendarSet()
    {
        return this.dateWithoutCalendarSet;
    }

    /**
     * 
     */
    public void setDateWithoutCalendar(java.util.Date dateWithoutCalendar)
    {
        this.dateWithoutCalendar = dateWithoutCalendar;
        this.dateWithoutCalendarSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] dateWithoutCalendarValueList;
    
    /**
     * Stores the labels
     */
    private Object[] dateWithoutCalendarLabelList;
    public Object[] getDateWithoutCalendarBackingList()
    {
        Object[] values = this.dateWithoutCalendarValueList;
        Object[] labels = this.dateWithoutCalendarLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getDateWithoutCalendarValueList()
    {
        return this.dateWithoutCalendarValueList;
    }

    public void setDateWithoutCalendarValueList(Object[] dateWithoutCalendarValueList)
    {
        this.dateWithoutCalendarValueList = dateWithoutCalendarValueList;
    }

    public Object[] getDateWithoutCalendarLabelList()
    {
        return this.dateWithoutCalendarLabelList;
    }

    public void setDateWithoutCalendarLabelList(Object[] dateWithoutCalendarLabelList)
    {
        this.dateWithoutCalendarLabelList = dateWithoutCalendarLabelList;
    }

    public void setDateWithoutCalendarBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setDateWithoutCalendarBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.dateWithoutCalendarValueList = null;
        this.dateWithoutCalendarLabelList = null;
        if (items != null)
        {
            this.dateWithoutCalendarValueList = new Object[items.size()];
            this.dateWithoutCalendarLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.dateWithoutCalendarValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.dateWithoutCalendarValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.dateWithoutCalendarValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.dateWithoutCalendarLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setDateWithoutCalendarBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setDateWithoutCalendarBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String hasCustomValidator;

    /**
     * 
     */
    public java.lang.String getHasCustomValidator()
    {
        return this.hasCustomValidator;
    }

    /**
     * Keeps track of whether or not the value of hasCustomValidator has
     * be populated at least once.
     */
    private boolean hasCustomValidatorSet = false;

    /**
     * Indicates whether or not the value for hasCustomValidator has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHasCustomValidatorSet()
    {
        return this.hasCustomValidatorSet;
    }

    /**
     * 
     */
    public void setHasCustomValidator(java.lang.String hasCustomValidator)
    {
        this.hasCustomValidator = hasCustomValidator;
        this.hasCustomValidatorSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] hasCustomValidatorValueList;
    
    /**
     * Stores the labels
     */
    private Object[] hasCustomValidatorLabelList;
    public Object[] getHasCustomValidatorBackingList()
    {
        Object[] values = this.hasCustomValidatorValueList;
        Object[] labels = this.hasCustomValidatorLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getHasCustomValidatorValueList()
    {
        return this.hasCustomValidatorValueList;
    }

    public void setHasCustomValidatorValueList(Object[] hasCustomValidatorValueList)
    {
        this.hasCustomValidatorValueList = hasCustomValidatorValueList;
    }

    public Object[] getHasCustomValidatorLabelList()
    {
        return this.hasCustomValidatorLabelList;
    }

    public void setHasCustomValidatorLabelList(Object[] hasCustomValidatorLabelList)
    {
        this.hasCustomValidatorLabelList = hasCustomValidatorLabelList;
    }

    public void setHasCustomValidatorBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setHasCustomValidatorBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.hasCustomValidatorValueList = null;
        this.hasCustomValidatorLabelList = null;
        if (items != null)
        {
            this.hasCustomValidatorValueList = new Object[items.size()];
            this.hasCustomValidatorLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.hasCustomValidatorValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.hasCustomValidatorValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.hasCustomValidatorValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.hasCustomValidatorLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setHasCustomValidatorBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setHasCustomValidatorBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.Integer integerClass;

    /**
     * 
     */
    public java.lang.Integer getIntegerClass()
    {
        return this.integerClass;
    }

    /**
     * Keeps track of whether or not the value of integerClass has
     * be populated at least once.
     */
    private boolean integerClassSet = false;

    /**
     * Indicates whether or not the value for integerClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isIntegerClassSet()
    {
        return this.integerClassSet;
    }

    /**
     * 
     */
    public void setIntegerClass(java.lang.Integer integerClass)
    {
        this.integerClass = integerClass;
        this.integerClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] integerClassValueList;
    
    /**
     * Stores the labels
     */
    private Object[] integerClassLabelList;
    public Object[] getIntegerClassBackingList()
    {
        Object[] values = this.integerClassValueList;
        Object[] labels = this.integerClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getIntegerClassValueList()
    {
        return this.integerClassValueList;
    }

    public void setIntegerClassValueList(Object[] integerClassValueList)
    {
        this.integerClassValueList = integerClassValueList;
    }

    public Object[] getIntegerClassLabelList()
    {
        return this.integerClassLabelList;
    }

    public void setIntegerClassLabelList(Object[] integerClassLabelList)
    {
        this.integerClassLabelList = integerClassLabelList;
    }

    public void setIntegerClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setIntegerClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.integerClassValueList = null;
        this.integerClassLabelList = null;
        if (items != null)
        {
            this.integerClassValueList = new Object[items.size()];
            this.integerClassLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.integerClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.integerClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.integerClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.integerClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setIntegerClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setIntegerClassBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.List setClass;

    /**
     * 
     */
    public java.util.List getSetClass()
    {
        return this.setClass;
    }

    /**
     * Keeps track of whether or not the value of setClass has
     * be populated at least once.
     */
    private boolean setClassSet = false;

    /**
     * Indicates whether or not the value for setClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSetClassSet()
    {
        return this.setClassSet;
    }

    /**
     * 
     */
    public void setSetClass(java.util.List setClass)
    {
        this.setClass = setClass;
        this.setClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] setClassValueList;
    
    /**
     * Stores the labels
     */
    private Object[] setClassLabelList;
    public Object[] getSetClassBackingList()
    {
        Object[] values = this.setClassValueList;
        Object[] labels = this.setClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getSetClassValueList()
    {
        return this.setClassValueList;
    }

    public void setSetClassValueList(Object[] setClassValueList)
    {
        this.setClassValueList = setClassValueList;
    }

    public Object[] getSetClassLabelList()
    {
        return this.setClassLabelList;
    }

    public void setSetClassLabelList(Object[] setClassLabelList)
    {
        this.setClassLabelList = setClassLabelList;
    }

    public void setSetClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setSetClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.setClassValueList = null;
        this.setClassLabelList = null;
        if (items != null)
        {
            this.setClassValueList = new Object[items.size()];
            this.setClassLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.setClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.setClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.setClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.setClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setSetClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setSetClassBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Set setClassBackingValue;

    public void setSetClassBackingValue(java.util.Set setClassBackingValue)
    {
        this.setClassBackingValue = setClassBackingValue;
    }
    
    public java.util.Set getSetClassBackingValue()
    {
        return this.setClassBackingValue;
    }


    private java.util.Map mapClass;

    /**
     * 
     */
    public java.util.Map getMapClass()
    {
        return this.mapClass;
    }

    /**
     * Keeps track of whether or not the value of mapClass has
     * be populated at least once.
     */
    private boolean mapClassSet = false;

    /**
     * Indicates whether or not the value for mapClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMapClassSet()
    {
        return this.mapClassSet;
    }

    /**
     * 
     */
    public void setMapClass(java.util.Map mapClass)
    {
        this.mapClass = mapClass;
        this.mapClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] mapClassValueList;
    
    /**
     * Stores the labels
     */
    private Object[] mapClassLabelList;
    public Object[] getMapClassBackingList()
    {
        Object[] values = this.mapClassValueList;
        Object[] labels = this.mapClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getMapClassValueList()
    {
        return this.mapClassValueList;
    }

    public void setMapClassValueList(Object[] mapClassValueList)
    {
        this.mapClassValueList = mapClassValueList;
    }

    public Object[] getMapClassLabelList()
    {
        return this.mapClassLabelList;
    }

    public void setMapClassLabelList(Object[] mapClassLabelList)
    {
        this.mapClassLabelList = mapClassLabelList;
    }

    public void setMapClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setMapClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.mapClassValueList = null;
        this.mapClassLabelList = null;
        if (items != null)
        {
            this.mapClassValueList = new Object[items.size()];
            this.mapClassLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.mapClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.mapClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.mapClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.mapClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setMapClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setMapClassBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.Boolean booleanClass;

    /**
     * 
     */
    public java.lang.Boolean getBooleanClass()
    {
        return this.booleanClass;
    }

    /**
     * Keeps track of whether or not the value of booleanClass has
     * be populated at least once.
     */
    private boolean booleanClassSet = false;

    /**
     * Indicates whether or not the value for booleanClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBooleanClassSet()
    {
        return this.booleanClassSet;
    }

    /**
     * 
     */
    public void setBooleanClass(java.lang.Boolean booleanClass)
    {
        this.booleanClass = booleanClass;
        this.booleanClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] booleanClassValueList;
    
    /**
     * Stores the labels
     */
    private Object[] booleanClassLabelList;
    public Object[] getBooleanClassBackingList()
    {
        Object[] values = this.booleanClassValueList;
        Object[] labels = this.booleanClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getBooleanClassValueList()
    {
        return this.booleanClassValueList;
    }

    public void setBooleanClassValueList(Object[] booleanClassValueList)
    {
        this.booleanClassValueList = booleanClassValueList;
    }

    public Object[] getBooleanClassLabelList()
    {
        return this.booleanClassLabelList;
    }

    public void setBooleanClassLabelList(Object[] booleanClassLabelList)
    {
        this.booleanClassLabelList = booleanClassLabelList;
    }

    public void setBooleanClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setBooleanClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.booleanClassValueList = null;
        this.booleanClassLabelList = null;
        if (items != null)
        {
            this.booleanClassValueList = new Object[items.size()];
            this.booleanClassLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.booleanClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.booleanClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.booleanClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.booleanClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setBooleanClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setBooleanClassBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.Float floatClass;

    /**
     * 
     */
    public java.lang.Float getFloatClass()
    {
        return this.floatClass;
    }

    /**
     * Keeps track of whether or not the value of floatClass has
     * be populated at least once.
     */
    private boolean floatClassSet = false;

    /**
     * Indicates whether or not the value for floatClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFloatClassSet()
    {
        return this.floatClassSet;
    }

    /**
     * 
     */
    public void setFloatClass(java.lang.Float floatClass)
    {
        this.floatClass = floatClass;
        this.floatClassSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] floatClassValueList;
    
    /**
     * Stores the labels
     */
    private Object[] floatClassLabelList;
    public Object[] getFloatClassBackingList()
    {
        Object[] values = this.floatClassValueList;
        Object[] labels = this.floatClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getFloatClassValueList()
    {
        return this.floatClassValueList;
    }

    public void setFloatClassValueList(Object[] floatClassValueList)
    {
        this.floatClassValueList = floatClassValueList;
    }

    public Object[] getFloatClassLabelList()
    {
        return this.floatClassLabelList;
    }

    public void setFloatClassLabelList(Object[] floatClassLabelList)
    {
        this.floatClassLabelList = floatClassLabelList;
    }

    public void setFloatClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setFloatClassBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.floatClassValueList = null;
        this.floatClassLabelList = null;
        if (items != null)
        {
            this.floatClassValueList = new Object[items.size()];
            this.floatClassLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.floatClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.floatClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.floatClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.floatClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setFloatClassBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setFloatClassBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String hiddenWithDefaultValue = "someDefaultValue";

    /**
     * 
     */
    public java.lang.String getHiddenWithDefaultValue()
    {
        return this.hiddenWithDefaultValue;
    }

    /**
     * Keeps track of whether or not the value of hiddenWithDefaultValue has
     * be populated at least once.
     */
    private boolean hiddenWithDefaultValueSet = false;

    /**
     * Indicates whether or not the value for hiddenWithDefaultValue has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHiddenWithDefaultValueSet()
    {
        return this.hiddenWithDefaultValueSet;
    }

    /**
     * 
     */
    public void setHiddenWithDefaultValue(java.lang.String hiddenWithDefaultValue)
    {
        this.hiddenWithDefaultValue = hiddenWithDefaultValue;
        this.hiddenWithDefaultValueSet = true;
    }


    private java.lang.String bAdName;

    /**
     * 
     */
    public java.lang.String getBAdName()
    {
        return this.bAdName;
    }

    /**
     * Keeps track of whether or not the value of bAdName has
     * be populated at least once.
     */
    private boolean bAdNameSet = false;

    /**
     * Indicates whether or not the value for bAdName has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBAdNameSet()
    {
        return this.bAdNameSet;
    }

    /**
     * 
     */
    public void setBAdName(java.lang.String bAdName)
    {
        this.bAdName = bAdName;
        this.bAdNameSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] bAdNameValueList;
    
    /**
     * Stores the labels
     */
    private Object[] bAdNameLabelList;
    public Object[] getBAdNameBackingList()
    {
        Object[] values = this.bAdNameValueList;
        Object[] labels = this.bAdNameLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getBAdNameValueList()
    {
        return this.bAdNameValueList;
    }

    public void setBAdNameValueList(Object[] bAdNameValueList)
    {
        this.bAdNameValueList = bAdNameValueList;
    }

    public Object[] getBAdNameLabelList()
    {
        return this.bAdNameLabelList;
    }

    public void setBAdNameLabelList(Object[] bAdNameLabelList)
    {
        this.bAdNameLabelList = bAdNameLabelList;
    }

    public void setBAdNameBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setBAdNameBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.bAdNameValueList = null;
        this.bAdNameLabelList = null;
        if (items != null)
        {
            this.bAdNameValueList = new Object[items.size()];
            this.bAdNameLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.bAdNameValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.bAdNameValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.bAdNameValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.bAdNameLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setBAdNameBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setBAdNameBackingList(items, valueProperty, labelProperty, null);
    }
    


    private org.andromda.cartridges.jsf.tests.formfields.SubValueObject complexParameter;

    /**
     * 
     */
    public org.andromda.cartridges.jsf.tests.formfields.SubValueObject getComplexParameter()
    {
        if (this.complexParameter == null)
        {
            this.complexParameter = new org.andromda.cartridges.jsf.tests.formfields.SubValueObject();
            this.setComplexParameter(this.complexParameter);
        }
        return this.complexParameter;
    }

    /**
     * Keeps track of whether or not the value of complexParameter has
     * be populated at least once.
     */
    private boolean complexParameterSet = false;

    /**
     * Indicates whether or not the value for complexParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isComplexParameterSet()
    {
        return this.complexParameterSet;
    }

    /**
     * 
     */
    public void setComplexParameter(org.andromda.cartridges.jsf.tests.formfields.SubValueObject complexParameter)
    {
        this.complexParameter = complexParameter;
        this.complexParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] complexParameterSubValueObjectAttributeOneValueList;
    
    /**
     * Stores the labels
     */
    private Object[] complexParameterSubValueObjectAttributeOneLabelList;
    public Object[] getComplexParameterSubValueObjectAttributeOneBackingList()
    {
        Object[] values = this.complexParameterSubValueObjectAttributeOneValueList;
        Object[] labels = this.complexParameterSubValueObjectAttributeOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getComplexParameterSubValueObjectAttributeOneValueList()
    {
        return this.complexParameterSubValueObjectAttributeOneValueList;
    }

    public void setComplexParameterSubValueObjectAttributeOneValueList(Object[] complexParameterSubValueObjectAttributeOneValueList)
    {
        this.complexParameterSubValueObjectAttributeOneValueList = complexParameterSubValueObjectAttributeOneValueList;
    }

    public Object[] getComplexParameterSubValueObjectAttributeOneLabelList()
    {
        return this.complexParameterSubValueObjectAttributeOneLabelList;
    }

    public void setComplexParameterSubValueObjectAttributeOneLabelList(Object[] complexParameterSubValueObjectAttributeOneLabelList)
    {
        this.complexParameterSubValueObjectAttributeOneLabelList = complexParameterSubValueObjectAttributeOneLabelList;
    }

    public void setComplexParameterSubValueObjectAttributeOneBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setComplexParameterSubValueObjectAttributeOneBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.complexParameterSubValueObjectAttributeOneValueList = null;
        this.complexParameterSubValueObjectAttributeOneLabelList = null;
        if (items != null)
        {
            this.complexParameterSubValueObjectAttributeOneValueList = new Object[items.size()];
            this.complexParameterSubValueObjectAttributeOneLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.complexParameterSubValueObjectAttributeOneValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.complexParameterSubValueObjectAttributeOneValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.complexParameterSubValueObjectAttributeOneValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.complexParameterSubValueObjectAttributeOneLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setComplexParameterSubValueObjectAttributeOneBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setComplexParameterSubValueObjectAttributeOneBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores the values.
     */
    private Object[] complexParameterRootAttributeOneValueList;
    
    /**
     * Stores the labels
     */
    private Object[] complexParameterRootAttributeOneLabelList;
    public Object[] getComplexParameterRootAttributeOneBackingList()
    {
        Object[] values = this.complexParameterRootAttributeOneValueList;
        Object[] labels = this.complexParameterRootAttributeOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getComplexParameterRootAttributeOneValueList()
    {
        return this.complexParameterRootAttributeOneValueList;
    }

    public void setComplexParameterRootAttributeOneValueList(Object[] complexParameterRootAttributeOneValueList)
    {
        this.complexParameterRootAttributeOneValueList = complexParameterRootAttributeOneValueList;
    }

    public Object[] getComplexParameterRootAttributeOneLabelList()
    {
        return this.complexParameterRootAttributeOneLabelList;
    }

    public void setComplexParameterRootAttributeOneLabelList(Object[] complexParameterRootAttributeOneLabelList)
    {
        this.complexParameterRootAttributeOneLabelList = complexParameterRootAttributeOneLabelList;
    }

    public void setComplexParameterRootAttributeOneBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("OneSubmitFormImpl.setComplexParameterRootAttributeOneBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.complexParameterRootAttributeOneValueList = null;
        this.complexParameterRootAttributeOneLabelList = null;
        if (items != null)
        {
            this.complexParameterRootAttributeOneValueList = new Object[items.size()];
            this.complexParameterRootAttributeOneLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.complexParameterRootAttributeOneValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.complexParameterRootAttributeOneValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.complexParameterRootAttributeOneValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.complexParameterRootAttributeOneLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setComplexParameterRootAttributeOneBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setComplexParameterRootAttributeOneBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -1803195588026504400L;
}