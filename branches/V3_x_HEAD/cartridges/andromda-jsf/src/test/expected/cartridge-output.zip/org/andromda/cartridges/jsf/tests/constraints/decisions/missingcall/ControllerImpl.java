// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.decisions.missingcall;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.decisions.missingcall.Controller
 */
public class ControllerImpl
    extends Controller
{

}