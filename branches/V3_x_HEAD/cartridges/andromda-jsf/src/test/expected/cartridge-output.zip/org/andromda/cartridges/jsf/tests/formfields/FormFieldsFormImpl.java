// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

/**
 * 
 */
public class FormFieldsFormImpl
    implements java.io.Serializable
{
    public FormFieldsFormImpl()
    {
        java.text.DateFormat dateDateFormatter = new java.text.SimpleDateFormat("MM/dd/yyyy");
        dateDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("date", dateDateFormatter);
        java.text.DateFormat timeTimeFormatter = new java.text.SimpleDateFormat("HH:mm");
        this.dateTimeFormatters.put("time", timeTimeFormatter);
        java.text.DateFormat dateWithTimeDateFormatter = new java.text.SimpleDateFormat("dddd/MM/yyyy HH:mm:ss");
        dateWithTimeDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("dateWithTime", dateWithTimeDateFormatter);
        java.text.DateFormat dateWithoutCalendarDateFormatter = new java.text.SimpleDateFormat("MM/dd/yyyy");
        dateWithoutCalendarDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("dateWithoutCalendar", dateWithoutCalendarDateFormatter);
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.util.Date date;

    /**
     * 
     */
    public java.util.Date getDate()
    {
        return this.date;
    }

    /**
     * Keeps track of whether or not the value of date has
     * be populated at least once.
     */
    private boolean dateSet = false;

    /**
     * Indicates whether or not the value for date has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateSet()
    {
        return this.dateSet;
    }

    /**
     * 
     */
    public void setDate(java.util.Date date)
    {
        this.date = date;
        this.dateSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] dateValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] dateLabelList;
    public java.lang.Object[] getDateBackingList()
    {
        java.lang.Object[] values = this.dateValueList;
        java.lang.Object[] labels = this.dateLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getDateValueList()
    {
        return this.dateValueList;
    }

    public void setDateValueList(java.lang.Object[] dateValueList)
    {
        this.dateValueList = dateValueList;
    }

    public java.lang.Object[] getDateLabelList()
    {
        return this.dateLabelList;
    }

    public void setDateLabelList(java.lang.Object[] dateLabelList)
    {
        this.dateLabelList = dateLabelList;
    }

    public void setDateBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setDateBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.dateValueList = null;
        this.dateLabelList = null;
        if (items != null)
        {
            this.dateValueList = new java.lang.Object[items.size()];
            this.dateLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.dateValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.dateValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.dateValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.dateLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setDateBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setDateBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.Date time;

    /**
     * 
     */
    public java.util.Date getTime()
    {
        return this.time;
    }

    /**
     * Keeps track of whether or not the value of time has
     * be populated at least once.
     */
    private boolean timeSet = false;

    /**
     * Indicates whether or not the value for time has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTimeSet()
    {
        return this.timeSet;
    }

    /**
     * 
     */
    public void setTime(java.util.Date time)
    {
        this.time = time;
        this.timeSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] timeValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] timeLabelList;
    public java.lang.Object[] getTimeBackingList()
    {
        java.lang.Object[] values = this.timeValueList;
        java.lang.Object[] labels = this.timeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTimeValueList()
    {
        return this.timeValueList;
    }

    public void setTimeValueList(java.lang.Object[] timeValueList)
    {
        this.timeValueList = timeValueList;
    }

    public java.lang.Object[] getTimeLabelList()
    {
        return this.timeLabelList;
    }

    public void setTimeLabelList(java.lang.Object[] timeLabelList)
    {
        this.timeLabelList = timeLabelList;
    }

    public void setTimeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setTimeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.timeValueList = null;
        this.timeLabelList = null;
        if (items != null)
        {
            this.timeValueList = new java.lang.Object[items.size()];
            this.timeLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.timeValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.timeValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.timeValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.timeLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setTimeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setTimeBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String text;

    /**
     * 
     */
    public java.lang.String getText()
    {
        return this.text;
    }

    /**
     * Keeps track of whether or not the value of text has
     * be populated at least once.
     */
    private boolean textSet = false;

    /**
     * Indicates whether or not the value for text has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTextSet()
    {
        return this.textSet;
    }

    /**
     * 
     */
    public void setText(java.lang.String text)
    {
        this.text = text;
        this.textSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] textValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] textLabelList;
    public java.lang.Object[] getTextBackingList()
    {
        java.lang.Object[] values = this.textValueList;
        java.lang.Object[] labels = this.textLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTextValueList()
    {
        return this.textValueList;
    }

    public void setTextValueList(java.lang.Object[] textValueList)
    {
        this.textValueList = textValueList;
    }

    public java.lang.Object[] getTextLabelList()
    {
        return this.textLabelList;
    }

    public void setTextLabelList(java.lang.Object[] textLabelList)
    {
        this.textLabelList = textLabelList;
    }

    public void setTextBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setTextBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.textValueList = null;
        this.textLabelList = null;
        if (items != null)
        {
            this.textValueList = new java.lang.Object[items.size()];
            this.textLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.textValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.textValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.textValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.textLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setTextBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setTextBackingList(items, valueProperty, labelProperty, null);
    }
    


    private int number;

    /**
     * 
     */
    public int getNumber()
    {
        return this.number;
    }

    /**
     * Keeps track of whether or not the value of number has
     * be populated at least once.
     */
    private boolean numberSet = false;

    /**
     * Indicates whether or not the value for number has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isNumberSet()
    {
        return this.numberSet;
    }

    /**
     * 
     */
    public void setNumber(int number)
    {
        this.number = number;
        this.numberSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] numberValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] numberLabelList;
    public java.lang.Object[] getNumberBackingList()
    {
        java.lang.Object[] values = this.numberValueList;
        java.lang.Object[] labels = this.numberLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getNumberValueList()
    {
        return this.numberValueList;
    }

    public void setNumberValueList(java.lang.Object[] numberValueList)
    {
        this.numberValueList = numberValueList;
    }

    public java.lang.Object[] getNumberLabelList()
    {
        return this.numberLabelList;
    }

    public void setNumberLabelList(java.lang.Object[] numberLabelList)
    {
        this.numberLabelList = numberLabelList;
    }

    public void setNumberBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setNumberBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.numberValueList = null;
        this.numberLabelList = null;
        if (items != null)
        {
            this.numberValueList = new java.lang.Object[items.size()];
            this.numberLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.numberValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.numberValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.numberValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.numberLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setNumberBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setNumberBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.List collection;

    /**
     * 
     */
    public java.util.List getCollection()
    {
        return this.collection;
    }

    /**
     * Keeps track of whether or not the value of collection has
     * be populated at least once.
     */
    private boolean collectionSet = false;

    /**
     * Indicates whether or not the value for collection has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCollectionSet()
    {
        return this.collectionSet;
    }

    /**
     * 
     */
    public void setCollection(java.util.List collection)
    {
        this.collection = collection;
        this.collectionSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] collectionValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] collectionLabelList;
    public java.lang.Object[] getCollectionBackingList()
    {
        java.lang.Object[] values = this.collectionValueList;
        java.lang.Object[] labels = this.collectionLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCollectionValueList()
    {
        return this.collectionValueList;
    }

    public void setCollectionValueList(java.lang.Object[] collectionValueList)
    {
        this.collectionValueList = collectionValueList;
    }

    public java.lang.Object[] getCollectionLabelList()
    {
        return this.collectionLabelList;
    }

    public void setCollectionLabelList(java.lang.Object[] collectionLabelList)
    {
        this.collectionLabelList = collectionLabelList;
    }

    public void setCollectionBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setCollectionBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.collectionValueList = null;
        this.collectionLabelList = null;
        if (items != null)
        {
            this.collectionValueList = new java.lang.Object[items.size()];
            this.collectionLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.collectionValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.collectionValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.collectionValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.collectionLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setCollectionBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setCollectionBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection collectionBackingValue;

    public void setCollectionBackingValue(java.util.Collection collectionBackingValue)
    {
        this.collectionBackingValue = collectionBackingValue;
    }
    
    public java.util.Collection getCollectionBackingValue()
    {
        return this.collectionBackingValue;
    }


    private java.lang.String selectable;

    /**
     * 
     */
    public java.lang.String getSelectable()
    {
        return this.selectable;
    }

    /**
     * Keeps track of whether or not the value of selectable has
     * be populated at least once.
     */
    private boolean selectableSet = false;

    /**
     * Indicates whether or not the value for selectable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSelectableSet()
    {
        return this.selectableSet;
    }

    /**
     * 
     */
    public void setSelectable(java.lang.String selectable)
    {
        this.selectable = selectable;
        this.selectableSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] selectableValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] selectableLabelList;
    public java.lang.Object[] getSelectableBackingList()
    {
        java.lang.Object[] values = this.selectableValueList;
        java.lang.Object[] labels = this.selectableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSelectableValueList()
    {
        return this.selectableValueList;
    }

    public void setSelectableValueList(java.lang.Object[] selectableValueList)
    {
        this.selectableValueList = selectableValueList;
    }

    public java.lang.Object[] getSelectableLabelList()
    {
        return this.selectableLabelList;
    }

    public void setSelectableLabelList(java.lang.Object[] selectableLabelList)
    {
        this.selectableLabelList = selectableLabelList;
    }

    public void setSelectableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setSelectableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.selectableValueList = null;
        this.selectableLabelList = null;
        if (items != null)
        {
            this.selectableValueList = new java.lang.Object[items.size()];
            this.selectableLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.selectableValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.selectableValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.selectableValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.selectableLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setSelectableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setSelectableBackingList(items, valueProperty, labelProperty, null);
    }
    


    private boolean bool;

    /**
     * 
     */
    public boolean isBool()
    {
        return this.bool;
    }

    /**
     * Keeps track of whether or not the value of bool has
     * be populated at least once.
     */
    private boolean boolSet = false;

    /**
     * Indicates whether or not the value for bool has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBoolSet()
    {
        return this.boolSet;
    }

    /**
     * 
     */
    public void setBool(boolean bool)
    {
        this.bool = bool;
        this.boolSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] boolValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] boolLabelList;
    public java.lang.Object[] getBoolBackingList()
    {
        java.lang.Object[] values = this.boolValueList;
        java.lang.Object[] labels = this.boolLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getBoolValueList()
    {
        return this.boolValueList;
    }

    public void setBoolValueList(java.lang.Object[] boolValueList)
    {
        this.boolValueList = boolValueList;
    }

    public java.lang.Object[] getBoolLabelList()
    {
        return this.boolLabelList;
    }

    public void setBoolLabelList(java.lang.Object[] boolLabelList)
    {
        this.boolLabelList = boolLabelList;
    }

    public void setBoolBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setBoolBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.boolValueList = null;
        this.boolLabelList = null;
        if (items != null)
        {
            this.boolValueList = new java.lang.Object[items.size()];
            this.boolLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.boolValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.boolValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.boolValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.boolLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setBoolBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setBoolBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.List multiSelect;

    /**
     * 
     */
    public java.util.List getMultiSelect()
    {
        return this.multiSelect;
    }

    /**
     * Keeps track of whether or not the value of multiSelect has
     * be populated at least once.
     */
    private boolean multiSelectSet = false;

    /**
     * Indicates whether or not the value for multiSelect has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiSelectSet()
    {
        return this.multiSelectSet;
    }

    /**
     * 
     */
    public void setMultiSelect(java.util.List multiSelect)
    {
        this.multiSelect = multiSelect;
        this.multiSelectSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] multiSelectValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] multiSelectLabelList;
    public java.lang.Object[] getMultiSelectBackingList()
    {
        java.lang.Object[] values = this.multiSelectValueList;
        java.lang.Object[] labels = this.multiSelectLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getMultiSelectValueList()
    {
        return this.multiSelectValueList;
    }

    public void setMultiSelectValueList(java.lang.Object[] multiSelectValueList)
    {
        this.multiSelectValueList = multiSelectValueList;
    }

    public java.lang.Object[] getMultiSelectLabelList()
    {
        return this.multiSelectLabelList;
    }

    public void setMultiSelectLabelList(java.lang.Object[] multiSelectLabelList)
    {
        this.multiSelectLabelList = multiSelectLabelList;
    }

    public void setMultiSelectBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setMultiSelectBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.multiSelectValueList = null;
        this.multiSelectLabelList = null;
        if (items != null)
        {
            this.multiSelectValueList = new java.lang.Object[items.size()];
            this.multiSelectLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.multiSelectValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.multiSelectValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.multiSelectValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.multiSelectLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setMultiSelectBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setMultiSelectBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection multiSelectBackingValue;

    public void setMultiSelectBackingValue(java.util.Collection multiSelectBackingValue)
    {
        this.multiSelectBackingValue = multiSelectBackingValue;
    }
    
    public java.util.Collection getMultiSelectBackingValue()
    {
        return this.multiSelectBackingValue;
    }


    private java.lang.String title;

    /**
     * <p>
     * should not conflict with the use-cases title property in the
     * resource bundle
     * </p>
     */
    public java.lang.String getTitle()
    {
        return this.title;
    }

    /**
     * Keeps track of whether or not the value of title has
     * be populated at least once.
     */
    private boolean titleSet = false;

    /**
     * Indicates whether or not the value for title has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTitleSet()
    {
        return this.titleSet;
    }

    /**
     * <p>
     * should not conflict with the use-cases title property in the
     * resource bundle
     * </p>
     */
    public void setTitle(java.lang.String title)
    {
        this.title = title;
        this.titleSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] titleValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] titleLabelList;
    public java.lang.Object[] getTitleBackingList()
    {
        java.lang.Object[] values = this.titleValueList;
        java.lang.Object[] labels = this.titleLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTitleValueList()
    {
        return this.titleValueList;
    }

    public void setTitleValueList(java.lang.Object[] titleValueList)
    {
        this.titleValueList = titleValueList;
    }

    public java.lang.Object[] getTitleLabelList()
    {
        return this.titleLabelList;
    }

    public void setTitleLabelList(java.lang.Object[] titleLabelList)
    {
        this.titleLabelList = titleLabelList;
    }

    public void setTitleBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setTitleBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.titleValueList = null;
        this.titleLabelList = null;
        if (items != null)
        {
            this.titleValueList = new java.lang.Object[items.size()];
            this.titleLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.titleValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.titleValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.titleValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.titleLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setTitleBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setTitleBackingList(items, valueProperty, labelProperty, null);
    }
    


    private oracle.adf.view.faces.model.UploadedFile file;

    /**
     * 
     */
    public oracle.adf.view.faces.model.UploadedFile getFile()
    {
        return this.file;
    }

    /**
     * Keeps track of whether or not the value of file has
     * be populated at least once.
     */
    private boolean fileSet = false;

    /**
     * Indicates whether or not the value for file has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFileSet()
    {
        return this.fileSet;
    }

    /**
     * 
     */
    public void setFile(oracle.adf.view.faces.model.UploadedFile file)
    {
        this.file = file;
        this.fileSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] fileValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] fileLabelList;
    public java.lang.Object[] getFileBackingList()
    {
        java.lang.Object[] values = this.fileValueList;
        java.lang.Object[] labels = this.fileLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFileValueList()
    {
        return this.fileValueList;
    }

    public void setFileValueList(java.lang.Object[] fileValueList)
    {
        this.fileValueList = fileValueList;
    }

    public java.lang.Object[] getFileLabelList()
    {
        return this.fileLabelList;
    }

    public void setFileLabelList(java.lang.Object[] fileLabelList)
    {
        this.fileLabelList = fileLabelList;
    }

    public void setFileBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setFileBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.fileValueList = null;
        this.fileLabelList = null;
        if (items != null)
        {
            this.fileValueList = new java.lang.Object[items.size()];
            this.fileLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.fileValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.fileValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.fileValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.fileLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setFileBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setFileBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String multiFormat;

    /**
     * 
     */
    public java.lang.String getMultiFormat()
    {
        return this.multiFormat;
    }

    /**
     * Keeps track of whether or not the value of multiFormat has
     * be populated at least once.
     */
    private boolean multiFormatSet = false;

    /**
     * Indicates whether or not the value for multiFormat has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMultiFormatSet()
    {
        return this.multiFormatSet;
    }

    /**
     * 
     */
    public void setMultiFormat(java.lang.String multiFormat)
    {
        this.multiFormat = multiFormat;
        this.multiFormatSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] multiFormatValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] multiFormatLabelList;
    public java.lang.Object[] getMultiFormatBackingList()
    {
        java.lang.Object[] values = this.multiFormatValueList;
        java.lang.Object[] labels = this.multiFormatLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getMultiFormatValueList()
    {
        return this.multiFormatValueList;
    }

    public void setMultiFormatValueList(java.lang.Object[] multiFormatValueList)
    {
        this.multiFormatValueList = multiFormatValueList;
    }

    public java.lang.Object[] getMultiFormatLabelList()
    {
        return this.multiFormatLabelList;
    }

    public void setMultiFormatLabelList(java.lang.Object[] multiFormatLabelList)
    {
        this.multiFormatLabelList = multiFormatLabelList;
    }

    public void setMultiFormatBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setMultiFormatBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.multiFormatValueList = null;
        this.multiFormatLabelList = null;
        if (items != null)
        {
            this.multiFormatValueList = new java.lang.Object[items.size()];
            this.multiFormatLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.multiFormatValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.multiFormatValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.multiFormatValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.multiFormatLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setMultiFormatBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setMultiFormatBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.Date dateWithTime;

    /**
     * 
     */
    public java.util.Date getDateWithTime()
    {
        return this.dateWithTime;
    }

    /**
     * Keeps track of whether or not the value of dateWithTime has
     * be populated at least once.
     */
    private boolean dateWithTimeSet = false;

    /**
     * Indicates whether or not the value for dateWithTime has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateWithTimeSet()
    {
        return this.dateWithTimeSet;
    }

    /**
     * 
     */
    public void setDateWithTime(java.util.Date dateWithTime)
    {
        this.dateWithTime = dateWithTime;
        this.dateWithTimeSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] dateWithTimeValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] dateWithTimeLabelList;
    public java.lang.Object[] getDateWithTimeBackingList()
    {
        java.lang.Object[] values = this.dateWithTimeValueList;
        java.lang.Object[] labels = this.dateWithTimeLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getDateWithTimeValueList()
    {
        return this.dateWithTimeValueList;
    }

    public void setDateWithTimeValueList(java.lang.Object[] dateWithTimeValueList)
    {
        this.dateWithTimeValueList = dateWithTimeValueList;
    }

    public java.lang.Object[] getDateWithTimeLabelList()
    {
        return this.dateWithTimeLabelList;
    }

    public void setDateWithTimeLabelList(java.lang.Object[] dateWithTimeLabelList)
    {
        this.dateWithTimeLabelList = dateWithTimeLabelList;
    }

    public void setDateWithTimeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setDateWithTimeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.dateWithTimeValueList = null;
        this.dateWithTimeLabelList = null;
        if (items != null)
        {
            this.dateWithTimeValueList = new java.lang.Object[items.size()];
            this.dateWithTimeLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.dateWithTimeValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.dateWithTimeValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.dateWithTimeValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.dateWithTimeLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setDateWithTimeBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setDateWithTimeBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.Date dateWithoutCalendar;

    /**
     * 
     */
    public java.util.Date getDateWithoutCalendar()
    {
        return this.dateWithoutCalendar;
    }

    /**
     * Keeps track of whether or not the value of dateWithoutCalendar has
     * be populated at least once.
     */
    private boolean dateWithoutCalendarSet = false;

    /**
     * Indicates whether or not the value for dateWithoutCalendar has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDateWithoutCalendarSet()
    {
        return this.dateWithoutCalendarSet;
    }

    /**
     * 
     */
    public void setDateWithoutCalendar(java.util.Date dateWithoutCalendar)
    {
        this.dateWithoutCalendar = dateWithoutCalendar;
        this.dateWithoutCalendarSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] dateWithoutCalendarValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] dateWithoutCalendarLabelList;
    public java.lang.Object[] getDateWithoutCalendarBackingList()
    {
        java.lang.Object[] values = this.dateWithoutCalendarValueList;
        java.lang.Object[] labels = this.dateWithoutCalendarLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getDateWithoutCalendarValueList()
    {
        return this.dateWithoutCalendarValueList;
    }

    public void setDateWithoutCalendarValueList(java.lang.Object[] dateWithoutCalendarValueList)
    {
        this.dateWithoutCalendarValueList = dateWithoutCalendarValueList;
    }

    public java.lang.Object[] getDateWithoutCalendarLabelList()
    {
        return this.dateWithoutCalendarLabelList;
    }

    public void setDateWithoutCalendarLabelList(java.lang.Object[] dateWithoutCalendarLabelList)
    {
        this.dateWithoutCalendarLabelList = dateWithoutCalendarLabelList;
    }

    public void setDateWithoutCalendarBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setDateWithoutCalendarBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.dateWithoutCalendarValueList = null;
        this.dateWithoutCalendarLabelList = null;
        if (items != null)
        {
            this.dateWithoutCalendarValueList = new java.lang.Object[items.size()];
            this.dateWithoutCalendarLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.dateWithoutCalendarValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.dateWithoutCalendarValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.dateWithoutCalendarValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.dateWithoutCalendarLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setDateWithoutCalendarBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setDateWithoutCalendarBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String hasCustomValidator;

    /**
     * 
     */
    public java.lang.String getHasCustomValidator()
    {
        return this.hasCustomValidator;
    }

    /**
     * Keeps track of whether or not the value of hasCustomValidator has
     * be populated at least once.
     */
    private boolean hasCustomValidatorSet = false;

    /**
     * Indicates whether or not the value for hasCustomValidator has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHasCustomValidatorSet()
    {
        return this.hasCustomValidatorSet;
    }

    /**
     * 
     */
    public void setHasCustomValidator(java.lang.String hasCustomValidator)
    {
        this.hasCustomValidator = hasCustomValidator;
        this.hasCustomValidatorSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] hasCustomValidatorValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] hasCustomValidatorLabelList;
    public java.lang.Object[] getHasCustomValidatorBackingList()
    {
        java.lang.Object[] values = this.hasCustomValidatorValueList;
        java.lang.Object[] labels = this.hasCustomValidatorLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getHasCustomValidatorValueList()
    {
        return this.hasCustomValidatorValueList;
    }

    public void setHasCustomValidatorValueList(java.lang.Object[] hasCustomValidatorValueList)
    {
        this.hasCustomValidatorValueList = hasCustomValidatorValueList;
    }

    public java.lang.Object[] getHasCustomValidatorLabelList()
    {
        return this.hasCustomValidatorLabelList;
    }

    public void setHasCustomValidatorLabelList(java.lang.Object[] hasCustomValidatorLabelList)
    {
        this.hasCustomValidatorLabelList = hasCustomValidatorLabelList;
    }

    public void setHasCustomValidatorBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setHasCustomValidatorBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.hasCustomValidatorValueList = null;
        this.hasCustomValidatorLabelList = null;
        if (items != null)
        {
            this.hasCustomValidatorValueList = new java.lang.Object[items.size()];
            this.hasCustomValidatorLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.hasCustomValidatorValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.hasCustomValidatorValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.hasCustomValidatorValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.hasCustomValidatorLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setHasCustomValidatorBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setHasCustomValidatorBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.Integer integerClass;

    /**
     * 
     */
    public java.lang.Integer getIntegerClass()
    {
        return this.integerClass;
    }

    /**
     * Keeps track of whether or not the value of integerClass has
     * be populated at least once.
     */
    private boolean integerClassSet = false;

    /**
     * Indicates whether or not the value for integerClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isIntegerClassSet()
    {
        return this.integerClassSet;
    }

    /**
     * 
     */
    public void setIntegerClass(java.lang.Integer integerClass)
    {
        this.integerClass = integerClass;
        this.integerClassSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] integerClassValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] integerClassLabelList;
    public java.lang.Object[] getIntegerClassBackingList()
    {
        java.lang.Object[] values = this.integerClassValueList;
        java.lang.Object[] labels = this.integerClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getIntegerClassValueList()
    {
        return this.integerClassValueList;
    }

    public void setIntegerClassValueList(java.lang.Object[] integerClassValueList)
    {
        this.integerClassValueList = integerClassValueList;
    }

    public java.lang.Object[] getIntegerClassLabelList()
    {
        return this.integerClassLabelList;
    }

    public void setIntegerClassLabelList(java.lang.Object[] integerClassLabelList)
    {
        this.integerClassLabelList = integerClassLabelList;
    }

    public void setIntegerClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setIntegerClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.integerClassValueList = null;
        this.integerClassLabelList = null;
        if (items != null)
        {
            this.integerClassValueList = new java.lang.Object[items.size()];
            this.integerClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.integerClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.integerClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.integerClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.integerClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setIntegerClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setIntegerClassBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.util.List setClass;

    /**
     * 
     */
    public java.util.List getSetClass()
    {
        return this.setClass;
    }

    /**
     * Keeps track of whether or not the value of setClass has
     * be populated at least once.
     */
    private boolean setClassSet = false;

    /**
     * Indicates whether or not the value for setClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isSetClassSet()
    {
        return this.setClassSet;
    }

    /**
     * 
     */
    public void setSetClass(java.util.List setClass)
    {
        this.setClass = setClass;
        this.setClassSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] setClassValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] setClassLabelList;
    public java.lang.Object[] getSetClassBackingList()
    {
        java.lang.Object[] values = this.setClassValueList;
        java.lang.Object[] labels = this.setClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getSetClassValueList()
    {
        return this.setClassValueList;
    }

    public void setSetClassValueList(java.lang.Object[] setClassValueList)
    {
        this.setClassValueList = setClassValueList;
    }

    public java.lang.Object[] getSetClassLabelList()
    {
        return this.setClassLabelList;
    }

    public void setSetClassLabelList(java.lang.Object[] setClassLabelList)
    {
        this.setClassLabelList = setClassLabelList;
    }

    public void setSetClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setSetClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.setClassValueList = null;
        this.setClassLabelList = null;
        if (items != null)
        {
            this.setClassValueList = new java.lang.Object[items.size()];
            this.setClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.setClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.setClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.setClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.setClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setSetClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setSetClassBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Set setClassBackingValue;

    public void setSetClassBackingValue(java.util.Set setClassBackingValue)
    {
        this.setClassBackingValue = setClassBackingValue;
    }
    
    public java.util.Set getSetClassBackingValue()
    {
        return this.setClassBackingValue;
    }


    private java.util.Map mapClass;

    /**
     * 
     */
    public java.util.Map getMapClass()
    {
        return this.mapClass;
    }

    /**
     * Keeps track of whether or not the value of mapClass has
     * be populated at least once.
     */
    private boolean mapClassSet = false;

    /**
     * Indicates whether or not the value for mapClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMapClassSet()
    {
        return this.mapClassSet;
    }

    /**
     * 
     */
    public void setMapClass(java.util.Map mapClass)
    {
        this.mapClass = mapClass;
        this.mapClassSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] mapClassValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] mapClassLabelList;
    public java.lang.Object[] getMapClassBackingList()
    {
        java.lang.Object[] values = this.mapClassValueList;
        java.lang.Object[] labels = this.mapClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getMapClassValueList()
    {
        return this.mapClassValueList;
    }

    public void setMapClassValueList(java.lang.Object[] mapClassValueList)
    {
        this.mapClassValueList = mapClassValueList;
    }

    public java.lang.Object[] getMapClassLabelList()
    {
        return this.mapClassLabelList;
    }

    public void setMapClassLabelList(java.lang.Object[] mapClassLabelList)
    {
        this.mapClassLabelList = mapClassLabelList;
    }

    public void setMapClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setMapClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.mapClassValueList = null;
        this.mapClassLabelList = null;
        if (items != null)
        {
            this.mapClassValueList = new java.lang.Object[items.size()];
            this.mapClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.mapClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.mapClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.mapClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.mapClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setMapClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setMapClassBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.Boolean booleanClass;

    /**
     * 
     */
    public java.lang.Boolean getBooleanClass()
    {
        return this.booleanClass;
    }

    /**
     * Keeps track of whether or not the value of booleanClass has
     * be populated at least once.
     */
    private boolean booleanClassSet = false;

    /**
     * Indicates whether or not the value for booleanClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBooleanClassSet()
    {
        return this.booleanClassSet;
    }

    /**
     * 
     */
    public void setBooleanClass(java.lang.Boolean booleanClass)
    {
        this.booleanClass = booleanClass;
        this.booleanClassSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] booleanClassValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] booleanClassLabelList;
    public java.lang.Object[] getBooleanClassBackingList()
    {
        java.lang.Object[] values = this.booleanClassValueList;
        java.lang.Object[] labels = this.booleanClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getBooleanClassValueList()
    {
        return this.booleanClassValueList;
    }

    public void setBooleanClassValueList(java.lang.Object[] booleanClassValueList)
    {
        this.booleanClassValueList = booleanClassValueList;
    }

    public java.lang.Object[] getBooleanClassLabelList()
    {
        return this.booleanClassLabelList;
    }

    public void setBooleanClassLabelList(java.lang.Object[] booleanClassLabelList)
    {
        this.booleanClassLabelList = booleanClassLabelList;
    }

    public void setBooleanClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setBooleanClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.booleanClassValueList = null;
        this.booleanClassLabelList = null;
        if (items != null)
        {
            this.booleanClassValueList = new java.lang.Object[items.size()];
            this.booleanClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.booleanClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.booleanClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.booleanClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.booleanClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setBooleanClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setBooleanClassBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.Float floatClass;

    /**
     * 
     */
    public java.lang.Float getFloatClass()
    {
        return this.floatClass;
    }

    /**
     * Keeps track of whether or not the value of floatClass has
     * be populated at least once.
     */
    private boolean floatClassSet = false;

    /**
     * Indicates whether or not the value for floatClass has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFloatClassSet()
    {
        return this.floatClassSet;
    }

    /**
     * 
     */
    public void setFloatClass(java.lang.Float floatClass)
    {
        this.floatClass = floatClass;
        this.floatClassSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] floatClassValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] floatClassLabelList;
    public java.lang.Object[] getFloatClassBackingList()
    {
        java.lang.Object[] values = this.floatClassValueList;
        java.lang.Object[] labels = this.floatClassLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFloatClassValueList()
    {
        return this.floatClassValueList;
    }

    public void setFloatClassValueList(java.lang.Object[] floatClassValueList)
    {
        this.floatClassValueList = floatClassValueList;
    }

    public java.lang.Object[] getFloatClassLabelList()
    {
        return this.floatClassLabelList;
    }

    public void setFloatClassLabelList(java.lang.Object[] floatClassLabelList)
    {
        this.floatClassLabelList = floatClassLabelList;
    }

    public void setFloatClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setFloatClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.floatClassValueList = null;
        this.floatClassLabelList = null;
        if (items != null)
        {
            this.floatClassValueList = new java.lang.Object[items.size()];
            this.floatClassLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.floatClassValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.floatClassValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.floatClassValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.floatClassLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setFloatClassBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setFloatClassBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String hiddenWithDefaultValue = "someDefaultValue";

    /**
     * 
     */
    public java.lang.String getHiddenWithDefaultValue()
    {
        return this.hiddenWithDefaultValue;
    }

    /**
     * Keeps track of whether or not the value of hiddenWithDefaultValue has
     * be populated at least once.
     */
    private boolean hiddenWithDefaultValueSet = false;

    /**
     * Indicates whether or not the value for hiddenWithDefaultValue has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHiddenWithDefaultValueSet()
    {
        return this.hiddenWithDefaultValueSet;
    }

    /**
     * 
     */
    public void setHiddenWithDefaultValue(java.lang.String hiddenWithDefaultValue)
    {
        this.hiddenWithDefaultValue = hiddenWithDefaultValue;
        this.hiddenWithDefaultValueSet = true;
    }


    private java.lang.String bAdName;

    /**
     * 
     */
    public java.lang.String getBAdName()
    {
        return this.bAdName;
    }

    /**
     * Keeps track of whether or not the value of bAdName has
     * be populated at least once.
     */
    private boolean bAdNameSet = false;

    /**
     * Indicates whether or not the value for bAdName has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBAdNameSet()
    {
        return this.bAdNameSet;
    }

    /**
     * 
     */
    public void setBAdName(java.lang.String bAdName)
    {
        this.bAdName = bAdName;
        this.bAdNameSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] bAdNameValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] bAdNameLabelList;
    public java.lang.Object[] getBAdNameBackingList()
    {
        java.lang.Object[] values = this.bAdNameValueList;
        java.lang.Object[] labels = this.bAdNameLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getBAdNameValueList()
    {
        return this.bAdNameValueList;
    }

    public void setBAdNameValueList(java.lang.Object[] bAdNameValueList)
    {
        this.bAdNameValueList = bAdNameValueList;
    }

    public java.lang.Object[] getBAdNameLabelList()
    {
        return this.bAdNameLabelList;
    }

    public void setBAdNameLabelList(java.lang.Object[] bAdNameLabelList)
    {
        this.bAdNameLabelList = bAdNameLabelList;
    }

    public void setBAdNameBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setBAdNameBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.bAdNameValueList = null;
        this.bAdNameLabelList = null;
        if (items != null)
        {
            this.bAdNameValueList = new java.lang.Object[items.size()];
            this.bAdNameLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.bAdNameValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.bAdNameValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.bAdNameValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.bAdNameLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setBAdNameBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setBAdNameBackingList(items, valueProperty, labelProperty, null);
    }
    


    private org.andromda.cartridges.jsf.tests.formfields.SubValueObject complexParameter;

    /**
     * 
     */
    public org.andromda.cartridges.jsf.tests.formfields.SubValueObject getComplexParameter()
    {
        if (this.complexParameter == null)
        {
            this.complexParameter = new org.andromda.cartridges.jsf.tests.formfields.SubValueObject();
            this.setComplexParameter(this.complexParameter);
        }
        return this.complexParameter;
    }

    /**
     * Keeps track of whether or not the value of complexParameter has
     * be populated at least once.
     */
    private boolean complexParameterSet = false;

    /**
     * Indicates whether or not the value for complexParameter has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isComplexParameterSet()
    {
        return this.complexParameterSet;
    }

    /**
     * 
     */
    public void setComplexParameter(org.andromda.cartridges.jsf.tests.formfields.SubValueObject complexParameter)
    {
        this.complexParameter = complexParameter;
        this.complexParameterSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] complexParameterSubValueObjectAttributeOneValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] complexParameterSubValueObjectAttributeOneLabelList;
    public java.lang.Object[] getComplexParameterSubValueObjectAttributeOneBackingList()
    {
        java.lang.Object[] values = this.complexParameterSubValueObjectAttributeOneValueList;
        java.lang.Object[] labels = this.complexParameterSubValueObjectAttributeOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getComplexParameterSubValueObjectAttributeOneValueList()
    {
        return this.complexParameterSubValueObjectAttributeOneValueList;
    }

    public void setComplexParameterSubValueObjectAttributeOneValueList(java.lang.Object[] complexParameterSubValueObjectAttributeOneValueList)
    {
        this.complexParameterSubValueObjectAttributeOneValueList = complexParameterSubValueObjectAttributeOneValueList;
    }

    public java.lang.Object[] getComplexParameterSubValueObjectAttributeOneLabelList()
    {
        return this.complexParameterSubValueObjectAttributeOneLabelList;
    }

    public void setComplexParameterSubValueObjectAttributeOneLabelList(java.lang.Object[] complexParameterSubValueObjectAttributeOneLabelList)
    {
        this.complexParameterSubValueObjectAttributeOneLabelList = complexParameterSubValueObjectAttributeOneLabelList;
    }

    public void setComplexParameterSubValueObjectAttributeOneBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setComplexParameterSubValueObjectAttributeOneBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.complexParameterSubValueObjectAttributeOneValueList = null;
        this.complexParameterSubValueObjectAttributeOneLabelList = null;
        if (items != null)
        {
            this.complexParameterSubValueObjectAttributeOneValueList = new java.lang.Object[items.size()];
            this.complexParameterSubValueObjectAttributeOneLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.complexParameterSubValueObjectAttributeOneValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.complexParameterSubValueObjectAttributeOneValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.complexParameterSubValueObjectAttributeOneValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.complexParameterSubValueObjectAttributeOneLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setComplexParameterSubValueObjectAttributeOneBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setComplexParameterSubValueObjectAttributeOneBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores the values.
     */
    private java.lang.Object[] complexParameterRootAttributeOneValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] complexParameterRootAttributeOneLabelList;
    public java.lang.Object[] getComplexParameterRootAttributeOneBackingList()
    {
        java.lang.Object[] values = this.complexParameterRootAttributeOneValueList;
        java.lang.Object[] labels = this.complexParameterRootAttributeOneLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getComplexParameterRootAttributeOneValueList()
    {
        return this.complexParameterRootAttributeOneValueList;
    }

    public void setComplexParameterRootAttributeOneValueList(java.lang.Object[] complexParameterRootAttributeOneValueList)
    {
        this.complexParameterRootAttributeOneValueList = complexParameterRootAttributeOneValueList;
    }

    public java.lang.Object[] getComplexParameterRootAttributeOneLabelList()
    {
        return this.complexParameterRootAttributeOneLabelList;
    }

    public void setComplexParameterRootAttributeOneLabelList(java.lang.Object[] complexParameterRootAttributeOneLabelList)
    {
        this.complexParameterRootAttributeOneLabelList = complexParameterRootAttributeOneLabelList;
    }

    public void setComplexParameterRootAttributeOneBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormFieldsFormImpl.setComplexParameterRootAttributeOneBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.complexParameterRootAttributeOneValueList = null;
        this.complexParameterRootAttributeOneLabelList = null;
        if (items != null)
        {
            this.complexParameterRootAttributeOneValueList = new java.lang.Object[items.size()];
            this.complexParameterRootAttributeOneLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.complexParameterRootAttributeOneValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.complexParameterRootAttributeOneValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.complexParameterRootAttributeOneValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.complexParameterRootAttributeOneLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setComplexParameterRootAttributeOneBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setComplexParameterRootAttributeOneBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -7652211626046938046L;
}