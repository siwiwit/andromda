// license-header java merge-point
package org.andromda.cartridges.jsf.tests.finalstates.nohrefnoname;

/**
 * @see org.andromda.cartridges.jsf.tests.finalstates.nohrefnoname.Controller
 */
public class ControllerImpl
    extends Controller
{

}