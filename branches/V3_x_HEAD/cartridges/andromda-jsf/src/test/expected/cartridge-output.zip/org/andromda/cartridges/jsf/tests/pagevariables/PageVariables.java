package org.andromda.cartridges.jsf.tests.pagevariables;

import java.io.IOException;

import javax.faces.FactoryFinder;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * This servlet is used to allow controller operation execution through
 * a URL call.
 */
public class PageVariables
    extends HttpServlet
{
    /**
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public void doGet(
        final HttpServletRequest request,
        final HttpServletResponse response)
        throws ServletException, IOException
    {
        // - we need to retrieve the faces context differently since we're outside of the
        //   faces servlet
        final LifecycleFactory lifecycleFactory =
            (LifecycleFactory)FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY);
        final Lifecycle lifecycle = lifecycleFactory.getLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE);
        final FacesContextFactory facesContextFactory =
            (FacesContextFactory)FactoryFinder.getFactory(FactoryFinder.FACES_CONTEXT_FACTORY);
        final FacesContext facesContext =
            facesContextFactory.getFacesContext(
                this.getServletContext(),
                request,
                response,
                lifecycle);
        final javax.faces.el.VariableResolver variableResolver = facesContext.getApplication().getVariableResolver();
        org.andromda.cartridges.jsf.tests.pagevariables.Controller controller =
            (org.andromda.cartridges.jsf.tests.pagevariables.Controller)variableResolver.resolveVariable(
                facesContext,
                "controller");
        String forwardPath = org.andromda.presentation.jsf.UseCaseForwards.getPath(controller.pageVariables());
        response.sendRedirect(request.getContextPath() + forwardPath);
    }

    /**
     * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    public void doPost(
        final HttpServletRequest request,
        final HttpServletResponse response)
        throws ServletException, IOException
    {
        this.doGet(request, response);
    }
}