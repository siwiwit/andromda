// license-header java merge-point
package org.andromda.cartridges.jsf.tests.finalstates.webpage;

/**
 * @see org.andromda.cartridges.jsf.tests.finalstates.webpage.Controller
 */
public class ControllerImpl
    extends Controller
{

}