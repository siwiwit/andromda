// license-header java merge-point
package org.andromda.cartridges.jsf.tests.pagevariables;

/**
 * 
 */
public class PageVariablesFormImpl
    implements java.io.Serializable
{
    public PageVariablesFormImpl()
    {
        java.text.DateFormat cDateFormatter = new java.text.SimpleDateFormat("MM/dd/yyyy");
        cDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("c", cDateFormatter);
    }

    private java.lang.String a;

    /**
     * 
     */
    public java.lang.String getA()
    {
        return this.a;
    }

    /**
     * Keeps track of whether or not the value of a has
     * be populated at least once.
     */
    private boolean aSet = false;

    /**
     * Indicates whether or not the value for a has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isASet()
    {
        return this.aSet;
    }

    /**
     * 
     */
    public void setA(java.lang.String a)
    {
        this.a = a;
        this.aSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] aValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] aLabelList;
    public java.lang.Object[] getABackingList()
    {
        java.lang.Object[] values = this.aValueList;
        java.lang.Object[] labels = this.aLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getAValueList()
    {
        return this.aValueList;
    }

    public void setAValueList(java.lang.Object[] aValueList)
    {
        this.aValueList = aValueList;
    }

    public java.lang.Object[] getALabelList()
    {
        return this.aLabelList;
    }

    public void setALabelList(java.lang.Object[] aLabelList)
    {
        this.aLabelList = aLabelList;
    }

    public void setABackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("PageVariablesFormImpl.setABackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.aValueList = null;
        this.aLabelList = null;
        if (items != null)
        {
            this.aValueList = new java.lang.Object[items.size()];
            this.aLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.aValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.aLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private int b;

    /**
     * 
     */
    public int getB()
    {
        return this.b;
    }

    /**
     * Keeps track of whether or not the value of b has
     * be populated at least once.
     */
    private boolean bSet = false;

    /**
     * Indicates whether or not the value for b has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isBSet()
    {
        return this.bSet;
    }

    /**
     * 
     */
    public void setB(int b)
    {
        this.b = b;
        this.bSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] bValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] bLabelList;
    public java.lang.Object[] getBBackingList()
    {
        java.lang.Object[] values = this.bValueList;
        java.lang.Object[] labels = this.bLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getBValueList()
    {
        return this.bValueList;
    }

    public void setBValueList(java.lang.Object[] bValueList)
    {
        this.bValueList = bValueList;
    }

    public java.lang.Object[] getBLabelList()
    {
        return this.bLabelList;
    }

    public void setBLabelList(java.lang.Object[] bLabelList)
    {
        this.bLabelList = bLabelList;
    }

    public void setBBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("PageVariablesFormImpl.setBBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.bValueList = null;
        this.bLabelList = null;
        if (items != null)
        {
            this.bValueList = new java.lang.Object[items.size()];
            this.bLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.bValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.bLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.util.Date c;

    /**
     * 
     */
    public java.util.Date getC()
    {
        return this.c;
    }

    /**
     * Keeps track of whether or not the value of c has
     * be populated at least once.
     */
    private boolean cSet = false;

    /**
     * Indicates whether or not the value for c has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCSet()
    {
        return this.cSet;
    }

    /**
     * 
     */
    public void setC(java.util.Date c)
    {
        this.c = c;
        this.cSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] cValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] cLabelList;
    public java.lang.Object[] getCBackingList()
    {
        java.lang.Object[] values = this.cValueList;
        java.lang.Object[] labels = this.cLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCValueList()
    {
        return this.cValueList;
    }

    public void setCValueList(java.lang.Object[] cValueList)
    {
        this.cValueList = cValueList;
    }

    public java.lang.Object[] getCLabelList()
    {
        return this.cLabelList;
    }

    public void setCLabelList(java.lang.Object[] cLabelList)
    {
        this.cLabelList = cLabelList;
    }

    public void setCBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("PageVariablesFormImpl.setCBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.cValueList = null;
        this.cLabelList = null;
        if (items != null)
        {
            this.cValueList = new java.lang.Object[items.size()];
            this.cLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.cValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.cLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -7272526022808945793L;
}