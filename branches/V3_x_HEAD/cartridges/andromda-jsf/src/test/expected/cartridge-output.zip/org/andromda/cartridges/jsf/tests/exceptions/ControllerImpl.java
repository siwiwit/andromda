// license-header java merge-point
package org.andromda.cartridges.jsf.tests.exceptions;

/**
 * @see org.andromda.cartridges.jsf.tests.exceptions.Controller
 */
public class ControllerImpl
    extends Controller
{

}