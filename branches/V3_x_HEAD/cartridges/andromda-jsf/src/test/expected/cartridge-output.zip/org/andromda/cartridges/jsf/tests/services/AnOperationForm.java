// license-header java merge-point
package org.andromda.cartridges.jsf.tests.services;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.services.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.services.Controller#anOperation(java.lang.String one)
 */
public interface AnOperationForm
{
    /**
     * 
     */
    public java.lang.String getOne();

    /**
     * 
     */
    public void setOne(java.lang.String one);
    
}