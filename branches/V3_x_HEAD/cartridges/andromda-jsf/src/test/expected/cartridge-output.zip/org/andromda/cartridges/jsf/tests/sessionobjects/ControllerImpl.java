// license-header java merge-point
package org.andromda.cartridges.jsf.tests.sessionobjects;

/**
 * @see org.andromda.cartridges.jsf.tests.sessionobjects.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.sessionobjects.Controller#someOperation()
     */
    public void someOperation()
    {
    }
    
}