// license-header java merge-point
package org.andromda.cartridges.jsf.tests.interactionstate;

/**
 * 
 */
public class InterActionStateFormImpl
    implements java.io.Serializable
{
    public InterActionStateFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String param;

    /**
     * 
     */
    public java.lang.String getParam()
    {
        return this.param;
    }

    /**
     * Keeps track of whether or not the value of param has
     * be populated at least once.
     */
    private boolean paramSet = false;

    /**
     * Indicates whether or not the value for param has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParamSet()
    {
        return this.paramSet;
    }

    /**
     * 
     */
    public void setParam(java.lang.String param)
    {
        this.param = param;
        this.paramSet = true;
    }

    /**
     * Stores the values.
     */
    private Object[] paramValueList;
    
    /**
     * Stores the labels
     */
    private Object[] paramLabelList;
    public Object[] getParamBackingList()
    {
        Object[] values = this.paramValueList;
        Object[] labels = this.paramLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public Object[] getParamValueList()
    {
        return this.paramValueList;
    }

    public void setParamValueList(Object[] paramValueList)
    {
        this.paramValueList = paramValueList;
    }

    public Object[] getParamLabelList()
    {
        return this.paramLabelList;
    }

    public void setParamLabelList(Object[] paramLabelList)
    {
        this.paramLabelList = paramLabelList;
    }

    public void setParamBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("InterActionStateFormImpl.setParamBackingList(java.util.Collection items, String valueProperty, String labelProperty, Class valuePropertyType) requires non-null arguments");
        }
        this.paramValueList = null;
        this.paramLabelList = null;
        if (items != null)
        {
            this.paramValueList = new Object[items.size()];
            this.paramLabelList = new Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final Object item = iterator.next();
                    this.paramValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final Object value = this.paramValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.paramValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.paramLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new RuntimeException(throwable);
            }
        }
    }
    
    public void setParamBackingList(java.util.Collection items, String valueProperty, String labelProperty)
    {
        this.setParamBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -5594668505357867997L;
}