// license-header java merge-point
package org.andromda.cartridges.jsf.tests.duplicateactions;

/**
 * 
 */
public class ShowSomethingSubmitFormImpl
    implements java.io.Serializable
{
    public ShowSomethingSubmitFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String testParam;

    /**
     * 
     */
    public java.lang.String getTestParam()
    {
        return this.testParam;
    }

    /**
     * Keeps track of whether or not the value of testParam has
     * be populated at least once.
     */
    private boolean testParamSet = false;

    /**
     * Indicates whether or not the value for testParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTestParamSet()
    {
        return this.testParamSet;
    }

    /**
     * 
     */
    public void setTestParam(java.lang.String testParam)
    {
        this.testParam = testParam;
        this.testParamSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] testParamValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] testParamLabelList;
    public java.lang.Object[] getTestParamBackingList()
    {
        java.lang.Object[] values = this.testParamValueList;
        java.lang.Object[] labels = this.testParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTestParamValueList()
    {
        return this.testParamValueList;
    }

    public void setTestParamValueList(java.lang.Object[] testParamValueList)
    {
        this.testParamValueList = testParamValueList;
    }

    public java.lang.Object[] getTestParamLabelList()
    {
        return this.testParamLabelList;
    }

    public void setTestParamLabelList(java.lang.Object[] testParamLabelList)
    {
        this.testParamLabelList = testParamLabelList;
    }

    public void setTestParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowSomethingSubmitFormImpl.setTestParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.testParamValueList = null;
        this.testParamLabelList = null;
        if (items != null)
        {
            this.testParamValueList = new java.lang.Object[items.size()];
            this.testParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.testParamValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.testParamLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 454170267760850989L;
}