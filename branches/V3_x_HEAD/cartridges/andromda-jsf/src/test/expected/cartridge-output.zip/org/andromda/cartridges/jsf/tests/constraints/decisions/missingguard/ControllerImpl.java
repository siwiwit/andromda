// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.decisions.missingguard.Controller#operation()
     */
    public java.lang.String operation() throws java.lang.Exception
    {
        return null;
    }
    
}