package org.andromda.cartridges.jsf.tests.deferringoperations;

import java.io.IOException;

import javax.faces.FactoryFinder;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * This filter handles the population of forms for the <em>state4</code>
 * view.
 */
public class State4Populator
    implements Filter
{

    private FilterConfig config;

    /**
     * Initialize the filter
     * 
     * @param config the configuration
     * @see javax.servlet.Filter#setFilterConfig(FilterConfig)
     */
    public void init(FilterConfig config)
    {
        this.config = config;
    }

    /**
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    public void doFilter(
        ServletRequest request,
        ServletResponse response,
        FilterChain chain) throws IOException, ServletException
    {
        this.populateFormAndViewVariables(request, response, null);
        chain.doFilter(request, response);
    }
    
    private void populateFormAndViewVariables(final ServletRequest request, final ServletResponse response, Object form)
        throws ServletException
    {
        // - we need to retrieve the faces context differently since we're outside of the
        //   faces servlet
        final LifecycleFactory lifecycleFactory =
            (LifecycleFactory)FactoryFinder.getFactory(FactoryFinder.LIFECYCLE_FACTORY);
        final Lifecycle lifecycle = lifecycleFactory.getLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE);
        final FacesContextFactory facesContextFactory =
            (FacesContextFactory)FactoryFinder.getFactory(FactoryFinder.FACES_CONTEXT_FACTORY);
        final FacesContext facesContext =
            facesContextFactory.getFacesContext(
                this.config.getServletContext(),
                request,
                response,
                lifecycle);
        oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        final javax.faces.el.VariableResolver variableResolver = facesContext.getApplication().getVariableResolver();
        final javax.servlet.http.HttpSession session = ((javax.servlet.http.HttpServletRequest)request).getSession();
        if (form == null)
        {  
            // - first try getting the form from the ADF processScope
            form = adfContext.getProcessScope().get("form");
            // - if the form is null, try getting the current adfContext from the session (and then remove it from the session)
            if (form == null)
            {
                adfContext = (oracle.adf.view.faces.context.AdfFacesContext)session.getAttribute("AndroMDAADFContext");       
                form = adfContext != null ? adfContext.getProcessScope().get("form") : null;    
                // - add the form to the current process scope since it wasn't in the current one to begin with
                oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance().getProcessScope().put("form", form);   
            }
        }
        else
        {
            // - since the form argument is not null, set it as the "form" in the processScope 
            //   (to replace the existing "form" attribute)
            adfContext.getProcessScope().put("form", form);
        }
        // - remove the ADF context in the event that its present
        session.removeAttribute("AndroMDAADFContext");
        try
        {
            // - populate the forms
            if (form != null)
            {    
                org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl deferringOperationsState4Trigger4Form =
                    (org.andromda.cartridges.jsf.tests.deferringoperations.State4Trigger4FormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "deferringOperationsState4Trigger4Form");
                // - populate the deferringOperationsState4Trigger4Form with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, deferringOperationsState4Trigger4Form);
                request.setAttribute("deferringOperationsState4Trigger4Form", deferringOperationsState4Trigger4Form);
                org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl deferringOperationsState4NullForm =
                    (org.andromda.cartridges.jsf.tests.deferringoperations.State4NullFormImpl)variableResolver.resolveVariable(
                    facesContext,
                    "deferringOperationsState4NullForm");
                // - populate the deferringOperationsState4NullForm with any parameters from the previous form
                org.andromda.presentation.jsf.FormPopulator.populateForm(form, deferringOperationsState4NullForm);
                request.setAttribute("deferringOperationsState4NullForm", deferringOperationsState4NullForm);
            }
            // - populate the view variables
            if (form != null)
            {    
                boolean allPropertiesReadable = true;
                final boolean testParam2BackingListReadable = org.apache.commons.beanutils.PropertyUtils.isReadable(form, "testParam2BackingList");
                if (testParam2BackingListReadable)
                {
                    request.setAttribute("testParam2BackingList", org.apache.commons.beanutils.PropertyUtils.getProperty(form, "testParam2BackingList"));
                }
                else
                {
                    allPropertiesReadable = false;
                }
                if (!allPropertiesReadable)
                {
                    // TODO: org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)variableResolver.resolveVariable(facesContext, "formHistory");
                    org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)adfContext.getProcessScope().get("formHistory");
                    if (formHistory != null)
                    {
                        form = formHistory.getLastFormInHistory();
                        if (form != null)
                        {
                            this.populateFormAndViewVariables(request, response, form);
                            formHistory.addFormToHistory(form);
                        }
                    }                
                }
            } 
        }
        catch (final Throwable throwable)
        {
            throw new ServletException(throwable);
        }
    }


    /**
     * @see javax.servlet.Filter#destroy()
     */
    public void destroy()
    {
        this.config = null;
    }
}