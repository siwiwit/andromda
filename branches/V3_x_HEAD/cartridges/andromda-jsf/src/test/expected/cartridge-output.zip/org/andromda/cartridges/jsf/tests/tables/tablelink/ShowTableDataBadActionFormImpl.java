// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * 
 */
public class ShowTableDataBadActionFormImpl
    implements java.io.Serializable    
{
    public ShowTableDataBadActionFormImpl()
    {
    }

    private java.lang.String thisParameterNameDoesNotExistAsTableColumn;

    /**
     * 
     */
    public java.lang.String getThisParameterNameDoesNotExistAsTableColumn()
    {
        return this.thisParameterNameDoesNotExistAsTableColumn;
    }
    
    /**
     * Keeps track of whether or not the value of thisParameterNameDoesNotExistAsTableColumn has
     * be populated at least once.
     */
    private boolean thisParameterNameDoesNotExistAsTableColumnSet = false;
    
    /**
     * Indicates whether or not the value for thisParameterNameDoesNotExistAsTableColumn has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isThisParameterNameDoesNotExistAsTableColumnSet()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnSet;
    }

    /**
     * 
     */
    public void setThisParameterNameDoesNotExistAsTableColumn(java.lang.String thisParameterNameDoesNotExistAsTableColumn)
    {
        this.thisParameterNameDoesNotExistAsTableColumn = thisParameterNameDoesNotExistAsTableColumn;
        this.thisParameterNameDoesNotExistAsTableColumnSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList;
    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnBackingList()
    {
        java.lang.Object[] values = this.thisParameterNameDoesNotExistAsTableColumnValueList;
        java.lang.Object[] labels = this.thisParameterNameDoesNotExistAsTableColumnLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnValueList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnValueList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnLabelList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnLabelList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataBadActionFormImpl.setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;
        if (items != null)
        {
            this.thisParameterNameDoesNotExistAsTableColumnValueList = new java.lang.Object[items.size()];
            this.thisParameterNameDoesNotExistAsTableColumnLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.thisParameterNameDoesNotExistAsTableColumnLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = -7596426928358654054L;
}