// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * 
 */
public class ShowTableDataBadActionFormImpl
    implements java.io.Serializable
{
    public ShowTableDataBadActionFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String thisParameterNameDoesNotExistAsTableColumn;

    /**
     * 
     */
    public java.lang.String getThisParameterNameDoesNotExistAsTableColumn()
    {
        return this.thisParameterNameDoesNotExistAsTableColumn;
    }

    /**
     * Keeps track of whether or not the value of thisParameterNameDoesNotExistAsTableColumn has
     * be populated at least once.
     */
    private boolean thisParameterNameDoesNotExistAsTableColumnSet = false;

    /**
     * Indicates whether or not the value for thisParameterNameDoesNotExistAsTableColumn has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isThisParameterNameDoesNotExistAsTableColumnSet()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnSet;
    }

    /**
     * 
     */
    public void setThisParameterNameDoesNotExistAsTableColumn(java.lang.String thisParameterNameDoesNotExistAsTableColumn)
    {
        this.thisParameterNameDoesNotExistAsTableColumn = thisParameterNameDoesNotExistAsTableColumn;
        this.thisParameterNameDoesNotExistAsTableColumnSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList;
    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnBackingList()
    {
        java.lang.Object[] values = this.thisParameterNameDoesNotExistAsTableColumnValueList;
        java.lang.Object[] labels = this.thisParameterNameDoesNotExistAsTableColumnLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnValueList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnValueList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnValueList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnValueList = thisParameterNameDoesNotExistAsTableColumnValueList;
    }

    public java.lang.Object[] getThisParameterNameDoesNotExistAsTableColumnLabelList()
    {
        return this.thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnLabelList(java.lang.Object[] thisParameterNameDoesNotExistAsTableColumnLabelList)
    {
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = thisParameterNameDoesNotExistAsTableColumnLabelList;
    }

    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("ShowTableDataBadActionFormImpl.setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.thisParameterNameDoesNotExistAsTableColumnValueList = null;
        this.thisParameterNameDoesNotExistAsTableColumnLabelList = null;
        if (items != null)
        {
            this.thisParameterNameDoesNotExistAsTableColumnValueList = new java.lang.Object[items.size()];
            this.thisParameterNameDoesNotExistAsTableColumnLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.thisParameterNameDoesNotExistAsTableColumnValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.thisParameterNameDoesNotExistAsTableColumnLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setThisParameterNameDoesNotExistAsTableColumnBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setThisParameterNameDoesNotExistAsTableColumnBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }
    
    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 6946340935181195343L;
}