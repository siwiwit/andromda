// license-header java merge-point
package org.andromda.cartridges.jsf.tests.finalstates.namednotusecase;

/**
 * @see org.andromda.cartridges.jsf.tests.finalstates.namednotusecase.Controller
 */
public class ControllerImpl
    extends Controller
{

}