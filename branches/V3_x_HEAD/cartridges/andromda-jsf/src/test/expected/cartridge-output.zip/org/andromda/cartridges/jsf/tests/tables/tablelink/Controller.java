// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.tablelink;

/**
 * 
 */
public abstract class Controller
    implements java.io.Serializable
{
    /**
     * 
     */
    public abstract void loadTableData(LoadTableDataForm form);


    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAgainFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataAgainForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAgainFormImpl getShowTableDataAgainForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataAgainForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAgainFormImpl)this.resolveVariable("tableLinkActivityShowTableDataAgainForm");
    }
    
    public java.lang.String showTableDataAgain()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAgainFormImpl form =
                this.getShowTableDataAgainForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "again";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataHyperlinkActionForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionFormImpl getShowTableDataHyperlinkActionForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataHyperlinkActionForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionFormImpl)this.resolveVariable("tableLinkActivityShowTableDataHyperlinkActionForm");
    }
    
    public java.lang.String showTableDataHyperlinkAction()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionFormImpl form =
                this.getShowTableDataHyperlinkActionForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "hyperlink-action";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataBadActionFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataBadActionForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataBadActionFormImpl getShowTableDataBadActionForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataBadActionForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataBadActionFormImpl)this.resolveVariable("tableLinkActivityShowTableDataBadActionForm");
    }
    
    public java.lang.String showTableDataBadAction()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataBadActionFormImpl form =
                this.getShowTableDataBadActionForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "bad-action";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl getShowTableDataHyperlinkActionDuplicatingParameterForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl)this.resolveVariable("tableLinkActivityShowTableDataHyperlinkActionDuplicatingParameterForm");
    }
    
    public java.lang.String showTableDataHyperlinkActionDuplicatingParameter()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkActionDuplicatingParameterFormImpl form =
                this.getShowTableDataHyperlinkActionDuplicatingParameterForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "hyperlink-action-duplicating-parameter";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkNotSpecifyingColumnFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkNotSpecifyingColumnFormImpl getShowTableDataHyperlinkNotSpecifyingColumnForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkNotSpecifyingColumnFormImpl)this.resolveVariable("tableLinkActivityShowTableDataHyperlinkNotSpecifyingColumnForm");
    }
    
    public java.lang.String showTableDataHyperlinkNotSpecifyingColumn()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataHyperlinkNotSpecifyingColumnFormImpl form =
                this.getShowTableDataHyperlinkNotSpecifyingColumnForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "hyperlink-not-specifying-column";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataActionWithBadTableLinkForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl getShowTableDataActionWithBadTableLinkForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataActionWithBadTableLinkForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl)this.resolveVariable("tableLinkActivityShowTableDataActionWithBadTableLinkForm");
    }
    
    public java.lang.String showTableDataActionWithBadTableLink()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataActionWithBadTableLinkFormImpl form =
                this.getShowTableDataActionWithBadTableLinkForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "action-with-bad-table-link";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataRealisticFormActionFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataRealisticFormActionForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataRealisticFormActionFormImpl getShowTableDataRealisticFormActionForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataRealisticFormActionForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataRealisticFormActionFormImpl)this.resolveVariable("tableLinkActivityShowTableDataRealisticFormActionForm");
    }
    
    public java.lang.String showTableDataRealisticFormAction()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataRealisticFormActionFormImpl form =
                this.getShowTableDataRealisticFormActionForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "realistic-form-action";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataImageLinkActionFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataImageLinkActionForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataImageLinkActionFormImpl getShowTableDataImageLinkActionForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataImageLinkActionForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataImageLinkActionFormImpl)this.resolveVariable("tableLinkActivityShowTableDataImageLinkActionForm");
    }
    
    public java.lang.String showTableDataImageLinkAction()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataImageLinkActionFormImpl form =
                this.getShowTableDataImageLinkActionForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "image-link-action";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataGlobalTableActionFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataGlobalTableActionForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataGlobalTableActionFormImpl getShowTableDataGlobalTableActionForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataGlobalTableActionForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataGlobalTableActionFormImpl)this.resolveVariable("tableLinkActivityShowTableDataGlobalTableActionForm");
    }
    
    public java.lang.String showTableDataGlobalTableAction()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataGlobalTableActionFormImpl form =
                this.getShowTableDataGlobalTableActionForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "global-table-action";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataDuplicateGlobalTableActionFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataDuplicateGlobalTableActionForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataDuplicateGlobalTableActionFormImpl getShowTableDataDuplicateGlobalTableActionForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataDuplicateGlobalTableActionForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataDuplicateGlobalTableActionFormImpl)this.resolveVariable("tableLinkActivityShowTableDataDuplicateGlobalTableActionForm");
    }
    
    public java.lang.String showTableDataDuplicateGlobalTableAction()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataDuplicateGlobalTableActionFormImpl form =
                this.getShowTableDataDuplicateGlobalTableActionForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "duplicate-global-table-action";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAnotherDuplicateGlobalTableActionFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAnotherDuplicateGlobalTableActionFormImpl getShowTableDataAnotherDuplicateGlobalTableActionForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAnotherDuplicateGlobalTableActionFormImpl)this.resolveVariable("tableLinkActivityShowTableDataAnotherDuplicateGlobalTableActionForm");
    }
    
    public java.lang.String showTableDataAnotherDuplicateGlobalTableAction()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.ShowTableDataAnotherDuplicateGlobalTableActionFormImpl form =
                this.getShowTableDataAnotherDuplicateGlobalTableActionForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = "another-duplicate-global-table-action";
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.tables.tablelink.TableLinkActivityFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>tableLinkActivityTableLinkActivityForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.tables.tablelink.TableLinkActivityFormImpl getTableLinkActivityForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "tableLinkActivityTableLinkActivityForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.tables.tablelink.TableLinkActivityFormImpl)this.resolveVariable("tableLinkActivityTableLinkActivityForm");
    }
    
    public java.lang.String tableLinkActivity()
    {
        String forward = null;
        try
        {
            final org.andromda.cartridges.jsf.tests.tables.tablelink.TableLinkActivityFormImpl form =
                this.getTableLinkActivityForm();

            // - pass any parameters from the previous form along
            org.andromda.presentation.jsf.FormPopulator.populateForm(this.resolveVariable("form"), form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                forward = _loadTableData(form);
                org.andromda.presentation.jsf.FormHistory formHistory = (org.andromda.presentation.jsf.FormHistory)this.resolveVariable("formHistory");
                if (formHistory != null)
                {
                    formHistory.addFormToHistory(form);
                }        
            }
            catch (final Throwable throwable)
            {
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
            this.getSession(true).setAttribute("form", form);
        }
        catch (final Throwable throwable)
        {
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _loadTableData(final org.andromda.cartridges.jsf.tests.tables.tablelink.TableLinkActivityFormImpl form)
    {
        java.lang.String forward = null;
        loadTableData(form);
        forward = "show-table-data";
        return forward;
    }

    /**
     * Gets the current faces context.  This object is the point
     * from which to retrieve any request, session, etc information.
     *
     * @return the JSF faces context instance.
     */
    protected javax.faces.context.FacesContext getContext()
    {
        return javax.faces.context.FacesContext.getCurrentInstance();
    }

    /**
     * A helper method that gets the current request from the faces
     * context.
     *
     * @return the current HttpServletRequest instance.
     */
    protected javax.servlet.http.HttpServletRequest getRequest()
    {
        return (javax.servlet.http.HttpServletRequest)this.getContext().getExternalContext().getRequest();
    }

    /**
     * A helper method that gets the current reponse from the faces
     * context.
     *
     * @return the current HttpServletReponse instance.
     */
    protected javax.servlet.http.HttpServletResponse getResponse()
    {
        return (javax.servlet.http.HttpServletResponse)this.getContext().getExternalContext().getResponse();
    }

    /**
     * A helper method that gets the current session from the faces
     * context.
     *
     * @param create If the create parameter is true, create (if necessary) and return a
     *        session instance associated with the current request. If the create
     *        parameter is false return any existing session instance associated with the
     *        current request, or return null if there is no such session.
     * @return the current HttpSession instance.
     */
    protected javax.servlet.http.HttpSession getSession(final boolean create)
    {
        return (javax.servlet.http.HttpSession)this.getContext().getExternalContext().getSession(create);
    }
    
    /**
     * Attempts to resolve the variable, given, the <code>name</code> of
     * the variable using the faces context variable resolver instance.
     * 
     * @return the resolved variable or null if not found.
     */
    protected java.lang.Object resolveVariable(final String name)
    {
        final javax.faces.context.FacesContext context = this.getContext();
        return context != null ? context.getApplication().getVariableResolver().resolveVariable(context, name) : null;    
    }

    /**
     * Finds the root cause of the given <code>throwable</code> and
     * adds the message taken from that cause to the faces context messages.
     *
     * @param throwable the exception information to add.
     */
    private final void addExceptionMessage(
        Throwable throwable)
    {
        String message = null;
        final Throwable rootCause = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(throwable);
        if (rootCause != null)
        {
            message = rootCause.toString();
        }
        if (message == null || message.trim().length() == 0)
        {
            message = throwable.toString();
        }
        this.addErrorMessage(message);
    }

    /**
     * Adds the given error <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addErrorMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_ERROR, message);
    }

    /**
     * Adds the given warning <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addWarningMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_WARN, message);
    }

    /**
     * Adds the given info <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addInfoMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_INFO, message);
    }

    /**
     * Adds the given fatal <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addFatalMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_FATAL, message);
    }

    /**
     * Adds a message to the faces context (which will show up on your view when using the
     * lt;h:messages/gt; tag).
     *
     * @param severity the severity of the message
     * @param message the message to add.
     */
    protected void addMessage(final javax.faces.application.FacesMessage.Severity severity, final String message)
    {
        final javax.faces.application.FacesMessage facesMessage = new javax.faces.application.FacesMessage(severity, message, message);
        javax.faces.context.FacesContext.getCurrentInstance().addMessage(
            null,
            facesMessage);
    }
    
    /**
     * Copies all matching properties from the <code>fromForm</code> to the given
     * <code>toForm</code> overridding any previously set values.
     */
    protected void copyForm(final Object fromForm, final Object toForm)
    {
        org.andromda.presentation.jsf.FormPopulator.populateForm(fromForm, toForm, true);
    }

    /**
     * Populates the form from the given parameters.  If the request parameter is null or an empty
     * string, then null is placed on the form.
     *
     * @param form the form to populate.
     * @param formatters any date or time formatters.
     */
    private final void populateFormFromRequestParameters(final Object form, final java.util.Map formatters)
    {
        try
        {
            final java.util.Map parameters = this.getContext().getExternalContext().getRequestParameterMap();
            for (final java.util.Iterator iterator = parameters.keySet().iterator(); iterator.hasNext();)
            {
                final String name = (String)iterator.next();
                if (org.apache.commons.beanutils.PropertyUtils.isWriteable(form, name))
                {
                    final java.beans.PropertyDescriptor descriptor =
                        org.apache.commons.beanutils.PropertyUtils.getPropertyDescriptor(form, name);
                    if (descriptor != null)
                    {
                        final String parameter = (String)parameters.get(name);
                        Object value = null;
                        // - only convert if the string is not empty
                        if (parameter != null && parameter.trim().length() > 0)
                        {
                            java.text.DateFormat formatter = (java.text.DateFormat)formatters.get(name);
                            // - if the formatter is available we use that, otherwise we attempt to convert
                            if (formatter != null)
                            {
                                try
                                {
                                    value = formatter.parse(parameter);
                                }
                                catch (java.text.ParseException parseException)
                                {
                                    // - try the default formatter (handles the default java.util.Date.toString() format)
                                    formatter = (java.text.DateFormat)formatters.get(null);
                                    value = formatter.parse(parameter); 
                                }
                            }
                            else
                            {
                                value = org.apache.commons.beanutils.ConvertUtils.convert(parameter, descriptor.getPropertyType());
                            }
                            org.apache.commons.beanutils.PropertyUtils.setProperty(form, name, value);
                        }
                    }
                }
            }
        }
        catch (final Throwable throwable)
        {
            throw new RuntimeException(throwable);
        }
    }
    
    /**
     * Finds the form (if one is present) on the given <code>component</code> having the given
     * <code>id</code>.
     * 
     * @param component the component to search.
     * @param id the id of the form.
     * @return the form or null if none was found.
     */
    private javax.faces.component.UIForm findForm(javax.faces.component.UIComponent component, String id)
    {
        javax.faces.component.UIForm foundForm = null;
        if (component != null)
        {
            for (final java.util.Iterator iterator = component.getFacetsAndChildren(); iterator.hasNext();)
            {
                final Object object = (javax.faces.component.UIComponent)iterator.next();
                if (object instanceof javax.faces.component.UIComponent)
                {
                    final javax.faces.component.UIComponent uiComponent = (javax.faces.component.UIComponent)object;
                    if (uiComponent instanceof javax.faces.component.UIForm)
                    {
                        final javax.faces.component.UIForm form = (javax.faces.component.UIForm)uiComponent;
                        if (form.getId().equals(id))
                        {
                            foundForm = form;
                            break;
                        }
                    }
                    foundForm = this.findForm(uiComponent, id);
                    if (foundForm != null)
                    {
                        break;
                    }
                }
            }
        }
        return foundForm;
    }
    
    /**
     * If the given <code>component</code> has an child input elements, this method findds
     * them all and populates them.  This is to get around the fact that when immediate is set to true
     * on a button that submits the form that the form isn't populated.
     * 
     * @param component the component to populate.
     */
    private void populateComponentInputs(javax.faces.component.UIComponent component)
    {
        if (component != null)
        {
            for (final java.util.Iterator iterator = component.getFacetsAndChildren(); iterator.hasNext();)
            {
                final javax.faces.component.UIComponent uiComponent = (javax.faces.component.UIComponent)iterator.next();
                if (uiComponent instanceof javax.faces.component.UIInput)
                {
                    try
                    {
                        final javax.faces.component.UIInput input = (javax.faces.component.UIInput)uiComponent;
                        input.validate(this.getContext());
                        input.updateModel(this.getContext());
                    }
                    catch (javax.faces.validator.ValidatorException exception)
                    {
                        // - ignore, no value is set (validate will be called by the regular
                        //   JSF lifecycle processing anyway, this is just called to populate the
                        //   local value
                    }
                }
                else
                {
                    this.populateComponentInputs(uiComponent);
                }
            }
        }
    }
}