// license-header java merge-point
package org.andromda.cartridges.jsf.tests.tables.notablelink;

/**
 * 
 */
public class NoTableLinkActivityFormImpl
    implements java.io.Serializable
{
    public NoTableLinkActivityFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.util.List tableData;

    /**
     * 
     */
    public java.util.List getTableData()
    {
        return this.tableData;
    }

    /**
     * Keeps track of whether or not the value of tableData has
     * be populated at least once.
     */
    private boolean tableDataSet = false;

    /**
     * Indicates whether or not the value for tableData has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isTableDataSet()
    {
        return this.tableDataSet;
    }

    /**
     * 
     */
    public void setTableData(java.util.List tableData)
    {
        this.tableData = tableData;
        this.tableDataSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] tableDataValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] tableDataLabelList;
    public java.lang.Object[] getTableDataBackingList()
    {
        java.lang.Object[] values = this.tableDataValueList;
        java.lang.Object[] labels = this.tableDataLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getTableDataValueList()
    {
        return this.tableDataValueList;
    }

    public void setTableDataValueList(java.lang.Object[] tableDataValueList)
    {
        this.tableDataValueList = tableDataValueList;
    }

    public java.lang.Object[] getTableDataLabelList()
    {
        return this.tableDataLabelList;
    }

    public void setTableDataLabelList(java.lang.Object[] tableDataLabelList)
    {
        this.tableDataLabelList = tableDataLabelList;
    }

    public void setTableDataBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("NoTableLinkActivityFormImpl.setTableDataBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.tableDataValueList = null;
        this.tableDataLabelList = null;
        if (items != null)
        {
            this.tableDataValueList = new java.lang.Object[items.size()];
            this.tableDataLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.tableDataValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.tableDataValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.tableDataValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.tableDataLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setTableDataBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setTableDataBackingList(items, valueProperty, labelProperty, null);
    }
    
    private java.util.Collection tableDataBackingValue;

    public void setTableDataBackingValue(java.util.Collection tableDataBackingValue)
    {
        this.tableDataBackingValue = tableDataBackingValue;
    }
    
    public java.util.Collection getTableDataBackingValue()
    {
        return this.tableDataBackingValue;
    }


    private org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTable;

    /**
     * 
     */
    public org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] getCustomTable()
    {
        return this.customTable;
    }

    /**
     * Keeps track of whether or not the value of customTable has
     * be populated at least once.
     */
    private boolean customTableSet = false;

    /**
     * Indicates whether or not the value for customTable has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCustomTableSet()
    {
        return this.customTableSet;
    }

    /**
     * 
     */
    public void setCustomTable(org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTable)
    {
        this.customTable = customTable;
        this.customTableSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] customTableValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] customTableLabelList;
    public java.lang.Object[] getCustomTableBackingList()
    {
        java.lang.Object[] values = this.customTableValueList;
        java.lang.Object[] labels = this.customTableLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCustomTableValueList()
    {
        return this.customTableValueList;
    }

    public void setCustomTableValueList(java.lang.Object[] customTableValueList)
    {
        this.customTableValueList = customTableValueList;
    }

    public java.lang.Object[] getCustomTableLabelList()
    {
        return this.customTableLabelList;
    }

    public void setCustomTableLabelList(java.lang.Object[] customTableLabelList)
    {
        this.customTableLabelList = customTableLabelList;
    }

    public void setCustomTableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("NoTableLinkActivityFormImpl.setCustomTableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.customTableValueList = null;
        this.customTableLabelList = null;
        if (items != null)
        {
            this.customTableValueList = new java.lang.Object[items.size()];
            this.customTableLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.customTableValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.customTableValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.customTableValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.customTableLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setCustomTableBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setCustomTableBackingList(items, valueProperty, labelProperty, null);
    }
    
    private org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTableBackingValue;

    public void setCustomTableBackingValue(org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] customTableBackingValue)
    {
        this.customTableBackingValue = customTableBackingValue;
    }
    
    public org.andromda.cartridges.jsf.tests.tables.notablelink.CustomTableRow[] getCustomTableBackingValue()
    {
        return this.customTableBackingValue;
    }

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Sets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @param messages a collection of the current Faces messages.
     */
    public void setJsfMessages(final java.util.Collection messages)
    {
        if (messages != null)
        {
            for (final java.util.Iterator iterator = messages.iterator(); iterator.hasNext();)
            {
                javax.faces.application.FacesMessage jsfMessage = (javax.faces.application.FacesMessage)iterator.next();
                this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
            }
        }
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 8406701110595000677L;
}