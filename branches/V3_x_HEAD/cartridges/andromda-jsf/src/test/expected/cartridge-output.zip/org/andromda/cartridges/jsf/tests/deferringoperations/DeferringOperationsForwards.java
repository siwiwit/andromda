package org.andromda.cartridges.jsf.tests.deferringoperations;

/**
 * Stores all forward paths available in the use case DeferringOperations keyed by forward name.
 */
final class DeferringOperationsForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("deferring-operations-state4", "/org/andromda/cartridges/jsf/tests/deferringoperations/state4.jsf");
            forwards.put("deferring-operations-state2", "/org/andromda/cartridges/jsf/tests/deferringoperations/state2.jsf");
            forwards.put("deferring-operations-state6", "/org/andromda/cartridges/jsf/tests/deferringoperations/state6.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}