package org.andromda.cartridges.jsf.tests.reset;

/**
 * Stores all forward paths available in the use case Reset keyed by forward name.
 */
final class ResetForwards
{
    /**
     * Gets the path given the forward <code>name</code>.  If a path can
     * not be found, null is returned.
     */
    static final String getPath(final String name)
    {
        if (forwards.isEmpty())
        {
            forwards.put("reset-usecase", "/org/andromda/cartridges/jsf/tests/reset/reset.jsf");
            forwards.put("reset-page", "/org/andromda/cartridges/jsf/tests/reset/reset-page.jsf");
        }
        return (String)forwards.get(name);
    }
    
    /**
     * Stores the keyed forward paths.
     */ 
    private static final java.util.Map forwards = new java.util.HashMap();
}