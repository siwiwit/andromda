// license-header java merge-point
package org.andromda.cartridges.jsf.tests.widgets;

/**
 * @see org.andromda.cartridges.jsf.tests.widgets.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.widgets.Controller#preloadSelects()
     */
    public void preloadSelects() throws java.lang.Exception
    {
    }
    
}