// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.decisions.returntypevoid;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.decisions.returntypevoid.Controller
 */
public class ControllerImpl
    extends Controller
{

    /**
     * @see org.andromda.cartridges.jsf.tests.constraints.decisions.returntypevoid.Controller#voidReturnTypeOperation()
     */
    public void voidReturnTypeOperation() throws java.lang.Exception
    {
    }
    
}