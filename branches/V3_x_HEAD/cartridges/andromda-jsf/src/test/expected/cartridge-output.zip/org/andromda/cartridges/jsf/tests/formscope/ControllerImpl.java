// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formscope;

/**
 * @see org.andromda.cartridges.jsf.tests.formscope.Controller
 */
public class ControllerImpl
    extends Controller
{

}