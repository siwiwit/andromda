// license-header java merge-point
package org.andromda.cartridges.jsf.tests.constraints.actionstates.noforward;

/**
 * @see org.andromda.cartridges.jsf.tests.constraints.actionstates.noforward.Controller
 */
public class ControllerImpl
    extends Controller
{

}