// license-header java merge-point
package org.andromda.cartridges.jsf.tests.interactionstate;

/**
 * 
 */
public class Page1SubmitFormImpl
    implements java.io.Serializable
{
    public Page1SubmitFormImpl()
    {
    }

    private int interActionStateParam;

    /**
     * 
     */
    public int getInterActionStateParam()
    {
        return this.interActionStateParam;
    }

    /**
     * Keeps track of whether or not the value of interActionStateParam has
     * be populated at least once.
     */
    private boolean interActionStateParamSet = false;

    /**
     * Indicates whether or not the value for interActionStateParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isInterActionStateParamSet()
    {
        return this.interActionStateParamSet;
    }

    /**
     * 
     */
    public void setInterActionStateParam(int interActionStateParam)
    {
        this.interActionStateParam = interActionStateParam;
        this.interActionStateParamSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] interActionStateParamValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] interActionStateParamLabelList;
    public java.lang.Object[] getInterActionStateParamBackingList()
    {
        java.lang.Object[] values = this.interActionStateParamValueList;
        java.lang.Object[] labels = this.interActionStateParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getInterActionStateParamValueList()
    {
        return this.interActionStateParamValueList;
    }

    public void setInterActionStateParamValueList(java.lang.Object[] interActionStateParamValueList)
    {
        this.interActionStateParamValueList = interActionStateParamValueList;
    }

    public java.lang.Object[] getInterActionStateParamLabelList()
    {
        return this.interActionStateParamLabelList;
    }

    public void setInterActionStateParamLabelList(java.lang.Object[] interActionStateParamLabelList)
    {
        this.interActionStateParamLabelList = interActionStateParamLabelList;
    }

    public void setInterActionStateParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("Page1SubmitFormImpl.setInterActionStateParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.interActionStateParamValueList = null;
        this.interActionStateParamLabelList = null;
        if (items != null)
        {
            this.interActionStateParamValueList = new java.lang.Object[items.size()];
            this.interActionStateParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.interActionStateParamValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.interActionStateParamLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String param;

    /**
     * 
     */
    public java.lang.String getParam()
    {
        return this.param;
    }

    /**
     * Keeps track of whether or not the value of param has
     * be populated at least once.
     */
    private boolean paramSet = false;

    /**
     * Indicates whether or not the value for param has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isParamSet()
    {
        return this.paramSet;
    }

    /**
     * 
     */
    public void setParam(java.lang.String param)
    {
        this.param = param;
        this.paramSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] paramValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] paramLabelList;
    public java.lang.Object[] getParamBackingList()
    {
        java.lang.Object[] values = this.paramValueList;
        java.lang.Object[] labels = this.paramLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getParamValueList()
    {
        return this.paramValueList;
    }

    public void setParamValueList(java.lang.Object[] paramValueList)
    {
        this.paramValueList = paramValueList;
    }

    public java.lang.Object[] getParamLabelList()
    {
        return this.paramLabelList;
    }

    public void setParamLabelList(java.lang.Object[] paramLabelList)
    {
        this.paramLabelList = paramLabelList;
    }

    public void setParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("Page1SubmitFormImpl.setParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.paramValueList = null;
        this.paramLabelList = null;
        if (items != null)
        {
            this.paramValueList = new java.lang.Object[items.size()];
            this.paramLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.paramValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.paramLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = -2466198971935441462L;
}