// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formscope;

/**
 * 
 */
public class APageSubmitFormImpl
    implements java.io.Serializable    
{
    public APageSubmitFormImpl()
    {
    }

    private java.lang.String eventParam;

    /**
     * 
     */
    public java.lang.String getEventParam()
    {
        return this.eventParam;
    }
    
    /**
     * Keeps track of whether or not the value of eventParam has
     * be populated at least once.
     */
    private boolean eventParamSet = false;
    
    /**
     * Indicates whether or not the value for eventParam has been set at least
     * once.
     * 
     * @return true/false
     */
    public boolean isEventParamSet()
    {
        return this.eventParamSet;
    }

    /**
     * 
     */
    public void setEventParam(java.lang.String eventParam)
    {
        this.eventParam = eventParam;
        this.eventParamSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] eventParamValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] eventParamLabelList;
    public java.lang.Object[] getEventParamBackingList()
    {
        java.lang.Object[] values = this.eventParamValueList;
        java.lang.Object[] labels = this.eventParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getEventParamValueList()
    {
        return this.eventParamValueList;
    }

    public void setEventParamValueList(java.lang.Object[] eventParamValueList)
    {
        this.eventParamValueList = eventParamValueList;
    }

    public java.lang.Object[] getEventParamLabelList()
    {
        return this.eventParamLabelList;
    }

    public void setEventParamLabelList(java.lang.Object[] eventParamLabelList)
    {
        this.eventParamLabelList = eventParamLabelList;
    }

    public void setEventParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("APageSubmitFormImpl.setEventParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.eventParamValueList = null;
        this.eventParamLabelList = null;
        if (items != null)
        {
            this.eventParamValueList = new java.lang.Object[items.size()];
            this.eventParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.eventParamValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty);
                    this.eventParamLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty);
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /** 
     * The serial version UID of this class. Needed for serialization. 
     */
    private static final long serialVersionUID = 4423810421062610311L;
}