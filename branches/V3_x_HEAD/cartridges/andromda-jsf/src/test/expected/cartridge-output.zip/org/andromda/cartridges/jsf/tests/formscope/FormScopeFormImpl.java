// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formscope;

/**
 * 
 */
public class FormScopeFormImpl
    implements java.io.Serializable
{
    public FormScopeFormImpl()
    {
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String eventParam;

    /**
     * 
     */
    public java.lang.String getEventParam()
    {
        return this.eventParam;
    }

    /**
     * Keeps track of whether or not the value of eventParam has
     * be populated at least once.
     */
    private boolean eventParamSet = false;

    /**
     * Indicates whether or not the value for eventParam has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isEventParamSet()
    {
        return this.eventParamSet;
    }

    /**
     * 
     */
    public void setEventParam(java.lang.String eventParam)
    {
        this.eventParam = eventParam;
        this.eventParamSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] eventParamValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] eventParamLabelList;
    public java.lang.Object[] getEventParamBackingList()
    {
        java.lang.Object[] values = this.eventParamValueList;
        java.lang.Object[] labels = this.eventParamLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getEventParamValueList()
    {
        return this.eventParamValueList;
    }

    public void setEventParamValueList(java.lang.Object[] eventParamValueList)
    {
        this.eventParamValueList = eventParamValueList;
    }

    public java.lang.Object[] getEventParamLabelList()
    {
        return this.eventParamLabelList;
    }

    public void setEventParamLabelList(java.lang.Object[] eventParamLabelList)
    {
        this.eventParamLabelList = eventParamLabelList;
    }

    public void setEventParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormScopeFormImpl.setEventParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.eventParamValueList = null;
        this.eventParamLabelList = null;
        if (items != null)
        {
            this.eventParamValueList = new java.lang.Object[items.size()];
            this.eventParamLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.eventParamValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.eventParamValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.eventParamValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.eventParamLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setEventParamBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setEventParamBackingList(items, valueProperty, labelProperty, null);
    }
    


    private java.lang.String pageVar;

    /**
     * 
     */
    public java.lang.String getPageVar()
    {
        return this.pageVar;
    }

    /**
     * Keeps track of whether or not the value of pageVar has
     * be populated at least once.
     */
    private boolean pageVarSet = false;

    /**
     * Indicates whether or not the value for pageVar has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isPageVarSet()
    {
        return this.pageVarSet;
    }

    /**
     * 
     */
    public void setPageVar(java.lang.String pageVar)
    {
        this.pageVar = pageVar;
        this.pageVarSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] pageVarValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] pageVarLabelList;
    public java.lang.Object[] getPageVarBackingList()
    {
        java.lang.Object[] values = this.pageVarValueList;
        java.lang.Object[] labels = this.pageVarLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(values[ctr], java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getPageVarValueList()
    {
        return this.pageVarValueList;
    }

    public void setPageVarValueList(java.lang.Object[] pageVarValueList)
    {
        this.pageVarValueList = pageVarValueList;
    }

    public java.lang.Object[] getPageVarLabelList()
    {
        return this.pageVarLabelList;
    }

    public void setPageVarLabelList(java.lang.Object[] pageVarLabelList)
    {
        this.pageVarLabelList = pageVarLabelList;
    }

    public void setPageVarBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("FormScopeFormImpl.setPageVarBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty, java.lang.Class valuePropertyType) requires non-null arguments");
        }
        this.pageVarValueList = null;
        this.pageVarLabelList = null;
        if (items != null)
        {
            this.pageVarValueList = new java.lang.Object[items.size()];
            this.pageVarLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.pageVarValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    // - if the valuePropertyType is specified, attempt to convert all values to that type
                    if (valuePropertyType != null)
                    {
                        final java.lang.Object value = this.pageVarValueList[ctr];
                        if (value != null && !valuePropertyType.isInstance(value))
                        {
                            try
                            {
                                this.pageVarValueList[ctr] = org.apache.commons.beanutils.ConvertUtils.convert(String.valueOf(value), valuePropertyType);      
                            }
                            catch (final java.lang.Exception exception)
                            {
                                // - ignore, means we couldn't perform the conversion
                            }
                        }                   
                    }
                    this.pageVarLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    
    public void setPageVarBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        this.setPageVarBackingList(items, valueProperty, labelProperty, null);
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }

    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();

    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     *
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }

    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * Clear the current {@link javax.faces.application.FacesMessage} message
     * instances stored within this form.
     *
     */
    public void clearJsfMessages()
    {
        this.jsfMessages.clear();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 730487784292559297L;
}