// license-header java merge-point
package org.andromda.cartridges.jsf.tests.validation;

/**
 * 
 */
public class EnterDataValidateFormImpl
    implements java.io.Serializable
{
    public EnterDataValidateFormImpl()
    {
        java.text.DateFormat lenientDateTestDateFormatter = new java.text.SimpleDateFormat("dd/MMM/yyyy");
        lenientDateTestDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("lenientDateTest", lenientDateTestDateFormatter);
        java.text.DateFormat strictDateTestDateFormatter = new java.text.SimpleDateFormat("strict dd/MM/yyyy");
        strictDateTestDateFormatter.setLenient(false);
        this.dateTimeFormatters.put("strictDateTest", strictDateTestDateFormatter);
        java.text.DateFormat hiddenNotValidatedDateFormatter = new java.text.SimpleDateFormat("MM/dd/yyyy");
        hiddenNotValidatedDateFormatter.setLenient(true);
        this.dateTimeFormatters.put("hiddenNotValidated", hiddenNotValidatedDateFormatter);
        // - setup the default java.util.Date.toString() formatter
        java.text.DateFormat dateFormatter = new java.text.SimpleDateFormat("EEE MMM dd hh:mm:ss zzz yyyy");
        dateFormatter.setLenient(true);
        this.dateTimeFormatters.put(null, dateFormatter);
    }

    private java.lang.String minlengthTest;

    /**
     * 
     */
    public java.lang.String getMinlengthTest()
    {
        return this.minlengthTest;
    }

    /**
     * Keeps track of whether or not the value of minlengthTest has
     * be populated at least once.
     */
    private boolean minlengthTestSet = false;

    /**
     * Indicates whether or not the value for minlengthTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMinlengthTestSet()
    {
        return this.minlengthTestSet;
    }

    /**
     * 
     */
    public void setMinlengthTest(java.lang.String minlengthTest)
    {
        this.minlengthTest = minlengthTest;
        this.minlengthTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] minlengthTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] minlengthTestLabelList;
    public java.lang.Object[] getMinlengthTestBackingList()
    {
        java.lang.Object[] values = this.minlengthTestValueList;
        java.lang.Object[] labels = this.minlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getMinlengthTestValueList()
    {
        return this.minlengthTestValueList;
    }

    public void setMinlengthTestValueList(java.lang.Object[] minlengthTestValueList)
    {
        this.minlengthTestValueList = minlengthTestValueList;
    }

    public java.lang.Object[] getMinlengthTestLabelList()
    {
        return this.minlengthTestLabelList;
    }

    public void setMinlengthTestLabelList(java.lang.Object[] minlengthTestLabelList)
    {
        this.minlengthTestLabelList = minlengthTestLabelList;
    }

    public void setMinlengthTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setMinlengthTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.minlengthTestValueList = null;
        this.minlengthTestLabelList = null;
        if (items != null)
        {
            this.minlengthTestValueList = new java.lang.Object[items.size()];
            this.minlengthTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.minlengthTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.minlengthTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String maxlengthTest;

    /**
     * 
     */
    public java.lang.String getMaxlengthTest()
    {
        return this.maxlengthTest;
    }

    /**
     * Keeps track of whether or not the value of maxlengthTest has
     * be populated at least once.
     */
    private boolean maxlengthTestSet = false;

    /**
     * Indicates whether or not the value for maxlengthTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMaxlengthTestSet()
    {
        return this.maxlengthTestSet;
    }

    /**
     * 
     */
    public void setMaxlengthTest(java.lang.String maxlengthTest)
    {
        this.maxlengthTest = maxlengthTest;
        this.maxlengthTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] maxlengthTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] maxlengthTestLabelList;
    public java.lang.Object[] getMaxlengthTestBackingList()
    {
        java.lang.Object[] values = this.maxlengthTestValueList;
        java.lang.Object[] labels = this.maxlengthTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getMaxlengthTestValueList()
    {
        return this.maxlengthTestValueList;
    }

    public void setMaxlengthTestValueList(java.lang.Object[] maxlengthTestValueList)
    {
        this.maxlengthTestValueList = maxlengthTestValueList;
    }

    public java.lang.Object[] getMaxlengthTestLabelList()
    {
        return this.maxlengthTestLabelList;
    }

    public void setMaxlengthTestLabelList(java.lang.Object[] maxlengthTestLabelList)
    {
        this.maxlengthTestLabelList = maxlengthTestLabelList;
    }

    public void setMaxlengthTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setMaxlengthTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.maxlengthTestValueList = null;
        this.maxlengthTestLabelList = null;
        if (items != null)
        {
            this.maxlengthTestValueList = new java.lang.Object[items.size()];
            this.maxlengthTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.maxlengthTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.maxlengthTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String patternTest;

    /**
     * 
     */
    public java.lang.String getPatternTest()
    {
        return this.patternTest;
    }

    /**
     * Keeps track of whether or not the value of patternTest has
     * be populated at least once.
     */
    private boolean patternTestSet = false;

    /**
     * Indicates whether or not the value for patternTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isPatternTestSet()
    {
        return this.patternTestSet;
    }

    /**
     * 
     */
    public void setPatternTest(java.lang.String patternTest)
    {
        this.patternTest = patternTest;
        this.patternTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] patternTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] patternTestLabelList;
    public java.lang.Object[] getPatternTestBackingList()
    {
        java.lang.Object[] values = this.patternTestValueList;
        java.lang.Object[] labels = this.patternTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getPatternTestValueList()
    {
        return this.patternTestValueList;
    }

    public void setPatternTestValueList(java.lang.Object[] patternTestValueList)
    {
        this.patternTestValueList = patternTestValueList;
    }

    public java.lang.Object[] getPatternTestLabelList()
    {
        return this.patternTestLabelList;
    }

    public void setPatternTestLabelList(java.lang.Object[] patternTestLabelList)
    {
        this.patternTestLabelList = patternTestLabelList;
    }

    public void setPatternTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setPatternTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.patternTestValueList = null;
        this.patternTestLabelList = null;
        if (items != null)
        {
            this.patternTestValueList = new java.lang.Object[items.size()];
            this.patternTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.patternTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.patternTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String creditcardTest;

    /**
     * 
     */
    public java.lang.String getCreditcardTest()
    {
        return this.creditcardTest;
    }

    /**
     * Keeps track of whether or not the value of creditcardTest has
     * be populated at least once.
     */
    private boolean creditcardTestSet = false;

    /**
     * Indicates whether or not the value for creditcardTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isCreditcardTestSet()
    {
        return this.creditcardTestSet;
    }

    /**
     * 
     */
    public void setCreditcardTest(java.lang.String creditcardTest)
    {
        this.creditcardTest = creditcardTest;
        this.creditcardTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] creditcardTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] creditcardTestLabelList;
    public java.lang.Object[] getCreditcardTestBackingList()
    {
        java.lang.Object[] values = this.creditcardTestValueList;
        java.lang.Object[] labels = this.creditcardTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getCreditcardTestValueList()
    {
        return this.creditcardTestValueList;
    }

    public void setCreditcardTestValueList(java.lang.Object[] creditcardTestValueList)
    {
        this.creditcardTestValueList = creditcardTestValueList;
    }

    public java.lang.Object[] getCreditcardTestLabelList()
    {
        return this.creditcardTestLabelList;
    }

    public void setCreditcardTestLabelList(java.lang.Object[] creditcardTestLabelList)
    {
        this.creditcardTestLabelList = creditcardTestLabelList;
    }

    public void setCreditcardTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setCreditcardTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.creditcardTestValueList = null;
        this.creditcardTestLabelList = null;
        if (items != null)
        {
            this.creditcardTestValueList = new java.lang.Object[items.size()];
            this.creditcardTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.creditcardTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.creditcardTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String emailTest;

    /**
     * 
     */
    public java.lang.String getEmailTest()
    {
        return this.emailTest;
    }

    /**
     * Keeps track of whether or not the value of emailTest has
     * be populated at least once.
     */
    private boolean emailTestSet = false;

    /**
     * Indicates whether or not the value for emailTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isEmailTestSet()
    {
        return this.emailTestSet;
    }

    /**
     * 
     */
    public void setEmailTest(java.lang.String emailTest)
    {
        this.emailTest = emailTest;
        this.emailTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] emailTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] emailTestLabelList;
    public java.lang.Object[] getEmailTestBackingList()
    {
        java.lang.Object[] values = this.emailTestValueList;
        java.lang.Object[] labels = this.emailTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getEmailTestValueList()
    {
        return this.emailTestValueList;
    }

    public void setEmailTestValueList(java.lang.Object[] emailTestValueList)
    {
        this.emailTestValueList = emailTestValueList;
    }

    public java.lang.Object[] getEmailTestLabelList()
    {
        return this.emailTestLabelList;
    }

    public void setEmailTestLabelList(java.lang.Object[] emailTestLabelList)
    {
        this.emailTestLabelList = emailTestLabelList;
    }

    public void setEmailTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setEmailTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.emailTestValueList = null;
        this.emailTestLabelList = null;
        if (items != null)
        {
            this.emailTestValueList = new java.lang.Object[items.size()];
            this.emailTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.emailTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.emailTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.net.URL urlTest;

    /**
     * 
     */
    public java.net.URL getUrlTest()
    {
        return this.urlTest;
    }

    /**
     * Keeps track of whether or not the value of urlTest has
     * be populated at least once.
     */
    private boolean urlTestSet = false;

    /**
     * Indicates whether or not the value for urlTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isUrlTestSet()
    {
        return this.urlTestSet;
    }

    /**
     * 
     */
    public void setUrlTest(java.net.URL urlTest)
    {
        this.urlTest = urlTest;
        this.urlTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] urlTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] urlTestLabelList;
    public java.lang.Object[] getUrlTestBackingList()
    {
        java.lang.Object[] values = this.urlTestValueList;
        java.lang.Object[] labels = this.urlTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getUrlTestValueList()
    {
        return this.urlTestValueList;
    }

    public void setUrlTestValueList(java.lang.Object[] urlTestValueList)
    {
        this.urlTestValueList = urlTestValueList;
    }

    public java.lang.Object[] getUrlTestLabelList()
    {
        return this.urlTestLabelList;
    }

    public void setUrlTestLabelList(java.lang.Object[] urlTestLabelList)
    {
        this.urlTestLabelList = urlTestLabelList;
    }

    public void setUrlTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setUrlTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.urlTestValueList = null;
        this.urlTestLabelList = null;
        if (items != null)
        {
            this.urlTestValueList = new java.lang.Object[items.size()];
            this.urlTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.urlTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.urlTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private int intRangeTest;

    /**
     * 
     */
    public int getIntRangeTest()
    {
        return this.intRangeTest;
    }

    /**
     * Keeps track of whether or not the value of intRangeTest has
     * be populated at least once.
     */
    private boolean intRangeTestSet = false;

    /**
     * Indicates whether or not the value for intRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isIntRangeTestSet()
    {
        return this.intRangeTestSet;
    }

    /**
     * 
     */
    public void setIntRangeTest(int intRangeTest)
    {
        this.intRangeTest = intRangeTest;
        this.intRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] intRangeTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] intRangeTestLabelList;
    public java.lang.Object[] getIntRangeTestBackingList()
    {
        java.lang.Object[] values = this.intRangeTestValueList;
        java.lang.Object[] labels = this.intRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getIntRangeTestValueList()
    {
        return this.intRangeTestValueList;
    }

    public void setIntRangeTestValueList(java.lang.Object[] intRangeTestValueList)
    {
        this.intRangeTestValueList = intRangeTestValueList;
    }

    public java.lang.Object[] getIntRangeTestLabelList()
    {
        return this.intRangeTestLabelList;
    }

    public void setIntRangeTestLabelList(java.lang.Object[] intRangeTestLabelList)
    {
        this.intRangeTestLabelList = intRangeTestLabelList;
    }

    public void setIntRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setIntRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.intRangeTestValueList = null;
        this.intRangeTestLabelList = null;
        if (items != null)
        {
            this.intRangeTestValueList = new java.lang.Object[items.size()];
            this.intRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.intRangeTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.intRangeTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private float floatRangeTest;

    /**
     * 
     */
    public float getFloatRangeTest()
    {
        return this.floatRangeTest;
    }

    /**
     * Keeps track of whether or not the value of floatRangeTest has
     * be populated at least once.
     */
    private boolean floatRangeTestSet = false;

    /**
     * Indicates whether or not the value for floatRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFloatRangeTestSet()
    {
        return this.floatRangeTestSet;
    }

    /**
     * 
     */
    public void setFloatRangeTest(float floatRangeTest)
    {
        this.floatRangeTest = floatRangeTest;
        this.floatRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] floatRangeTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] floatRangeTestLabelList;
    public java.lang.Object[] getFloatRangeTestBackingList()
    {
        java.lang.Object[] values = this.floatRangeTestValueList;
        java.lang.Object[] labels = this.floatRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFloatRangeTestValueList()
    {
        return this.floatRangeTestValueList;
    }

    public void setFloatRangeTestValueList(java.lang.Object[] floatRangeTestValueList)
    {
        this.floatRangeTestValueList = floatRangeTestValueList;
    }

    public java.lang.Object[] getFloatRangeTestLabelList()
    {
        return this.floatRangeTestLabelList;
    }

    public void setFloatRangeTestLabelList(java.lang.Object[] floatRangeTestLabelList)
    {
        this.floatRangeTestLabelList = floatRangeTestLabelList;
    }

    public void setFloatRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setFloatRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.floatRangeTestValueList = null;
        this.floatRangeTestLabelList = null;
        if (items != null)
        {
            this.floatRangeTestValueList = new java.lang.Object[items.size()];
            this.floatRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.floatRangeTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.floatRangeTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private double doubleRangeTest;

    /**
     * 
     */
    public double getDoubleRangeTest()
    {
        return this.doubleRangeTest;
    }

    /**
     * Keeps track of whether or not the value of doubleRangeTest has
     * be populated at least once.
     */
    private boolean doubleRangeTestSet = false;

    /**
     * Indicates whether or not the value for doubleRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDoubleRangeTestSet()
    {
        return this.doubleRangeTestSet;
    }

    /**
     * 
     */
    public void setDoubleRangeTest(double doubleRangeTest)
    {
        this.doubleRangeTest = doubleRangeTest;
        this.doubleRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] doubleRangeTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] doubleRangeTestLabelList;
    public java.lang.Object[] getDoubleRangeTestBackingList()
    {
        java.lang.Object[] values = this.doubleRangeTestValueList;
        java.lang.Object[] labels = this.doubleRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getDoubleRangeTestValueList()
    {
        return this.doubleRangeTestValueList;
    }

    public void setDoubleRangeTestValueList(java.lang.Object[] doubleRangeTestValueList)
    {
        this.doubleRangeTestValueList = doubleRangeTestValueList;
    }

    public java.lang.Object[] getDoubleRangeTestLabelList()
    {
        return this.doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestLabelList(java.lang.Object[] doubleRangeTestLabelList)
    {
        this.doubleRangeTestLabelList = doubleRangeTestLabelList;
    }

    public void setDoubleRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setDoubleRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.doubleRangeTestValueList = null;
        this.doubleRangeTestLabelList = null;
        if (items != null)
        {
            this.doubleRangeTestValueList = new java.lang.Object[items.size()];
            this.doubleRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.doubleRangeTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.doubleRangeTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.Integer intWrapperRangeTest;

    /**
     * 
     */
    public java.lang.Integer getIntWrapperRangeTest()
    {
        return this.intWrapperRangeTest;
    }

    /**
     * Keeps track of whether or not the value of intWrapperRangeTest has
     * be populated at least once.
     */
    private boolean intWrapperRangeTestSet = false;

    /**
     * Indicates whether or not the value for intWrapperRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isIntWrapperRangeTestSet()
    {
        return this.intWrapperRangeTestSet;
    }

    /**
     * 
     */
    public void setIntWrapperRangeTest(java.lang.Integer intWrapperRangeTest)
    {
        this.intWrapperRangeTest = intWrapperRangeTest;
        this.intWrapperRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] intWrapperRangeTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] intWrapperRangeTestLabelList;
    public java.lang.Object[] getIntWrapperRangeTestBackingList()
    {
        java.lang.Object[] values = this.intWrapperRangeTestValueList;
        java.lang.Object[] labels = this.intWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getIntWrapperRangeTestValueList()
    {
        return this.intWrapperRangeTestValueList;
    }

    public void setIntWrapperRangeTestValueList(java.lang.Object[] intWrapperRangeTestValueList)
    {
        this.intWrapperRangeTestValueList = intWrapperRangeTestValueList;
    }

    public java.lang.Object[] getIntWrapperRangeTestLabelList()
    {
        return this.intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestLabelList(java.lang.Object[] intWrapperRangeTestLabelList)
    {
        this.intWrapperRangeTestLabelList = intWrapperRangeTestLabelList;
    }

    public void setIntWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setIntWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.intWrapperRangeTestValueList = null;
        this.intWrapperRangeTestLabelList = null;
        if (items != null)
        {
            this.intWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.intWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.intWrapperRangeTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.intWrapperRangeTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.Float floatWrapperRangeTest;

    /**
     * 
     */
    public java.lang.Float getFloatWrapperRangeTest()
    {
        return this.floatWrapperRangeTest;
    }

    /**
     * Keeps track of whether or not the value of floatWrapperRangeTest has
     * be populated at least once.
     */
    private boolean floatWrapperRangeTestSet = false;

    /**
     * Indicates whether or not the value for floatWrapperRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isFloatWrapperRangeTestSet()
    {
        return this.floatWrapperRangeTestSet;
    }

    /**
     * 
     */
    public void setFloatWrapperRangeTest(java.lang.Float floatWrapperRangeTest)
    {
        this.floatWrapperRangeTest = floatWrapperRangeTest;
        this.floatWrapperRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] floatWrapperRangeTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] floatWrapperRangeTestLabelList;
    public java.lang.Object[] getFloatWrapperRangeTestBackingList()
    {
        java.lang.Object[] values = this.floatWrapperRangeTestValueList;
        java.lang.Object[] labels = this.floatWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getFloatWrapperRangeTestValueList()
    {
        return this.floatWrapperRangeTestValueList;
    }

    public void setFloatWrapperRangeTestValueList(java.lang.Object[] floatWrapperRangeTestValueList)
    {
        this.floatWrapperRangeTestValueList = floatWrapperRangeTestValueList;
    }

    public java.lang.Object[] getFloatWrapperRangeTestLabelList()
    {
        return this.floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestLabelList(java.lang.Object[] floatWrapperRangeTestLabelList)
    {
        this.floatWrapperRangeTestLabelList = floatWrapperRangeTestLabelList;
    }

    public void setFloatWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setFloatWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.floatWrapperRangeTestValueList = null;
        this.floatWrapperRangeTestLabelList = null;
        if (items != null)
        {
            this.floatWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.floatWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.floatWrapperRangeTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.floatWrapperRangeTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.Double doubleWrapperRangeTest;

    /**
     * 
     */
    public java.lang.Double getDoubleWrapperRangeTest()
    {
        return this.doubleWrapperRangeTest;
    }

    /**
     * Keeps track of whether or not the value of doubleWrapperRangeTest has
     * be populated at least once.
     */
    private boolean doubleWrapperRangeTestSet = false;

    /**
     * Indicates whether or not the value for doubleWrapperRangeTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isDoubleWrapperRangeTestSet()
    {
        return this.doubleWrapperRangeTestSet;
    }

    /**
     * 
     */
    public void setDoubleWrapperRangeTest(java.lang.Double doubleWrapperRangeTest)
    {
        this.doubleWrapperRangeTest = doubleWrapperRangeTest;
        this.doubleWrapperRangeTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] doubleWrapperRangeTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] doubleWrapperRangeTestLabelList;
    public java.lang.Object[] getDoubleWrapperRangeTestBackingList()
    {
        java.lang.Object[] values = this.doubleWrapperRangeTestValueList;
        java.lang.Object[] labels = this.doubleWrapperRangeTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getDoubleWrapperRangeTestValueList()
    {
        return this.doubleWrapperRangeTestValueList;
    }

    public void setDoubleWrapperRangeTestValueList(java.lang.Object[] doubleWrapperRangeTestValueList)
    {
        this.doubleWrapperRangeTestValueList = doubleWrapperRangeTestValueList;
    }

    public java.lang.Object[] getDoubleWrapperRangeTestLabelList()
    {
        return this.doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestLabelList(java.lang.Object[] doubleWrapperRangeTestLabelList)
    {
        this.doubleWrapperRangeTestLabelList = doubleWrapperRangeTestLabelList;
    }

    public void setDoubleWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setDoubleWrapperRangeTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.doubleWrapperRangeTestValueList = null;
        this.doubleWrapperRangeTestLabelList = null;
        if (items != null)
        {
            this.doubleWrapperRangeTestValueList = new java.lang.Object[items.size()];
            this.doubleWrapperRangeTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.doubleWrapperRangeTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.doubleWrapperRangeTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.util.Date lenientDateTest;

    /**
     * 
     */
    public java.util.Date getLenientDateTest()
    {
        return this.lenientDateTest;
    }

    /**
     * Keeps track of whether or not the value of lenientDateTest has
     * be populated at least once.
     */
    private boolean lenientDateTestSet = false;

    /**
     * Indicates whether or not the value for lenientDateTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isLenientDateTestSet()
    {
        return this.lenientDateTestSet;
    }

    /**
     * 
     */
    public void setLenientDateTest(java.util.Date lenientDateTest)
    {
        this.lenientDateTest = lenientDateTest;
        this.lenientDateTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] lenientDateTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] lenientDateTestLabelList;
    public java.lang.Object[] getLenientDateTestBackingList()
    {
        java.lang.Object[] values = this.lenientDateTestValueList;
        java.lang.Object[] labels = this.lenientDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getLenientDateTestValueList()
    {
        return this.lenientDateTestValueList;
    }

    public void setLenientDateTestValueList(java.lang.Object[] lenientDateTestValueList)
    {
        this.lenientDateTestValueList = lenientDateTestValueList;
    }

    public java.lang.Object[] getLenientDateTestLabelList()
    {
        return this.lenientDateTestLabelList;
    }

    public void setLenientDateTestLabelList(java.lang.Object[] lenientDateTestLabelList)
    {
        this.lenientDateTestLabelList = lenientDateTestLabelList;
    }

    public void setLenientDateTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setLenientDateTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.lenientDateTestValueList = null;
        this.lenientDateTestLabelList = null;
        if (items != null)
        {
            this.lenientDateTestValueList = new java.lang.Object[items.size()];
            this.lenientDateTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.lenientDateTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.lenientDateTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.util.Date strictDateTest;

    /**
     * 
     */
    public java.util.Date getStrictDateTest()
    {
        return this.strictDateTest;
    }

    /**
     * Keeps track of whether or not the value of strictDateTest has
     * be populated at least once.
     */
    private boolean strictDateTestSet = false;

    /**
     * Indicates whether or not the value for strictDateTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isStrictDateTestSet()
    {
        return this.strictDateTestSet;
    }

    /**
     * 
     */
    public void setStrictDateTest(java.util.Date strictDateTest)
    {
        this.strictDateTest = strictDateTest;
        this.strictDateTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] strictDateTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] strictDateTestLabelList;
    public java.lang.Object[] getStrictDateTestBackingList()
    {
        java.lang.Object[] values = this.strictDateTestValueList;
        java.lang.Object[] labels = this.strictDateTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getStrictDateTestValueList()
    {
        return this.strictDateTestValueList;
    }

    public void setStrictDateTestValueList(java.lang.Object[] strictDateTestValueList)
    {
        this.strictDateTestValueList = strictDateTestValueList;
    }

    public java.lang.Object[] getStrictDateTestLabelList()
    {
        return this.strictDateTestLabelList;
    }

    public void setStrictDateTestLabelList(java.lang.Object[] strictDateTestLabelList)
    {
        this.strictDateTestLabelList = strictDateTestLabelList;
    }

    public void setStrictDateTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setStrictDateTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.strictDateTestValueList = null;
        this.strictDateTestLabelList = null;
        if (items != null)
        {
            this.strictDateTestValueList = new java.lang.Object[items.size()];
            this.strictDateTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.strictDateTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.strictDateTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String requiredTest;

    /**
     * 
     */
    public java.lang.String getRequiredTest()
    {
        return this.requiredTest;
    }

    /**
     * Keeps track of whether or not the value of requiredTest has
     * be populated at least once.
     */
    private boolean requiredTestSet = false;

    /**
     * Indicates whether or not the value for requiredTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isRequiredTestSet()
    {
        return this.requiredTestSet;
    }

    /**
     * 
     */
    public void setRequiredTest(java.lang.String requiredTest)
    {
        this.requiredTest = requiredTest;
        this.requiredTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] requiredTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] requiredTestLabelList;
    public java.lang.Object[] getRequiredTestBackingList()
    {
        java.lang.Object[] values = this.requiredTestValueList;
        java.lang.Object[] labels = this.requiredTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getRequiredTestValueList()
    {
        return this.requiredTestValueList;
    }

    public void setRequiredTestValueList(java.lang.Object[] requiredTestValueList)
    {
        this.requiredTestValueList = requiredTestValueList;
    }

    public java.lang.Object[] getRequiredTestLabelList()
    {
        return this.requiredTestLabelList;
    }

    public void setRequiredTestLabelList(java.lang.Object[] requiredTestLabelList)
    {
        this.requiredTestLabelList = requiredTestLabelList;
    }

    public void setRequiredTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setRequiredTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.requiredTestValueList = null;
        this.requiredTestLabelList = null;
        if (items != null)
        {
            this.requiredTestValueList = new java.lang.Object[items.size()];
            this.requiredTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.requiredTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.requiredTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.util.Date hiddenNotValidated;

    /**
     * 
     */
    public java.util.Date getHiddenNotValidated()
    {
        return this.hiddenNotValidated;
    }

    /**
     * Keeps track of whether or not the value of hiddenNotValidated has
     * be populated at least once.
     */
    private boolean hiddenNotValidatedSet = false;

    /**
     * Indicates whether or not the value for hiddenNotValidated has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isHiddenNotValidatedSet()
    {
        return this.hiddenNotValidatedSet;
    }

    /**
     * 
     */
    public void setHiddenNotValidated(java.util.Date hiddenNotValidated)
    {
        this.hiddenNotValidated = hiddenNotValidated;
        this.hiddenNotValidatedSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] hiddenNotValidatedValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] hiddenNotValidatedLabelList;
    public java.lang.Object[] getHiddenNotValidatedBackingList()
    {
        java.lang.Object[] values = this.hiddenNotValidatedValueList;
        java.lang.Object[] labels = this.hiddenNotValidatedLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getHiddenNotValidatedValueList()
    {
        return this.hiddenNotValidatedValueList;
    }

    public void setHiddenNotValidatedValueList(java.lang.Object[] hiddenNotValidatedValueList)
    {
        this.hiddenNotValidatedValueList = hiddenNotValidatedValueList;
    }

    public java.lang.Object[] getHiddenNotValidatedLabelList()
    {
        return this.hiddenNotValidatedLabelList;
    }

    public void setHiddenNotValidatedLabelList(java.lang.Object[] hiddenNotValidatedLabelList)
    {
        this.hiddenNotValidatedLabelList = hiddenNotValidatedLabelList;
    }

    public void setHiddenNotValidatedBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setHiddenNotValidatedBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.hiddenNotValidatedValueList = null;
        this.hiddenNotValidatedLabelList = null;
        if (items != null)
        {
            this.hiddenNotValidatedValueList = new java.lang.Object[items.size()];
            this.hiddenNotValidatedLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.hiddenNotValidatedValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.hiddenNotValidatedLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    


    private java.lang.String minLengthOnPasswordTest;

    /**
     * 
     */
    public java.lang.String getMinLengthOnPasswordTest()
    {
        return this.minLengthOnPasswordTest;
    }

    /**
     * Keeps track of whether or not the value of minLengthOnPasswordTest has
     * be populated at least once.
     */
    private boolean minLengthOnPasswordTestSet = false;

    /**
     * Indicates whether or not the value for minLengthOnPasswordTest has been set at least
     * once.
     *
     * @return true/false
     */
    public boolean isMinLengthOnPasswordTestSet()
    {
        return this.minLengthOnPasswordTestSet;
    }

    /**
     * 
     */
    public void setMinLengthOnPasswordTest(java.lang.String minLengthOnPasswordTest)
    {
        this.minLengthOnPasswordTest = minLengthOnPasswordTest;
        this.minLengthOnPasswordTestSet = true;
    }

    /**
     * Stores the values.
     */
    private java.lang.Object[] minLengthOnPasswordTestValueList;
    
    /**
     * Stores the labels
     */
    private java.lang.Object[] minLengthOnPasswordTestLabelList;
    public java.lang.Object[] getMinLengthOnPasswordTestBackingList()
    {
        java.lang.Object[] values = this.minLengthOnPasswordTestValueList;
        java.lang.Object[] labels = this.minLengthOnPasswordTestLabelList;

        if (values == null || values.length == 0)
        {
            return values;
        }

        if (labels == null || labels.length == 0)
        {
            labels = values;
        }

        final int length = java.lang.Math.min(labels.length, values.length);
        javax.faces.model.SelectItem[] backingList = new javax.faces.model.SelectItem[length];

        for (int ctr = 0; ctr < length; ctr++)
        {
            backingList[ctr] = new javax.faces.model.SelectItem(java.lang.String.valueOf(values[ctr]), java.lang.String.valueOf(labels[ctr]));
        }
        return backingList;
    }

    public java.lang.Object[] getMinLengthOnPasswordTestValueList()
    {
        return this.minLengthOnPasswordTestValueList;
    }

    public void setMinLengthOnPasswordTestValueList(java.lang.Object[] minLengthOnPasswordTestValueList)
    {
        this.minLengthOnPasswordTestValueList = minLengthOnPasswordTestValueList;
    }

    public java.lang.Object[] getMinLengthOnPasswordTestLabelList()
    {
        return this.minLengthOnPasswordTestLabelList;
    }

    public void setMinLengthOnPasswordTestLabelList(java.lang.Object[] minLengthOnPasswordTestLabelList)
    {
        this.minLengthOnPasswordTestLabelList = minLengthOnPasswordTestLabelList;
    }

    public void setMinLengthOnPasswordTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty)
    {
        if (valueProperty == null || labelProperty == null)
        {
            throw new IllegalArgumentException("EnterDataValidateFormImpl.setMinLengthOnPasswordTestBackingList(java.util.Collection items, java.lang.String valueProperty, java.lang.String labelProperty) requires non-null arguments");
        }
        this.minLengthOnPasswordTestValueList = null;
        this.minLengthOnPasswordTestLabelList = null;
        if (items != null)
        {
            this.minLengthOnPasswordTestValueList = new java.lang.Object[items.size()];
            this.minLengthOnPasswordTestLabelList = new java.lang.Object[items.size()];

            try
            {
                int ctr = 0;
                for (final java.util.Iterator iterator = items.iterator(); iterator.hasNext(); ctr++)
                {
                    final java.lang.Object item = iterator.next();
                    this.minLengthOnPasswordTestValueList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, valueProperty.trim());
                    this.minLengthOnPasswordTestLabelList[ctr] = org.apache.commons.beanutils.PropertyUtils.getProperty(item, labelProperty.trim());
                }
            }
            catch (final Throwable throwable)
            {
                throw new java.lang.RuntimeException(throwable);
            }
        }
    }
    

    /**
     * Stores any date or time formatters for this form.
     */
    private final java.util.Map dateTimeFormatters = new java.util.HashMap();

    /**
     * Gets any date and time formatters (keyed by property name)
     * for this form.
     *
     * @return the Map containing any date and time formatters.
     */
    public java.util.Map getDateTimeFormatters()
    {
        return this.dateTimeFormatters;
    }
    
    /**
     * The current collection of messages stored within this form.
     */
    private java.util.Map jsfMessages = new java.util.LinkedHashMap();
    
    /**
     * Adds a {@link javax.faces.application.FacesMessage} message to the current messages
     * stored within this form.
     * 
     * @param jsfMessage the faces message to add.
     */
    public void addJsfMessages(javax.faces.application.FacesMessage jsfMessage)
    {
        if (jsfMessage != null)
        {
            this.jsfMessages.put(jsfMessage.getDetail(), jsfMessage);
        }
    }
    
    /**
     * Gets the current {@link javax.faces.application.FacesMessage} message 
     * instances stored within this form.
     * 
     * @return the current Faces messages.
     */
    public java.util.Collection getJsfMessages()
    {
        return this.jsfMessages.values();
    }

    /**
     * The serial version UID of this class. Needed for serialization.
     */
    private static final long serialVersionUID = 175428435667633554L;
}