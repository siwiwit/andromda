// license-header java merge-point
package org.andromda.cartridges.jsf.tests.formfields;

/**
 * 
 */
public abstract class Controller
    implements java.io.Serializable
{
    /**
     * 
     */
    public abstract void someOperation(SomeOperationForm form);

    /**
     * 
     */
    public abstract void anotherOperation(AnotherOperationForm form);


    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>formFieldsOneSubmitForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl getOneSubmitForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "formFieldsOneSubmitForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl)this.resolveVariable("formFieldsOneSubmitForm");
    }
    
    public java.lang.String oneSubmit()
    {
        String forward = null;
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        final Object currentForm = this.resolveVariable("form");
        try
        {
            final org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl form =
                this.getOneSubmitForm();

            // - pass any parameters from the previous form along 
            org.andromda.presentation.jsf.FormPopulator.populateForm(currentForm, form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", form);
                // - add this temporary ADF context to the session so that we can retrieve from a view populator if required
                this.getSession(false).setAttribute("AndroMDAADFContext", contextWrapper);
                forward = _two(form);
            }
            catch (final Throwable throwable)
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * 
     */
    private java.lang.String _two(final org.andromda.cartridges.jsf.tests.formfields.OneSubmitFormImpl form)
    {
        java.lang.String forward = null;
        someOperation(form);
        forward = "form-fields-three";
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.formfields.ThreeGoFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>formFieldsThreeGoForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.formfields.ThreeGoFormImpl getThreeGoForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "formFieldsThreeGoForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.formfields.ThreeGoFormImpl)this.resolveVariable("formFieldsThreeGoForm");
    }
    
    public java.lang.String threeGo()
    {
        String forward = null;
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        final Object currentForm = this.resolveVariable("form");
        try
        {
            final org.andromda.cartridges.jsf.tests.formfields.ThreeGoFormImpl form =
                this.getThreeGoForm();

            // - pass any parameters from the previous form along 
            org.andromda.presentation.jsf.FormPopulator.populateForm(currentForm, form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", form);
                // - add this temporary ADF context to the session so that we can retrieve from a view populator if required
                this.getSession(false).setAttribute("AndroMDAADFContext", contextWrapper);
                forward = "form-fields-one";
            }
            catch (final Throwable throwable)
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Retrieves the {@link org.andromda.cartridges.jsf.tests.formfields.FormFieldsFormImpl} form instance (normally you wont't
     * need to call this method explicitly, however this is here for times when you need to access the
     * <em>formFieldsFormFieldsForm</em> instance outside of its assigned controller operation).
     */
    protected org.andromda.cartridges.jsf.tests.formfields.FormFieldsFormImpl getFormFieldsForm()
    {
        // - we do this in the case a button that submitted the form was set to immediate (this should be removed 
        //   when we found a better way to handle this).
        final javax.faces.component.UIForm uiForm = this.findForm(this.getContext().getViewRoot(), "formFieldsFormFieldsForm");
        this.populateComponentInputs(uiForm);
        return (org.andromda.cartridges.jsf.tests.formfields.FormFieldsFormImpl)this.resolveVariable("formFieldsFormFieldsForm");
    }
    
    public java.lang.String formFields()
    {
        String forward = null;
        final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = new org.andromda.presentation.jsf.AdfFacesContextWrapper();
        final Object currentForm = this.resolveVariable("form");
        try
        {
            final org.andromda.cartridges.jsf.tests.formfields.FormFieldsFormImpl form =
                this.getFormFieldsForm();

            // - pass any parameters from the previous form along 
            org.andromda.presentation.jsf.FormPopulator.populateForm(currentForm, form);
            // - populate the form with any request parameters that may match
            this.populateFormFromRequestParameters(form, form.getDateTimeFormatters());
            try
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", form);
                // - add this temporary ADF context to the session so that we can retrieve from a view populator if required
                this.getSession(false).setAttribute("AndroMDAADFContext", contextWrapper);
                forward = "form-fields-one";
            }
            catch (final Throwable throwable)
            {
                contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
                final String message = org.andromda.presentation.jsf.Messages.get(
                    org.andromda.presentation.jsf.PatternMatchingExceptionHandler.instance().handleException(throwable), null);
                this.addErrorMessage(message);
            }
        }
        catch (final Throwable throwable)
        {
            contextWrapper.getCurrentInstance().getProcessScope().put("form", currentForm);
            this.addExceptionMessage(throwable);
            // - set the forward to null so that we stay on the current view
            forward = null;
        }
        return forward;
    }

    /**
     * Gets the current faces context.  This object is the point
     * from which to retrieve any request, session, etc information.
     *
     * @return the JSF faces context instance.
     */
    protected javax.faces.context.FacesContext getContext()
    {
        return javax.faces.context.FacesContext.getCurrentInstance();
    }

    /**
     * A helper method that gets the current request from the faces
     * context.
     *
     * @return the current HttpServletRequest instance.
     */
    protected javax.servlet.http.HttpServletRequest getRequest()
    {
        return (javax.servlet.http.HttpServletRequest)this.getContext().getExternalContext().getRequest();
    }

    /**
     * A helper method that gets the current reponse from the faces
     * context.
     *
     * @return the current HttpServletReponse instance.
     */
    protected javax.servlet.http.HttpServletResponse getResponse()
    {
        return (javax.servlet.http.HttpServletResponse)this.getContext().getExternalContext().getResponse();
    }

    /**
     * A helper method that gets the current session from the faces
     * context.
     *
     * @param create If the create parameter is true, create (if necessary) and return a
     *        session instance associated with the current request. If the create
     *        parameter is false return any existing session instance associated with the
     *        current request, or return null if there is no such session.
     * @return the current HttpSession instance.
     */
    protected javax.servlet.http.HttpSession getSession(final boolean create)
    {
        return (javax.servlet.http.HttpSession)this.getContext().getExternalContext().getSession(create);
    }
    
    /**
     * Attempts to resolve the variable, given, the <code>name</code> of
     * the variable using the faces context variable resolver instance.
     * 
     * @return the resolved variable or null if not found.
     */
    protected java.lang.Object resolveVariable(final String name)
    {
        oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        Object variable = adfContext.getProcessScope().get(name);
        // - if we couldn't get the variable from the regular ADF context, see if
        //   the session contains an ADF context with the variable
        if (variable == null)
        {
            final javax.servlet.http.HttpSession session = this.getSession(false);
            if (session != null)
            {
                final org.andromda.presentation.jsf.AdfFacesContextWrapper contextWrapper = 
                    (org.andromda.presentation.jsf.AdfFacesContextWrapper)session.getAttribute("AndroMDAADFContext");
                adfContext = contextWrapper != null ? contextWrapper.getCurrentInstance() : null;
            }
            variable = adfContext != null ? adfContext.getProcessScope().get(name) : null;
        }
        // - finally try resolving it in the standard JSF manner
        if (variable == null)
        {
            final javax.faces.context.FacesContext context = this.getContext();
            variable = context != null ? context.getApplication().getVariableResolver().resolveVariable(context, name) : null;
        }
        return variable;
    }

    /**
     * Finds the root cause of the given <code>throwable</code> and
     * adds the message taken from that cause to the faces context messages.
     *
     * @param throwable the exception information to add.
     */
    private final void addExceptionMessage(
        Throwable throwable)
    {
        String message = null;
        final Throwable rootCause = org.apache.commons.lang.exception.ExceptionUtils.getRootCause(throwable);
        if (rootCause != null)
        {
            message = rootCause.toString();
        }
        if (message == null || message.trim().length() == 0)
        {
            message = throwable.toString();
        }
        this.addErrorMessage(message);
    }

    /**
     * Adds the given error <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addErrorMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_ERROR, message);
    }

    /**
     * Adds the given warning <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addWarningMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_WARN, message);
    }

    /**
     * Adds the given info <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addInfoMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_INFO, message);
    }

    /**
     * Adds the given fatal <code>message</code> to the current faces context.
     *
     * @param message the message to add.
     */
    protected void addFatalMessage(final String message)
    {
        this.addMessage(javax.faces.application.FacesMessage.SEVERITY_FATAL, message);
    }

    /**
     * Adds a message to the faces context (which will show up on your view when using the
     * lt;h:messages/gt; tag).
     *
     * @param severity the severity of the message
     * @param message the message to add.
     */
    protected void addMessage(final javax.faces.application.FacesMessage.Severity severity, final String message)
    {
        final javax.faces.application.FacesMessage facesMessage = new javax.faces.application.FacesMessage(severity, message, message);
        final oracle.adf.view.faces.context.AdfFacesContext adfContext = oracle.adf.view.faces.context.AdfFacesContext.getCurrentInstance();
        final Object form = adfContext.getProcessScope().get("form");
        if (form != null)
        {
            try
            {
                final java.lang.reflect.Method method = form.getClass().getMethod(
                    "addJsfMessages", 
                    new Class[]{javax.faces.application.FacesMessage.class});
                method.invoke(form, new Object[]{facesMessage});  
            }
            catch (final Exception exception)
            {
                throw new RuntimeException(exception);
            }
        }
    }
    
    /**
     * Copies all matching properties from the <code>fromForm</code> to the given
     * <code>toForm</code> overridding any previously set values.
     */
    protected void copyForm(final Object fromForm, final Object toForm)
    {
        org.andromda.presentation.jsf.FormPopulator.populateForm(fromForm, toForm, true);
    }

    /**
     * Populates the form from the given parameters.  If the request parameter is null or an empty
     * string, then null is placed on the form.
     *
     * @param form the form to populate.
     * @param formatters any date or time formatters.
     */
    private final void populateFormFromRequestParameters(final Object form, final java.util.Map formatters)
    {
        try
        {
            final java.util.Map parameters = this.getContext().getExternalContext().getRequestParameterMap();
            for (final java.util.Iterator iterator = parameters.keySet().iterator(); iterator.hasNext();)
            {
                final String name = (String)iterator.next();
                if (org.apache.commons.beanutils.PropertyUtils.isWriteable(form, name))
                {
                    final java.beans.PropertyDescriptor descriptor =
                        org.apache.commons.beanutils.PropertyUtils.getPropertyDescriptor(form, name);
                    if (descriptor != null)
                    {
                        final String parameter = (String)parameters.get(name);
                        Object value = null;
                        // - only convert if the string is not empty
                        if (parameter != null && parameter.trim().length() > 0)
                        {
                            java.text.DateFormat formatter = (java.text.DateFormat)formatters.get(name);
                            // - if the formatter is available we use that, otherwise we attempt to convert
                            if (formatter != null)
                            {
                                try
                                {
                                    value = formatter.parse(parameter);
                                }
                                catch (java.text.ParseException parseException)
                                {
                                    // - try the default formatter (handles the default java.util.Date.toString() format)
                                    formatter = (java.text.DateFormat)formatters.get(null);
                                    value = formatter.parse(parameter); 
                                }
                            }
                            else
                            {
                                value = org.apache.commons.beanutils.ConvertUtils.convert(parameter, descriptor.getPropertyType());
                            }
                            org.apache.commons.beanutils.PropertyUtils.setProperty(form, name, value);
                        }
                    }
                }
            }
        }
        catch (final Throwable throwable)
        {
            throw new RuntimeException(throwable);
        }
    }
    
    /**
     * Finds the form (if one is present) on the given <code>component</code> having the given
     * <code>id</code>.
     * 
     * @param component the component to search.
     * @param id the id of the form.
     * @return the form or null if none was found.
     */
    private javax.faces.component.UIForm findForm(javax.faces.component.UIComponent component, String id)
    {
        javax.faces.component.UIForm foundForm = null;
        if (component != null)
        {
            for (final java.util.Iterator iterator = component.getFacetsAndChildren(); iterator.hasNext();)
            {
                final Object object = (javax.faces.component.UIComponent)iterator.next();
                if (object instanceof javax.faces.component.UIComponent)
                {
                    final javax.faces.component.UIComponent uiComponent = (javax.faces.component.UIComponent)object;
                    if (uiComponent instanceof javax.faces.component.UIForm)
                    {
                        final javax.faces.component.UIForm form = (javax.faces.component.UIForm)uiComponent;
                        if (form.getId().equals(id))
                        {
                            foundForm = form;
                            break;
                        }
                    }
                    foundForm = this.findForm(uiComponent, id);
                    if (foundForm != null)
                    {
                        break;
                    }
                }
            }
        }
        return foundForm;
    }
    
    /**
     * If the given <code>component</code> has an child input elements, this method findds
     * them all and populates them.  This is to get around the fact that when immediate is set to true
     * on a button that submits the form that the form isn't populated.
     * 
     * @param component the component to populate.
     */
    private void populateComponentInputs(javax.faces.component.UIComponent component)
    {
        if (component != null)
        {
            for (final java.util.Iterator iterator = component.getFacetsAndChildren(); iterator.hasNext();)
            {
                final javax.faces.component.UIComponent uiComponent = (javax.faces.component.UIComponent)iterator.next();
                if (uiComponent instanceof javax.faces.component.UIInput)
                {
                    try
                    {
                        final javax.faces.component.UIInput input = (javax.faces.component.UIInput)uiComponent;
                        input.validate(this.getContext());
                        input.updateModel(this.getContext());
                    }
                    catch (javax.faces.validator.ValidatorException exception)
                    {
                        // - ignore, no value is set (validate will be called by the regular
                        //   JSF lifecycle processing anyway, this is just called to populate the
                        //   local value
                    }
                }
                else
                {
                    this.populateComponentInputs(uiComponent);
                }
            }
        }
    }
}