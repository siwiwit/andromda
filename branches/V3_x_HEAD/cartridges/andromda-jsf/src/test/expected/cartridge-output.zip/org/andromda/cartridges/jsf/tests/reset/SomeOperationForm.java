// license-header java merge-point
package org.andromda.cartridges.jsf.tests.reset;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>someOperation</code> method, which is located on the
 * <code>org.andromda.cartridges.jsf.tests.reset.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.jsf.tests.reset.Controller#someOperation(java.lang.String firstParam)
 */
public interface SomeOperationForm
{
    /**
     * 
     */
    public java.lang.String getFirstParam();

    /**
     * 
     */
    public void setFirstParam(java.lang.String firstParam);
    
}