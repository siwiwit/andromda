delete from time_allocation;
delete from timecard;