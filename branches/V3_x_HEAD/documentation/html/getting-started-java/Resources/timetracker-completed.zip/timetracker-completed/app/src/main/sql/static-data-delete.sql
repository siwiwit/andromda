delete from USER;
delete from TASK;