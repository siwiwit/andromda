delete from USER_ROLE;
delete from USERS;
delete from TASK;