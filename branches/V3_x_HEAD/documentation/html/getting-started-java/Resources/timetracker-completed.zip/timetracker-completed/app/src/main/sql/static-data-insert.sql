insert into user values (1, 'nbhatia',      'Naresh', 'Bhatia');
insert into user values (2, 'lcoude',       'Louis',  'Coude');
insert into user values (3, 'ecrutchfield', 'Eric',   'Crutchfield');
insert into user values (4, 'cmicali',      'Chris',  'Micali');
commit;

insert into task values (1, 'Research');
insert into task values (2, 'Development');
insert into task values (3, 'Testing');
insert into task values (4, 'Admin');
insert into task values (5, 'Meeting');
commit;