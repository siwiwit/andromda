insert into USERS values (1, 'nbhatia',      'Naresh', 'Bhatia');
insert into USERS values (2, 'lcoude',       'Louis',  'Coude');
insert into USERS values (3, 'ecrutchfield', 'Eric',   'Crutchfield');
insert into USERS values (4, 'cmicali',      'Chris',  'Micali');
commit;

insert into TASK values (1, 'Research');
insert into TASK values (2, 'Development');
insert into TASK values (3, 'Testing');
insert into TASK values (4, 'Admin');
insert into TASK values (5, 'Meeting');
commit;