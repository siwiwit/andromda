/**
 * Example license header for Java files
 *
 *      http://www.andromda.org/
 */
package org.andromda.cartridges.bpm4struts.tests.services;

/**
 * This form encapsulates the fields that are used in the execution of the
 * <code>anOperation2</code> method, which is located on the
 * <code>org.andromda.cartridges.bpm4struts.tests.services.Controller</code> controller.
 *
 * 
 *
 * @see org.andromda.cartridges.bpm4struts.tests.services.Controller#anOperation2
 */
public interface AnOperation2Form
{
    /**
     * Sets the <code>one</code> field.
     *
     * 
     */
    public void setOne(java.lang.String one);

    /**
     * Gets the <code>one</code> field.
     *
     * 
     */
    public java.lang.String getOne();

    /**
     * Resets the <code>one</code> field.
     */
    public void resetOne();

    /**
     * Sets the <code>two</code> field.
     *
     * 
     */
    public void setTwo(int two);

    /**
     * Gets the <code>two</code> field.
     *
     * 
     */
    public int getTwo();

    /**
     * Resets the <code>two</code> field.
     */
    public void resetTwo();

    /**
     * Sets the <code>three</code> field.
     *
     * 
     */
    public void setThree(java.lang.String three);

    /**
     * Gets the <code>three</code> field.
     *
     * 
     */
    public java.lang.String getThree();

    /**
     * Resets the <code>three</code> field.
     */
    public void resetThree();

}
